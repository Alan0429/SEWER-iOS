# SEWER iOS

Native iOS client for the SEWER account service. This project is separate from the macOS and Windows clients.

The app links a reduced sing-box `libbox` for SOCKS5 and Shadowsocks routes and is therefore distributed under GNU GPL version 3. The build supports SIP002/legacy Shadowsocks URIs, `socks5h://`, and sing-box's built-in `obfs-local` and `v2ray-plugin`, without downloading or launching external plugin executables. See `LICENSE`, `LICENSE.sing-box`, and `CORRESPONDING_SOURCE.md` before publishing any build.

Public corresponding source for the `1.1.0` release is maintained at
[Alan0429/SEWER-iOS](https://github.com/Alan0429/SEWER-iOS).

## Current scope

- SwiftUI account and subscription interface
- Keychain-backed session storage
- SEWER API v3 encrypted transport (X25519 + HKDF-SHA256 + ChaCha20-Poly1305), pinned Ed25519 verification, encrypted subscription Grants, secure Keychain cache, and a 12-hour automatic refresh limit
- GeoIP/GeoSite routing data bundled with each App Store version
- Resolves SEWER and AWS route hostnames through Alibaba/Tencent DoH before connection, with plain DNS only as a fallback; `net.sewer.top` has a last-resort dial IP while TLS still validates the original hostname. After connection, DNS-over-53 is hijacked into Xray DNS and forwarded through the selected line
- Captures public IPv4/IPv6 and UDP, including WebRTC/STUN, to prevent physical-network leaks
- Optional Smart Acceleration selects a lower-latency CloudFront edge while preserving the original TLS SNI and certificate identity
- Smart Acceleration keeps up to four measured edges in a runtime Xray `leastPing` health pool and probes them every 10 seconds; new TCP/UDP flows can move to a healthy edge without restarting the Packet Tunnel
- TikTok and live-video domains use a dedicated non-Mux proxy pool so Mux head-of-line blocking does not throttle sustained media traffic
- The app performs low-cost end-to-end health checks while connected. Two consecutive failures trigger an in-place tunnel rebuild, and the extension also watches the local core and recovers if it exits unexpectedly
- App Store-managed updates only; the app neither downloads nor installs app updates
- A native `Packet Tunnel Provider` extension boundary using Network Extension
- In-app data-use disclosure, privacy policy, and App Review notes

The tunnel extension starts the locally bundled Xray Core only after the system Packet Tunnel has been configured. The app shows network protection as enabled after the system reports the tunnel is connected. A desktop executable or a downloaded executable must never be started on iOS.

For throughput, the extension first uses the provider's native utun descriptor when iOS makes it available to the process. Xray receives that descriptor directly, avoiding a second userspace packet bridge. If the descriptor cannot be obtained, the Packet Tunnel falls back to the compatibility bridge. The fallback bridge uses vectored writes, larger bounded queues and 8 MiB socket buffers. The virtual interface MTU is 1500. Xray mux is limited to VLESS TCP routes; WS, XHTTP, gRPC, HTTPUpgrade and Trojan keep their native transport multiplexing instead of stacking a second mux layer.

The Packet Tunnel data plane uses Xray Core source commit `5d17b872edde3024a5b906d9cd6c7a3ad4973d81` (upstream main, 2026-11-14) for VLESS and Trojan, and a reduced sing-box `libbox` build from KaringX/sing-box commit `73603b201141ee9bab41af76995808ccfc45209f` for SOCKS5 and Shadowsocks. Both cores are bundled locally. See `THIRD_PARTY_NOTICES.md` and `CORRESPONDING_SOURCE.md` for license obligations.

The two cores run in separate Packet Tunnel extensions (`SEWERTunnel` and `SEWERTunnelSingBox`) so each process contains exactly one Go runtime. Xray configures a 40 MiB soft Go heap limit to reduce the chance of a long-running Network Extension being terminated by iOS memory pressure.

## Opening the project

Open `SEWER.xcodeproj` in Xcode. Select the company development team for both targets before installing on a device. Packet Tunnel Provider requires a physical device and an Apple-issued Network Extension entitlement. Enable the App Group `group.top.sewer.client.ios` for both the app and `SEWERTunnel`.

## App Store compliance baseline

- The app is designed for an Organization Apple Developer account.
- It uses Apple's Network Extension APIs for all system tunnel operations.
- It requires the user to acknowledge the data-use notice before sign-in or connection.
- It does not collect advertising identifiers, sell traffic data, download executable content, or refresh routing data at runtime.
- Before App Store submission, keep the public privacy-policy URL, `AppStoreReviewNotes.md`, availability territories, App Store privacy details, and an active reviewer account accurate. The production policy is available at `https://net.sewer.top/privacy`.
