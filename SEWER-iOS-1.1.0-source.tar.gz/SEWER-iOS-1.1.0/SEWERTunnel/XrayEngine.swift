import Foundation
import XrayBridge

enum XrayEngine {
    private static let lifecycleLock = NSLock()

    static func start(configurationJSON: String, tunnelFileDescriptor: Int32) throws {
        lifecycleLock.lock()
        defer { lifecycleLock.unlock() }
        var error: NSError?
        guard XraybridgeStart(configurationJSON, Int(tunnelFileDescriptor), &error) else {
            throw error ?? NSError(domain: "top.sewer.client.ios.xray", code: 1, userInfo: [NSLocalizedDescriptionKey: "Xray 启动失败。"])
        }
    }

    static func stop() {
        lifecycleLock.lock()
        defer { lifecycleLock.unlock() }
        var error: NSError?
        _ = XraybridgeStop(&error)
    }

    static func isRunning() -> Bool {
        XraybridgeIsRunning()
    }
}
