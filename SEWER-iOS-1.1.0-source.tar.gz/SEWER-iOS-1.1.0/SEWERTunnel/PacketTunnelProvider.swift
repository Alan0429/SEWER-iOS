import Darwin
import Foundation
import Network
import NetworkExtension

// NEPacketTunnelProvider invokes its lifecycle callbacks serially. Mutable
// path-monitor state is confined to `tunnelStateQueue`, while the remaining
// properties are only mutated by start/stop callbacks. The unchecked Sendable
// declaration documents that invariant for recovery Tasks on newer SDKs.
final class PacketTunnelProvider: NEPacketTunnelProvider, @unchecked Sendable {
    private static let diagnosticsSuiteName = "group.top.sewer.client.ios"
    private static let diagnosticsKey = "sewer.tunnel.last-start-error.v1"
    // These resolvers are used only before the protected route is available,
    // to obtain a direct address for the selected proxy endpoint.
    private static let bootstrapDNSIPv4 = ["223.5.5.5", "1.2.4.8"]
    // Once the tunnel is running, device DNS requests enter Packet Flow and
    // are carried to this resolver through the selected proxy route.
    private static let protectedDNSIPv4 = ["1.1.1.1"]
    private static let bootstrapDNSIPv6: [String] = []
    private var packetBridge: PacketFlowBridge?
    private var nativeTunnelFileDescriptor: Int32?
    private let tunnelStateQueue = DispatchQueue(label: "top.sewer.client.ios.tunnel-state")
    private var activeTunnelState: ActiveTunnelState?
    private var pathMonitor: NWPathMonitor?
    private var lastSatisfiedPath: UnderlyingPathSignature?
    private var observedInitialPath = false
    private var pathWasUnavailable = false
    private var recoveryIsScheduled = false
    private var heartbeatTimer: DispatchSourceTimer?
    private var lastRuntimeStatusRecordedAt = Date.distantPast
    private var pathChangeCount = 0
    private var recoveryAttemptCount = 0
    private var lastReassertAt: Date?
    private var recoveryWindowStart = Date()
    private var recoveryCountInWindow = 0

    // iOS can stop a tunnel it considers unstable. A burst of reasserts from
    // rapid Wi-Fi/cellular alternation is one way to look unstable, so recovery
    // is rate-limited: at most one reassert per interval and a small number per
    // rolling window. Xray itself reconnects transient outbound sessions, so a
    // skipped refresh only delays a route update, never the data plane.
    private static let minimumReassertInterval: TimeInterval = 8
    private static let recoveryWindowDuration: TimeInterval = 120
    private static let maximumRecoveriesPerWindow = 4

    private enum TunnelError: LocalizedError {
        case missingConfiguration
        case missingTunnelServer
        case unresolvableTunnelServer
        case missingTunnelDescriptor

        var errorDescription: String? {
            switch self {
            case .missingConfiguration: return "缺少本地隧道配置。"
            case .missingTunnelServer: return "缺少线路服务器地址。"
            case .unresolvableTunnelServer: return "无法解析线路服务器，请检查互联网连接后重试。"
            case .missingTunnelDescriptor: return "无法获取系统分配的隧道接口。"
            }
        }
    }

    override func startTunnel(options: [String: NSObject]?) async throws {
        clearStartFailure()
        var stage = "准备启动"
        TunnelDiagnostics.record(source: "Tunnel", message: "扩展已启动，正在准备网络配置。")
        TunnelDiagnostics.markProcessStarted()
        TunnelDiagnostics.markAlive()
        do {
            // GeoIP and GeoSite data ship in this extension. Always use this
            // bundle so an app upgrade cannot retain stale cached rule data.
            if let resourcePath = Bundle.main.resourcePath {
                setenv("XRAY_LOCATION_ASSET", resourcePath, 1)
            }
        guard let tunnel = protocolConfiguration as? NETunnelProviderProtocol,
                  let configuration = (tunnel.providerConfiguration?["tunnelConfiguration"] as? String)
                    ?? (tunnel.providerConfiguration?["xrayConfiguration"] as? String),
                  !configuration.isEmpty else {
                throw TunnelError.missingConfiguration
            }
            let coreKind = tunnel.providerConfiguration?["coreEngine"] as? String ?? "xray"
            guard let remoteHost = tunnel.providerConfiguration?["remoteHost"] as? String,
                  !remoteHost.isEmpty else {
                throw TunnelError.missingTunnelServer
            }
            TunnelDiagnostics.record(
                source: "Tunnel",
                message: "线路已由系统交给 \(coreKind) 核心处理。"
            )

            let preResolved = tunnel.providerConfiguration?["resolvedRemoteAddresses"] as? [String] ?? []
            var previousAddresses = TunnelAddresses()
            for address in preResolved {
                if address.contains(":") { previousAddresses.insertIPv6(address) }
                else { previousAddresses.insertIPv4(address) }
            }
            let preferPreResolved = (options?["sewerPreResolved"] as? NSNumber)?.boolValue == true
            var remoteAddresses = preferPreResolved && !previousAddresses.isEmpty
                ? previousAddresses
                : await resolveProxyAddresses(for: remoteHost)
            TunnelDiagnostics.record(
                source: "Tunnel",
                message: "线路服务器地址解析完成，共 \(remoteAddresses.ordered.count) 个地址。"
            )
            if remoteAddresses.isEmpty {
                remoteAddresses = previousAddresses
            } else if !previousAddresses.isEmpty {
                // Prefer the result resolved on the current network. Addresses
                // saved in the provider configuration are retained only as a
                // fallback after a Wi-Fi/cellular handoff or On-Demand restart.
                remoteAddresses = remoteAddresses.union(previousAddresses)
            }
            let optimizedAddress = (tunnel.providerConfiguration?["optimizedAddress"] as? String)?
                .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            let configuredOptimizedAddresses = tunnel.providerConfiguration?["optimizedAddresses"] as? [String] ?? []
            var optimizedAddresses = configuredOptimizedAddresses.reduce(into: [String]()) { result, value in
                let address = value.trimmingCharacters(in: .whitespacesAndNewlines)
                if !address.isEmpty, !result.contains(address) { result.append(address) }
            }
            if optimizedAddresses.isEmpty, !optimizedAddress.isEmpty {
                optimizedAddresses = [optimizedAddress]
            }
            let primaryOptimizedAddress = optimizedAddresses.first ?? optimizedAddress
            guard !remoteAddresses.isEmpty else {
                throw TunnelError.unresolvableTunnelServer
            }
            let effectiveConfiguration: String
            if coreKind == "sing-box" {
                effectiveConfiguration = refreshedSingBoxConfiguration(
                    configuration,
                    addresses: remoteAddresses
                )
            } else if primaryOptimizedAddress.isEmpty {
                effectiveConfiguration = refreshedConfiguration(
                    configuration,
                    remoteHost: remoteHost,
                    addresses: remoteAddresses
                )
            } else {
                effectiveConfiguration = configuration
            }
            let tunnelRemoteAddress = primaryOptimizedAddress.isEmpty
                ? (remoteAddresses.preferredAddress ?? remoteHost)
                : primaryOptimizedAddress
            let addressFamily = remoteAddresses.ipv6.contains(tunnelRemoteAddress) ? "IPv6" : "IPv4"
            TunnelDiagnostics.record(
                source: "Tunnel",
                message: "本次线路出口使用 \(addressFamily) 地址：\(tunnelRemoteAddress)。"
            )
            let directHosts = tunnel.providerConfiguration?["directHosts"] as? [String] ?? []
            // Xray opens its outbound socket from inside this extension. These
            // destinations must retain a physical-network route; otherwise the
            // default Packet Tunnel route captures the connection again and the
            // proxy would attempt to reach itself in a loop.
            var directAddresses = remoteAddresses.union(await resolveServiceAddresses(for: directHosts))
            for address in optimizedAddresses { directAddresses.insertIPv4(address) }
            // The app resolves the origin through DoH before Xray starts.
            // The full address set (plus an optional optimized edge) is used
            // only for physical-network bypass routes; TLS SNI remains bound
            // to the original subscribed hostname in the Xray configuration.

            stage = "应用系统网络设置"
            try await applyNetworkSettings(
                tunnelRemoteAddress: tunnelRemoteAddress,
                directAddresses: directAddresses
            )
            TunnelDiagnostics.record(source: "Tunnel", message: "系统网络设置已应用。")
            stage = "建立数据通道并启动 Xray 核心"
            let activeFileDescriptor = try startDataPlane(
                configuration: effectiveConfiguration,
                coreKind: coreKind
            )
            startHeartbeat()
            beginMonitoringUnderlyingNetwork(
                configuration: effectiveConfiguration,
                remoteHost: remoteHost,
                directHosts: directHosts,
                optimizedAddress: primaryOptimizedAddress,
                optimizedAddresses: optimizedAddresses,
                tunnelFileDescriptor: activeFileDescriptor,
                coreKind: coreKind
            )
        } catch {
            stopMonitoringUnderlyingNetwork()
            packetBridge?.stopAndClose()
            packetBridge = nil
            nativeTunnelFileDescriptor = nil
            stopCores()
            recordStartFailure(stage: stage, error: error)
            TunnelDiagnostics.clearXrayErrorLog()
            cancelTunnelWithError(error)
            throw error
        }
    }

    override func stopTunnel(with reason: NEProviderStopReason) async {
        stopHeartbeat()
        let uptime = TunnelDiagnostics.processStartedAt().map {
            max(Int(Date().timeIntervalSince($0) / 60), 0)
        }
        if let xraySummary = TunnelDiagnostics.xrayErrorSummary() {
            TunnelDiagnostics.record(source: "Tunnel", message: "核心错误摘要：\(xraySummary)")
        }
        TunnelDiagnostics.record(
            source: "Tunnel",
            message: "扩展已停止（原因：\(stopReasonDescription(reason))；运行 \(uptime ?? 0) 分钟；路径切换 \(pathChangeCount) 次，网络恢复 \(recoveryAttemptCount) 次；停止时内存 \(TunnelDiagnostics.memoryFootprintDescription())）。"
        )
        stopMonitoringUnderlyingNetwork()
        // Release the packet bridge first so the Xray TUN read loop wakes up
        // before Instance.Close waits for its remaining features to stop.
        let bridge = packetBridge
        packetBridge = nil
        bridge?.stopAndClose()
        stopCores()
        nativeTunnelFileDescriptor = nil
        TunnelDiagnostics.markStopCompleted()
        TunnelDiagnostics.clearXrayErrorLog()
    }

    private func beginMonitoringUnderlyingNetwork(
        configuration: String,
        remoteHost: String,
        directHosts: [String],
        optimizedAddress: String,
        optimizedAddresses: [String],
        tunnelFileDescriptor: Int32,
        coreKind: String
    ) {
        let state = ActiveTunnelState(
            id: UUID(),
            configuration: configuration,
            remoteHost: remoteHost,
            directHosts: directHosts,
            optimizedAddress: optimizedAddress,
            optimizedAddresses: optimizedAddresses,
            tunnelFileDescriptor: tunnelFileDescriptor,
            coreKind: coreKind
        )
        tunnelStateQueue.sync {
            pathMonitor?.cancel()
            activeTunnelState = state
            lastSatisfiedPath = nil
            observedInitialPath = false
            pathWasUnavailable = false
            recoveryIsScheduled = false
            pathChangeCount = 0
            recoveryAttemptCount = 0
            lastReassertAt = nil
            recoveryWindowStart = Date()
            recoveryCountInWindow = 0

            let monitor = NWPathMonitor()
            monitor.pathUpdateHandler = { [weak self] path in
                self?.handleUnderlyingPathUpdate(path)
            }
            pathMonitor = monitor
            monitor.start(queue: tunnelStateQueue)
        }
    }

    private func stopMonitoringUnderlyingNetwork() {
        tunnelStateQueue.sync {
            pathMonitor?.cancel()
            pathMonitor = nil
            activeTunnelState = nil
            lastSatisfiedPath = nil
            observedInitialPath = false
            pathWasUnavailable = false
            recoveryIsScheduled = false
            pathChangeCount = 0
            recoveryAttemptCount = 0
            lastReassertAt = nil
        }
        reasserting = false
    }

    override func sleep(completionHandler: @escaping () -> Void) {
        TunnelDiagnostics.markAlive()
        TunnelDiagnostics.record(source: "Tunnel", message: "设备即将休眠，隧道按设置保持运行。")
        completionHandler()
    }

    override func wake() {
        TunnelDiagnostics.record(source: "Tunnel", message: "设备已唤醒，正在确认底层网络状态。")
    }

    private func handleUnderlyingPathUpdate(_ path: Network.NWPath) {
        guard let state = activeTunnelState else { return }
        guard path.status == .satisfied else {
            pathWasUnavailable = observedInitialPath
            return
        }

        let signature = UnderlyingPathSignature(path)
        guard observedInitialPath else {
            observedInitialPath = true
            lastSatisfiedPath = signature
            return
        }

        let hasChangedInterface = lastSatisfiedPath != signature
        lastSatisfiedPath = signature
        if hasChangedInterface {
            pathChangeCount += 1
        }
        let requiresRecovery = pathWasUnavailable || hasChangedInterface
        pathWasUnavailable = false
        guard requiresRecovery, !recoveryIsScheduled else { return }

        if let lastReassertAt,
           Date().timeIntervalSince(lastReassertAt) < Self.minimumReassertInterval {
            TunnelDiagnostics.record(source: "Tunnel", message: "网络在短时间内多次切换，暂缓触发隧道恢复。")
            return
        }
        if Date().timeIntervalSince(recoveryWindowStart) >= Self.recoveryWindowDuration {
            recoveryWindowStart = Date()
            recoveryCountInWindow = 0
        }
        guard recoveryCountInWindow < Self.maximumRecoveriesPerWindow else {
            TunnelDiagnostics.record(
                source: "Tunnel",
                message: "短时间内网络切换过于频繁，已停止自动恢复以避免隧道被系统判定为不稳定。"
            )
            return
        }
        recoveryCountInWindow += 1
        recoveryAttemptCount += 1
        lastReassertAt = Date()
        recoveryIsScheduled = true
        reasserting = true
        TunnelDiagnostics.record(source: "Tunnel", message: "检测到系统网络已切换，正在恢复保护通道。")
        Task { [weak self] in
            await self?.recoverAfterUnderlyingNetworkChange(state)
        }
    }

    private func recoverAfterUnderlyingNetworkChange(_ state: ActiveTunnelState) async {
        defer {
            tunnelStateQueue.async { [weak self] in
                guard let self, self.activeTunnelState?.id == state.id else { return }
                self.recoveryIsScheduled = false
                self.reasserting = false
            }
        }

        guard isActiveTunnelState(state) else { return }
        let remoteAddresses = await resolveProxyAddresses(for: state.remoteHost)
        guard !remoteAddresses.isEmpty else {
            TunnelDiagnostics.record(source: "Tunnel", message: "网络切换后无法解析线路服务器，将重建系统 Tunnel。")
            // The old outbound address is no longer reliable on this path.
            // Let Connect On Demand recreate the provider with a fresh DNS
            // resolution instead of leaving a superficially connected tunnel
            // that cannot carry traffic.
            cancelTunnelWithError(TunnelError.unresolvableTunnelServer)
            return
        }
        let tunnelRemoteAddress = state.optimizedAddress.isEmpty
            ? (remoteAddresses.preferredAddress ?? state.remoteHost)
            : state.optimizedAddress
        let addressFamily = remoteAddresses.ipv6.contains(tunnelRemoteAddress) ? "IPv6" : "IPv4"
        var directAddresses = remoteAddresses.union(await resolveServiceAddresses(for: state.directHosts))
        for address in state.optimizedAddresses { directAddresses.insertIPv4(address) }

        do {
            TunnelDiagnostics.record(
                source: "Tunnel",
                message: "网络切换后线路出口使用 \(addressFamily) 地址：\(tunnelRemoteAddress)。"
            )
            try await applyNetworkSettings(
                tunnelRemoteAddress: tunnelRemoteAddress,
                directAddresses: directAddresses
            )
            guard isActiveTunnelState(state) else { return }
            // An outbound socket opened on the previous Wi-Fi/cellular path
            // cannot reliably survive a handoff. Updating only excluded routes
            // leaves Xray holding that stale socket while iOS still reports the
            // Packet Tunnel as connected, which presents as a permanent loss of
            // traffic. Recreate the in-process data plane without stopping the
            // system Tunnel, so the new network gets a fresh DNS resolution and
            // outbound connection immediately.
            let refreshedConfiguration = state.coreKind == "sing-box"
                ? refreshedSingBoxConfiguration(
                    state.configuration,
                    addresses: remoteAddresses
                )
                : refreshedConfiguration(
                    state.configuration,
                    remoteHost: state.remoteHost,
                    addresses: remoteAddresses,
                    optimizedAddress: state.optimizedAddress
                )
            try restartDataPlane(
                configuration: refreshedConfiguration,
                coreKind: state.coreKind
            )
            TunnelDiagnostics.record(source: "Tunnel", message: "网络切换后已重建保护通道。")
        } catch {
            TunnelDiagnostics.record(
                source: "Tunnel",
                message: "网络切换后更新系统路由失败：\(TunnelDiagnostics.errorSummary(error))"
            )
            cancelTunnelWithError(error)
        }
    }

    private func restartDataPlane(configuration: String, coreKind: String) throws {
        let previousBridge = packetBridge
        packetBridge = nil
        // Close the bridge before stopping Xray so its TUN read loop is woken
        // immediately. This keeps network handoff recovery bounded instead of
        // waiting for the old transport to time out.
        previousBridge?.stopAndClose()
        stopCores()

        if let descriptor = nativePacketFlowDescriptor() ?? nativeTunnelFileDescriptor {
            do {
                try startCore(coreKind: coreKind, configuration: configuration, descriptor: descriptor)
                nativeTunnelFileDescriptor = descriptor
                TunnelDiagnostics.record(source: "Tunnel", message: "网络切换后已重建 \(coreKind) 原生 TUN 数据通道。")
                return
            } catch {
                TunnelDiagnostics.record(
                    source: "Tunnel",
                    message: "原生 TUN 重建失败，正在回退到兼容数据通道：\(TunnelDiagnostics.errorSummary(error))"
                )
                stopCores()
                self.nativeTunnelFileDescriptor = nil
            }
        }

        let bridge = try PacketFlowBridge(packetFlow: packetFlow)
        bridge.start()
        do {
            try startCore(
                coreKind: coreKind,
                configuration: configuration,
                descriptor: bridge.tunnelFileDescriptor
            )
            packetBridge = bridge
        } catch {
            bridge.stopAndClose()
            throw error
        }
    }

    private func startDataPlane(configuration: String, coreKind: String) throws -> Int32 {
        if let descriptor = nativePacketFlowDescriptor() {
            do {
                try startCore(coreKind: coreKind, configuration: configuration, descriptor: descriptor)
                nativeTunnelFileDescriptor = descriptor
                TunnelDiagnostics.record(source: "Tunnel", message: "已启用 \(coreKind) 原生 TUN 快速数据通道。")
                return descriptor
            } catch {
                TunnelDiagnostics.record(
                    source: "Tunnel",
                    message: "原生 TUN 启动失败，正在回退到兼容数据通道：\(TunnelDiagnostics.errorSummary(error))"
                )
                stopCores()
            }
        }

        let bridge = try PacketFlowBridge(packetFlow: packetFlow)
        bridge.start()
        do {
            try startCore(
                coreKind: coreKind,
                configuration: configuration,
                descriptor: bridge.tunnelFileDescriptor
            )
            packetBridge = bridge
            TunnelDiagnostics.record(source: "Tunnel", message: "已启用 \(coreKind) 兼容 Packet Flow 数据通道。")
            return bridge.tunnelFileDescriptor
        } catch {
            bridge.stopAndClose()
            throw error
        }
    }

    private func startCore(coreKind: String, configuration: String, descriptor: Int32) throws {
#if SEWER_XRAY_TUNNEL
        guard coreKind == "xray" else {
            throw TunnelError.missingConfiguration
        }
        try XrayEngine.start(
            configurationJSON: configuration,
            tunnelFileDescriptor: descriptor
        )
#elseif SEWER_SINGBOX_TUNNEL
        guard coreKind == "sing-box" else {
            throw TunnelError.missingConfiguration
        }
        try SingBoxEngine.start(
            configurationJSON: configuration,
            tunnelFileDescriptor: descriptor
        )
#endif
    }

    private func stopCores() {
#if SEWER_XRAY_TUNNEL
        XrayEngine.stop()
#elseif SEWER_SINGBOX_TUNNEL
        SingBoxEngine.stop()
#endif
    }

    private func nativePacketFlowDescriptor() -> Int32? {
        // The Packet Tunnel owns an AF_SYSTEM utun descriptor in this process.
        // Passing that descriptor directly to Xray avoids copying every packet
        // through NEPacketTunnelFlow callbacks and a second userspace bridge.
        // If iOS does not expose the descriptor, the public Packet Flow bridge
        // remains the automatic fallback.
        for descriptor: Int32 in 0...1_024 where isUtunFileDescriptor(descriptor) {
            return descriptor
        }
        return nil
    }

    private func isUtunFileDescriptor(_ descriptor: Int32) -> Bool {
        guard descriptor >= 0, fcntl(descriptor, F_GETFL, 0) >= 0 else { return false }
        var buffer = [CChar](repeating: 0, count: Int(IFNAMSIZ))
        var length = socklen_t(buffer.count)
        let result = buffer.withUnsafeMutableBytes { rawBuffer in
            getsockopt(
                descriptor,
                2, // SYSPROTO_CONTROL
                2, // UTUN_OPT_IFNAME
                rawBuffer.baseAddress,
                &length
            )
        }
        return result == 0 && length > 0 && String(cString: buffer).hasPrefix("utun")
    }

    private func refreshedConfiguration(
        _ configuration: String,
        remoteHost: String,
        addresses: TunnelAddresses,
        optimizedAddress: String = ""
    ) -> String {
        guard let dialAddress = optimizedAddress.isEmpty ? addresses.preferredAddress : optimizedAddress,
              let data = configuration.data(using: .utf8),
              var root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              var outbounds = root["outbounds"] as? [[String: Any]],
              let proxyIndex = outbounds.firstIndex(where: { $0["tag"] as? String == "proxy" }) else {
            return configuration
        }

        var proxy = outbounds[proxyIndex]
        if var settings = proxy["settings"] as? [String: Any] {
            if var vnext = settings["vnext"] as? [[String: Any]], !vnext.isEmpty {
                vnext[0]["address"] = dialAddress
                settings["vnext"] = vnext
            } else if var servers = settings["servers"] as? [[String: Any]], !servers.isEmpty {
                servers[0]["address"] = dialAddress
                settings["servers"] = servers
            }
            proxy["settings"] = settings
            outbounds[proxyIndex] = proxy
            root["outbounds"] = outbounds
        }

        if var dns = root["dns"] as? [String: Any] {
            var hosts = dns["hosts"] as? [String: Any] ?? [:]
            hosts[remoteHost] = addresses.ordered
            dns["hosts"] = hosts
            root["dns"] = dns
        }

        guard let refreshed = try? JSONSerialization.data(withJSONObject: root, options: [.sortedKeys]),
              let json = String(data: refreshed, encoding: .utf8) else {
            return configuration
        }
        return json
    }

    private func refreshedSingBoxConfiguration(
        _ configuration: String,
        addresses: TunnelAddresses
    ) -> String {
        guard !addresses.ordered.isEmpty,
              let data = configuration.data(using: .utf8),
              var root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let outbounds = root["outbounds"] as? [[String: Any]],
              let proxyIndex = outbounds.firstIndex(where: { $0["tag"] as? String == "proxy" }),
              let remoteHost = outbounds[proxyIndex]["server"] as? String,
              !remoteHost.isEmpty else {
            return configuration
        }
        // Preserve the subscribed hostname for SOCKS authentication semantics,
        // Shadowsocks SIP003 TLS/SNI, and future domain-specific routing. The
        // resolved address set is injected into sing-box's DNS hosts table, so
        // no local resolver query is needed after a Wi-Fi/cellular handoff.
        var dns = root["dns"] as? [String: Any] ?? [:]
        var dnsServers = dns["servers"] as? [[String: Any]] ?? []
        let pinnedAddresses: [String] = addresses.ordered
        if let hostServerIndex = dnsServers.firstIndex(where: { $0["type"] as? String == "hosts" }) {
            var hostServer = dnsServers[hostServerIndex]
            hostServer["predefined"] = [remoteHost: pinnedAddresses]
            dnsServers[hostServerIndex] = hostServer
        } else {
            dnsServers.append([
                "type": "hosts",
                "tag": "pinned-hosts",
                "path": [],
                "predefined": [remoteHost: pinnedAddresses]
            ])
        }
        var dnsRules = dns["rules"] as? [[String: Any]] ?? []
        if !dnsRules.contains(where: {
            ($0["server"] as? String) == "pinned-hosts"
                && ($0["domain"] as? [String])?.contains(remoteHost) == true
        }) {
            dnsRules.append([
                "domain": [remoteHost],
                "server": "pinned-hosts"
            ])
        }
        dns["servers"] = dnsServers
        dns["rules"] = dnsRules
        dns.removeValue(forKey: "hosts")
        root["dns"] = dns
        guard let refreshed = try? JSONSerialization.data(withJSONObject: root, options: [.sortedKeys]),
              let json = String(data: refreshed, encoding: .utf8) else {
            return configuration
        }
        return json
    }

    private func isActiveTunnelState(_ state: ActiveTunnelState) -> Bool {
        tunnelStateQueue.sync {
            activeTunnelState?.id == state.id
        }
    }

    private func applyNetworkSettings(
        tunnelRemoteAddress: String,
        directAddresses: TunnelAddresses
    ) async throws {
        let settings = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: tunnelRemoteAddress)
        // The Packet Tunnel carries protected traffic. A /32 route is retained
        // for the selected upstream and SEWER service hosts so sockets opened
        // by the extension itself do not recurse back into packetFlow.
        let ipv4 = NEIPv4Settings(addresses: ["10.254.0.2"], subnetMasks: ["255.255.255.0"])
        ipv4.includedRoutes = [NEIPv4Route.default()]
        ipv4.excludedRoutes = directAddresses.ipv4.sorted().map {
            NEIPv4Route(destinationAddress: $0, subnetMask: "255.255.255.255")
        }
        settings.ipv4Settings = ipv4
        // The device uses Cloudflare DNS only after the Packet Tunnel route is
        // active. Unlike the bootstrap resolvers, this destination has no
        // excluded route, so its requests are forwarded through the selected
        // protected route rather than from the device's physical network.
        let dnsServers = Self.protectedDNSIPv4
        let dns = NEDNSSettings(servers: dnsServers)
        dns.matchDomains = [""]
        settings.dnsSettings = dns
        settings.mtu = 1_500

        // Without an explicit IPv6 default route, IPv6-capable networks can
        // bypass the Packet Tunnel even while IPv4 traffic is protected.
        let ipv6 = NEIPv6Settings(
            addresses: ["fd00:254::2"],
            networkPrefixLengths: [NSNumber(value: 64)]
        )
        ipv6.includedRoutes = [NEIPv6Route.default()]
        ipv6.excludedRoutes = (directAddresses.ipv6.union(Self.bootstrapDNSIPv6)).sorted().map {
            NEIPv6Route(destinationAddress: $0, networkPrefixLength: NSNumber(value: 128))
        }
        settings.ipv6Settings = ipv6

        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            setTunnelNetworkSettings(settings) { error in
                if let error {
                    continuation.resume(throwing: error)
                } else {
                    continuation.resume()
                }
            }
        }
    }

    private func resolveAddresses(for hosts: [String]) -> TunnelAddresses {
        var addresses = TunnelAddresses()
        var seenHosts = Set<String>()
        for host in hosts where seenHosts.insert(host).inserted {
            var hints = addrinfo(
                ai_flags: AI_ADDRCONFIG,
                ai_family: AF_UNSPEC,
                ai_socktype: 0,
                ai_protocol: 0,
                ai_addrlen: 0,
                ai_canonname: nil,
                ai_addr: nil,
                ai_next: nil
            )
            var results: UnsafeMutablePointer<addrinfo>?
            guard getaddrinfo(host, nil, &hints, &results) == 0, let firstResult = results else { continue }
            defer { freeaddrinfo(firstResult) }

            var result: UnsafeMutablePointer<addrinfo>? = firstResult
            while let current = result {
                var numericHost = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                let status = getnameinfo(
                    current.pointee.ai_addr,
                    current.pointee.ai_addrlen,
                    &numericHost,
                    socklen_t(numericHost.count),
                    nil,
                    0,
                    NI_NUMERICHOST
                )
                if status == 0 {
                    let address = String(cString: numericHost)
                    switch current.pointee.ai_family {
                    case AF_INET: addresses.insertIPv4(address)
                    case AF_INET6: addresses.insertIPv6(address)
                    default: break
                    }
                }
                result = current.pointee.ai_next
            }
        }
        return addresses
    }

    private func resolveProxyAddresses(for host: String) async -> TunnelAddresses {
        // Resolve bootstrap hosts through DoH before the default tunnel route
        // exists. Plain DNS is a fallback only when every DoH endpoint fails.
        var addresses = TunnelAddresses()
        if SewerBootstrapResolver.isProtectedHostname(host),
           let values = try? await SewerBootstrapResolver.shared.resolveIPv4(host) {
            for value in values { addresses.insertIPv4(value) }
        }
        if addresses.isEmpty {
            addresses = resolveAddresses(for: [host])
        }
        return addresses
    }

    private func resolveServiceAddresses(for hosts: [String]) async -> TunnelAddresses {
        var addresses = TunnelAddresses()
        for host in Set(hosts) {
            if SewerBootstrapResolver.isProtectedHostname(host),
               let values = try? await SewerBootstrapResolver.shared.resolveIPv4(host) {
                for value in values { addresses.insertIPv4(value) }
            } else {
                addresses = addresses.union(resolveAddresses(for: [host]))
            }
        }
        return addresses
    }

    private func resolveIPv4ThroughBootstrapDNS(for host: String) -> TunnelAddresses {
        var resolvedAddresses = TunnelAddresses()
        for server in Self.bootstrapDNSIPv4 {
            guard let response = performDNSQuery(host: host, type: 1, serverAddress: server),
                  response.count >= 12 else {
                continue
            }

            var offset = 0
            guard readDNSUInt16(response, offset: &offset) != nil,
                  let flags = readDNSUInt16(response, offset: &offset),
                  let questionCount = readDNSUInt16(response, offset: &offset),
                  let answerCount = readDNSUInt16(response, offset: &offset),
                  readDNSUInt16(response, offset: &offset) != nil,
                  readDNSUInt16(response, offset: &offset) != nil,
                  flags & 0x000F == 0 else {
                continue
            }

            var questionSectionIsValid = true
            for _ in 0..<questionCount {
                guard skipDNSName(response, offset: &offset), offset + 4 <= response.count else {
                    questionSectionIsValid = false
                    break
                }
                offset += 4
            }
            guard questionSectionIsValid else { continue }

            var addresses = TunnelAddresses()
            for _ in 0..<answerCount {
                guard skipDNSName(response, offset: &offset),
                      let recordType = readDNSUInt16(response, offset: &offset),
                      let recordClass = readDNSUInt16(response, offset: &offset),
                      offset + 6 <= response.count else {
                    break
                }
                offset += 4 // TTL
                guard let recordLength = readDNSUInt16(response, offset: &offset),
                      offset + Int(recordLength) <= response.count else {
                    break
                }
                if recordType == 1, recordClass == 1, recordLength == 4 {
                    let octets = response[offset..<(offset + 4)]
                    addresses.insertIPv4(octets.map(String.init).joined(separator: "."))
                }
                offset += Int(recordLength)
            }
            resolvedAddresses = resolvedAddresses.union(addresses)
        }

        return resolvedAddresses
    }

    private func performDNSQuery(host: String, type: UInt16, serverAddress: String) -> Data? {
        var query = Data()
        let identifier = UInt16.random(in: .min ... .max)
        appendDNSUInt16(identifier, to: &query)
        appendDNSUInt16(0x0100, to: &query) // Recursion desired.
        appendDNSUInt16(1, to: &query)
        appendDNSUInt16(0, to: &query)
        appendDNSUInt16(0, to: &query)
        appendDNSUInt16(0, to: &query)
        for label in host.split(separator: ".") {
            guard label.utf8.count <= 63 else { return nil }
            query.append(UInt8(label.utf8.count))
            query.append(contentsOf: label.utf8)
        }
        query.append(0)
        appendDNSUInt16(type, to: &query)
        appendDNSUInt16(1, to: &query)

        let descriptor = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)
        guard descriptor >= 0 else { return nil }
        defer { close(descriptor) }

        var timeout = timeval(tv_sec: 1, tv_usec: 0)
        _ = withUnsafePointer(to: &timeout) {
            setsockopt(
                descriptor,
                SOL_SOCKET,
                SO_RCVTIMEO,
                $0,
                socklen_t(MemoryLayout<timeval>.size)
            )
        }
        var server = sockaddr_in()
        server.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        server.sin_family = sa_family_t(AF_INET)
        server.sin_port = in_port_t(53).bigEndian
        guard serverAddress.withCString({ inet_pton(AF_INET, $0, &server.sin_addr) }) == 1 else {
            return nil
        }
        let connected = withUnsafePointer(to: &server) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                connect(descriptor, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard connected == 0 else { return nil }
        let sent = query.withUnsafeBytes { bytes in
            send(descriptor, bytes.baseAddress, bytes.count, 0)
        }
        guard sent == query.count else { return nil }

        var buffer = [UInt8](repeating: 0, count: 4_096)
        let received = recv(descriptor, &buffer, buffer.count, 0)
        guard received >= 12 else { return nil }
        let response = Data(buffer.prefix(Int(received)))
        var responseOffset = 0
        guard readDNSUInt16(response, offset: &responseOffset) == identifier else { return nil }
        return response
    }

    private func appendDNSUInt16(_ value: UInt16, to data: inout Data) {
        data.append(UInt8(value >> 8))
        data.append(UInt8(truncatingIfNeeded: value))
    }

    private func readDNSUInt16(_ data: Data, offset: inout Int) -> UInt16? {
        guard offset + 2 <= data.count else { return nil }
        let value = UInt16(data[offset]) << 8 | UInt16(data[offset + 1])
        offset += 2
        return value
    }

    private func skipDNSName(_ data: Data, offset: inout Int) -> Bool {
        while offset < data.count {
            let length = data[offset]
            if length & 0xC0 == 0xC0 {
                guard offset + 2 <= data.count else { return false }
                offset += 2
                return true
            }
            if length == 0 {
                offset += 1
                return true
            }
            guard length & 0xC0 == 0,
                  offset + 1 + Int(length) <= data.count else {
                return false
            }
            offset += 1 + Int(length)
        }
        return false
    }

    private func stopReasonDescription(_ reason: NEProviderStopReason) -> String {
        switch reason.rawValue {
        case 0: return "未指定"
        case 1: return "用户主动断开"
        case 2: return "Tunnel 提供方失败"
        case 3: return "系统无可用网络"
        case 4: return "网络切换不可恢复"
        case 5: return "Tunnel 提供方已被禁用"
        case 6: return "认证已取消"
        case 7: return "配置失败"
        case 8: return "空闲超时"
        case 9: return "配置已被禁用"
        case 10: return "配置已被移除"
        case 11: return "被更高优先级网络配置取代"
        case 12: return "用户已退出系统账户"
        case 13: return "系统用户已切换"
        case 14: return "连接建立失败"
        case 15: return "设备休眠"
        case 16: return "应用正在更新"
        case 17: return "Network Extension 内部错误"
        default: return "未知系统原因（代码 \(reason.rawValue)）"
        }
    }

    private func clearStartFailure() {
        UserDefaults(suiteName: Self.diagnosticsSuiteName)?.removeObject(forKey: Self.diagnosticsKey)
    }

    private func recordStartFailure(stage: String, error: Error) {
        let message = "\(stage)失败：\(TunnelDiagnostics.errorSummary(error))"
        TunnelDiagnostics.record(source: "Tunnel", message: message)
        UserDefaults(suiteName: Self.diagnosticsSuiteName)?.set(message, forKey: Self.diagnosticsKey)
    }

    private func startHeartbeat() {
        let timer = DispatchSource.makeTimerSource(queue: tunnelStateQueue)
        timer.schedule(deadline: .now() + 30, repeating: 30)
        timer.setEventHandler { [weak self] in
            guard let self else { return }
            TunnelDiagnostics.markAlive()
            let coreKind = self.activeTunnelState?.coreKind ?? "xray"
            let coreIsRunning: Bool
#if SEWER_XRAY_TUNNEL
            coreIsRunning = XrayEngine.isRunning()
#elseif SEWER_SINGBOX_TUNNEL
            coreIsRunning = SingBoxEngine.isRunning()
#else
            coreIsRunning = false
#endif
            guard coreIsRunning else {
                TunnelDiagnostics.record(
                    source: "Tunnel",
                    message: "\(coreKind) 核心已停止运行，正在重建保护通道。"
                )
                self.cancelTunnelWithError(NSError(
                    domain: "top.sewer.client.ios.core",
                    code: 10,
                    userInfo: [NSLocalizedDescriptionKey: "网络核心意外停止。"]
                ))
                return
            }
            let now = Date()
            if now.timeIntervalSince(self.lastRuntimeStatusRecordedAt) >= 300 {
                self.lastRuntimeStatusRecordedAt = now
                TunnelDiagnostics.record(
                    source: "Tunnel",
                    message: "运行中：内存 \(TunnelDiagnostics.memoryFootprintDescription())。"
                )
            }
        }
        heartbeatTimer = timer
        timer.resume()
    }

    private func stopHeartbeat() {
        heartbeatTimer?.cancel()
        heartbeatTimer = nil
    }
}

private struct TunnelAddresses {
    var ipv4: Set<String> = []
    var ipv6: Set<String> = []
    private(set) var ordered: [String] = []

    var isEmpty: Bool {
        ipv4.isEmpty && ipv6.isEmpty
    }

    var preferredAddress: String? {
        // Cellular networks commonly publish IPv6 answers ahead of IPv4, but
        // CDN IPv6 paths are not consistently usable across carriers. Prefer a
        // public IPv4 endpoint for the actual upstream socket, then IPv6. Keep
        // the full address set in excluded routes so either family can still be
        // used by services that need it.
        if let publicIPv4 = ordered.first(where: { ipv4.contains($0) && !isBenchmarkIPv4($0) }) {
            return publicIPv4
        }
        if let ipv6Address = ordered.first(where: { ipv6.contains($0) }) {
            return ipv6Address
        }
        return ordered.first
    }

    mutating func insertIPv4(_ address: String) {
        guard ipv4.insert(address).inserted else { return }
        ordered.append(address)
    }

    mutating func insertIPv6(_ address: String) {
        guard ipv6.insert(address).inserted else { return }
        ordered.append(address)
    }

    func union(_ other: TunnelAddresses) -> TunnelAddresses {
        var result = TunnelAddresses()
        for address in ordered {
            if ipv4.contains(address) {
                result.insertIPv4(address)
            } else {
                result.insertIPv6(address)
            }
        }
        for address in other.ordered {
            if other.ipv4.contains(address) {
                result.insertIPv4(address)
            } else {
                result.insertIPv6(address)
            }
        }
        return result
    }

    private func isBenchmarkIPv4(_ address: String) -> Bool {
        let octets = address.split(separator: ".")
        guard octets.count == 4,
              let first = Int(octets[0]),
              let second = Int(octets[1]) else {
            return false
        }
        // RFC 2544 reserves 198.18.0.0/15 for network benchmarks, not public
        // Internet services. Some fake-IP DNS implementations return it.
        return first == 198 && (second == 18 || second == 19)
    }
}

private struct ActiveTunnelState {
    let id: UUID
    let configuration: String
    let remoteHost: String
    let directHosts: [String]
    let optimizedAddress: String
    let optimizedAddresses: [String]
    let tunnelFileDescriptor: Int32
    let coreKind: String
}

private struct UnderlyingPathSignature: Equatable {
    let usesWiFi: Bool
    let usesCellular: Bool
    let usesWiredEthernet: Bool
    let usesOther: Bool
    let gateways: [String]
    let interfaces: [String]
    let isExpensive: Bool
    let isConstrained: Bool

    init(_ path: Network.NWPath) {
        usesWiFi = path.usesInterfaceType(.wifi)
        usesCellular = path.usesInterfaceType(.cellular)
        usesWiredEthernet = path.usesInterfaceType(.wiredEthernet)
        usesOther = path.usesInterfaceType(.other)
        // A move between two Wi-Fi networks often remains "satisfied" and uses
        // the same interface type. Gateway and interface changes expose those
        // handoffs so the core can refresh its outbound socket.
        gateways = path.gateways.map(String.init(describing:)).sorted()
        interfaces = path.availableInterfaces.map(\.name).sorted()
        isExpensive = path.isExpensive
        isConstrained = path.isConstrained
    }
}
