import Foundation
import LibboxSlim
import Network
import NetworkExtension

final class SingBoxPlatformInterface: NSObject,
    LibboxPlatformInterfaceProtocol,
    LibboxCommandServerHandlerProtocol
{
    private let tunnelFileDescriptor: Int32
    private let interfaceMonitorQueue = DispatchQueue(label: "top.sewer.client.ios.sing-box.interface-monitor")
    private let interfaceMonitorLock = NSLock()
    private var pathMonitor: NWPathMonitor?
    private weak var interfaceListener: LibboxInterfaceUpdateListenerProtocol?
    private var lastInterfaceSignature: String?

    init(tunnelFileDescriptor: Int32) {
        self.tunnelFileDescriptor = tunnelFileDescriptor
    }

    func openTun(_ options: LibboxTunOptionsProtocol?, ret0_: UnsafeMutablePointer<Int32>?) throws {
        guard ret0_ != nil else {
            throw NSError(domain: "top.sewer.client.ios.sing-box", code: 1)
        }
        ret0_!.pointee = tunnelFileDescriptor
        TunnelDiagnostics.record(source: "sing-box", message: "系统 TUN 描述符已交付内核。")
    }

    func usePlatformAutoDetectControl() -> Bool { false }
    func autoDetectControl(_ fd: Int32) throws {}
    func useProcFS() -> Bool { false }
    func underNetworkExtension() -> Bool { true }
    func includeAllNetworks() -> Bool { false }
    func clearDNSCache() {}
    func localDNSTransport() -> LibboxLocalDNSTransportProtocol? { nil }
    func systemCertificates() -> LibboxStringIteratorProtocol? { nil }
    func readWIFIState() -> LibboxWIFIState? { nil }

    func startDefaultInterfaceMonitor(_ listener: LibboxInterfaceUpdateListenerProtocol?) throws {
        guard let listener else { return }
        let monitor = NWPathMonitor()
        interfaceMonitorLock.lock()
        pathMonitor?.cancel()
        pathMonitor = monitor
        interfaceListener = listener
        lastInterfaceSignature = nil
        interfaceMonitorLock.unlock()

        // Give sing-box one initial path snapshot before outbound sockets are
        // created. Subsequent Wi-Fi/cellular changes are delivered by the same
        // monitor and are also coordinated by PacketTunnelProvider.
        let firstPath = OneShotSignal()
        monitor.pathUpdateHandler = { [weak self, weak listener] path in
            if let self, let listener {
                self.updateDefaultInterface(listener, path: path)
            }
            firstPath.signal()
        }
        monitor.start(queue: interfaceMonitorQueue)
        firstPath.wait(timeout: .now() + 2)
    }

    func closeDefaultInterfaceMonitor(_ listener: LibboxInterfaceUpdateListenerProtocol?) throws {
        interfaceMonitorLock.lock()
        pathMonitor?.cancel()
        pathMonitor = nil
        interfaceListener = nil
        lastInterfaceSignature = nil
        interfaceMonitorLock.unlock()
    }

    func getInterfaces() throws -> LibboxNetworkInterfaceIteratorProtocol {
        interfaceMonitorLock.lock()
        let monitor = pathMonitor
        interfaceMonitorLock.unlock()
        guard let path = monitor?.currentPath, path.status == .satisfied else {
            return NetworkInterfaceIterator([])
        }

        let interfaces = path.availableInterfaces.map { pathInterface -> LibboxNetworkInterface in
            let interface = LibboxNetworkInterface()
            interface.name = pathInterface.name
            interface.index = Int32(pathInterface.index)
            switch pathInterface.type {
            case .wifi:
                interface.type = LibboxInterfaceTypeWIFI
            case .cellular:
                interface.type = LibboxInterfaceTypeCellular
            case .wiredEthernet:
                interface.type = LibboxInterfaceTypeEthernet
            default:
                interface.type = LibboxInterfaceTypeOther
            }
            interface.metered = path.isExpensive
            return interface
        }
        return NetworkInterfaceIterator(interfaces)
    }

    func findConnectionOwner(
        _ ipProtocol: Int32,
        sourceAddress: String?,
        sourcePort: Int32,
        destinationAddress: String?,
        destinationPort: Int32
    ) throws -> LibboxConnectionOwner {
        throw NSError(domain: "top.sewer.client.ios.sing-box", code: 2)
    }

    func send(_ notification: LibboxNotification?) throws {}

    func getSystemProxyStatus() throws -> LibboxSystemProxyStatus {
        LibboxSystemProxyStatus()
    }

    func serviceReload() throws {}
    func serviceStop() throws {}
    func setSystemProxyEnabled(_ isEnabled: Bool) throws {}

    func writeDebugMessage(_ message: String?) {
        if let message, !message.isEmpty {
            TunnelDiagnostics.record(source: "sing-box", message: message)
        }
    }

    private func updateDefaultInterface(
        _ listener: LibboxInterfaceUpdateListenerProtocol,
        path: Network.NWPath
    ) {
        let defaultInterface = path.status == .satisfied ? path.availableInterfaces.first : nil
        let interfaceName = defaultInterface?.name ?? ""
        let interfaceIndex = defaultInterface.map { Int32($0.index) } ?? -1
        let signature = [
            path.status == .satisfied ? "satisfied" : "unavailable",
            interfaceName,
            String(interfaceIndex),
            path.isExpensive ? "expensive" : "standard",
            path.isConstrained ? "constrained" : "unconstrained"
        ].joined(separator: "|")

        interfaceMonitorLock.lock()
        let changed = signature != lastInterfaceSignature
        if changed { lastInterfaceSignature = signature }
        interfaceMonitorLock.unlock()
        guard changed else { return }

        listener.updateDefaultInterface(
            interfaceName,
            interfaceIndex: interfaceIndex,
            isExpensive: path.isExpensive,
            isConstrained: path.isConstrained
        )
        if !interfaceName.isEmpty {
            TunnelDiagnostics.record(
                source: "sing-box",
                message: "默认网络接口已更新为 \(interfaceName)（#\(interfaceIndex)）。"
            )
        }
    }
}

private final class NetworkInterfaceIterator: NSObject, LibboxNetworkInterfaceIteratorProtocol {
    private let interfaces: [LibboxNetworkInterface]
    private var index = 0

    init(_ interfaces: [LibboxNetworkInterface]) {
        self.interfaces = interfaces
    }

    func hasNext() -> Bool {
        index < interfaces.count
    }

    func next() -> LibboxNetworkInterface? {
        guard hasNext() else { return nil }
        defer { index += 1 }
        return interfaces[index]
    }
}

private final class OneShotSignal: @unchecked Sendable {
    private let lock = NSLock()
    private let semaphore = DispatchSemaphore(value: 0)
    private var didSignal = false

    func signal() {
        lock.lock()
        guard !didSignal else {
            lock.unlock()
            return
        }
        didSignal = true
        lock.unlock()
        semaphore.signal()
    }

    func wait(timeout: DispatchTime) {
        _ = semaphore.wait(timeout: timeout)
    }
}
