import Foundation
import LibboxSlim

enum SingBoxEngine {
    private static let lifecycleLock = NSLock()
    private static var commandServer: LibboxCommandServer?
    private static var platformInterface: SingBoxPlatformInterface?
    private static var isSetup = false

    static func start(configurationJSON: String, tunnelFileDescriptor: Int32) throws {
        lifecycleLock.lock()
        defer { lifecycleLock.unlock() }
        guard !configurationJSON.isEmpty else {
            throw NSError(domain: "top.sewer.client.ios.sing-box", code: 10)
        }
        guard commandServer == nil else {
            throw NSError(domain: "top.sewer.client.ios.sing-box", code: 11)
        }

        if !isSetup {
            let basePath = FileManager.default.containerURL(
                forSecurityApplicationGroupIdentifier: "group.top.sewer.client.ios"
            )?.path ?? NSTemporaryDirectory()
            let workingPath = (basePath as NSString).appendingPathComponent("SingBoxRuntime")
            let options = LibboxSetupOptions()
            options.basePath = basePath
            options.workingPath = workingPath
            options.tempPath = NSTemporaryDirectory()
            options.logMaxLines = 300
            options.debug = false
            var setupError: NSError?
            LibboxSetup(options, &setupError)
            if let setupError { throw setupError }
            isSetup = true
        }

        let platform = SingBoxPlatformInterface(tunnelFileDescriptor: tunnelFileDescriptor)
        var serverError: NSError?
        guard let server = LibboxNewCommandServer(platform, platform, &serverError) else {
            throw serverError ?? NSError(domain: "top.sewer.client.ios.sing-box", code: 12)
        }
        do {
            try server.start()
            try server.startOrReloadService(configurationJSON, options: LibboxOverrideOptions())
        } catch {
            server.close()
            throw error
        }
        platformInterface = platform
        commandServer = server
        TunnelDiagnostics.record(source: "sing-box", message: "sing-box 核心已启动。")
    }

    static func stop() {
        lifecycleLock.lock()
        defer { lifecycleLock.unlock() }
        guard let server = commandServer else { return }
        do {
            try server.closeService()
        } catch {
            TunnelDiagnostics.record(
                source: "sing-box",
                message: "sing-box 停止服务失败：\(TunnelDiagnostics.errorSummary(error))"
            )
        }
        server.close()
        commandServer = nil
        platformInterface = nil
    }

    static func isRunning() -> Bool {
        lifecycleLock.lock()
        defer { lifecycleLock.unlock() }
        return commandServer != nil
    }
}
