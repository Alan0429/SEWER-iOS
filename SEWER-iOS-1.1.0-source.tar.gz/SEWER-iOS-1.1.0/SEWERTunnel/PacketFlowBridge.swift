import Darwin
import Foundation
import NetworkExtension

enum PacketFlowBridgeError: LocalizedError {
    case socketPairUnavailable(Int32)

    var errorDescription: String? {
        switch self {
        case let .socketPairUnavailable(code):
            return "无法建立本地数据转发通道（代码 \(code)）。"
        }
    }
}

// Bridges the public NEPacketTunnelFlow API to Xray's Darwin TUN adapter.
// The datagram socket preserves one IP packet per read/write, while the first
// four bytes follow the public utun packet-family framing Xray already uses.
final class PacketFlowBridge {
    private let packetFlow: NEPacketTunnelFlow
    private let queue = DispatchQueue(label: "top.sewer.client.ios.packet-flow")
    private let descriptorLock = NSLock()
    private let xrayDescriptor: Int32
    private let flowDescriptor: Int32
    private var descriptorsClosed = false
    private var isRunning = false
    private var outputSource: DispatchSourceRead?
    private var pendingFrameRetryTimer: DispatchSourceTimer?
    private var pendingPackets: [PacketToXray] = []
    private var pendingPacketCursor = 0
    private var pendingFrameBytes = 0
    private var packetsFromSystem = 0
    private var packetsToSystem = 0
    private var bytesFromSystem = 0
    private var bytesToSystem = 0
    private var droppedPacketsFromSystem = 0
    private var hasRecordedSystemPacket = false
    private var hasRecordedXrayPacket = false
    private var hasRecordedSendFailure = false

    private let maximumPendingFrames = 1_024
    private let maximumPendingBytes = 4 * 1_024 * 1_024
    private let maximumPacketsPerOutputDrain = 1_024

    init(packetFlow: NEPacketTunnelFlow) throws {
        self.packetFlow = packetFlow
        var descriptors: [Int32] = [0, 0]
        guard socketpair(AF_UNIX, SOCK_DGRAM, 0, &descriptors) == 0 else {
            throw PacketFlowBridgeError.socketPairUnavailable(errno)
        }
        xrayDescriptor = descriptors[0]
        flowDescriptor = descriptors[1]
        configureSocketBuffers()
    }

    deinit {
        closeDescriptors()
    }

    func start() {
        queue.sync {
            guard !isRunning else { return }
            isRunning = true
            let source = DispatchSource.makeReadSource(fileDescriptor: flowDescriptor, queue: queue)
            source.setEventHandler { [weak self] in
                self?.forwardPacketsFromXray()
            }
            outputSource = source
            source.resume()
            requestPacketsFromSystem()
        }
    }

    func stop() {
        queue.sync {
            stopLocked()
        }
    }

    // Closing the descriptor makes Xray's non-blocking TUN reader return
    // immediately. This prevents its dispatcher from delaying the Network
    // Extension stop callback while it waits for more packets.
    func stopAndClose() {
        queue.sync {
            stopLocked()
        }
        closeDescriptors()
    }

    var tunnelFileDescriptor: Int32 {
        xrayDescriptor
    }

    private func requestPacketsFromSystem() {
        guard isRunning else { return }
        packetFlow.readPackets { [weak self] packets, protocols in
            guard let self else { return }
            self.queue.async {
                guard self.isRunning else { return }
                for (packet, protocolFamily) in zip(packets, protocols) {
                    self.forwardPacketToXray(packet, protocolFamily: protocolFamily.int32Value)
                }
                self.requestPacketsFromSystem()
            }
        }
    }

    private func forwardPacketToXray(_ packet: Data, protocolFamily: Int32) {
        guard !packet.isEmpty else { return }
        let framedPacket = PacketToXray(protocolFamily: protocolFamily, payload: packet)

        // Preserve packet order while a previous packet is waiting for Xray's
        // local datagram socket to become writable again.
        if !pendingPackets.isEmpty {
            enqueuePendingPacket(framedPacket)
            flushPendingFrames()
            schedulePendingFrameRetryIfNeeded()
        } else {
            switch sendPacketToXray(framedPacket) {
            case .sent:
                break
            case .backpressured:
                enqueuePendingPacket(framedPacket)
                schedulePendingFrameRetryIfNeeded()
            case let .failed(code):
                recordSendFailureIfNeeded(code: code)
                return
            }
        }
        packetsFromSystem += 1
        bytesFromSystem += packet.count
        if !hasRecordedSystemPacket {
            hasRecordedSystemPacket = true
            TunnelDiagnostics.record(source: "Tunnel", message: "已收到系统 IP 流量，正在交给核心处理。")
        }
    }

    private func forwardPacketsFromXray() {
        var buffer = [UInt8](repeating: 0, count: 65_535)
        var outputPackets: [Data] = []
        var outputProtocols: [NSNumber] = []
        outputPackets.reserveCapacity(maximumPacketsPerOutputDrain)
        outputProtocols.reserveCapacity(maximumPacketsPerOutputDrain)
        // Keep this handler bounded. The same serial queue also receives
        // packetFlow callbacks, and an unbounded stream of download packets
        // could otherwise prevent new requests from reaching Xray.
        var processedPackets = 0
        while isRunning, processedPackets < maximumPacketsPerOutputDrain {
            let count = recv(flowDescriptor, &buffer, buffer.count, MSG_DONTWAIT)
            guard count > 4 else { break }
            processedPackets += 1
            let packetLength = Int(count)
            let protocolFamily = Int32(buffer[3])
            guard protocolFamily == AF_INET || protocolFamily == AF_INET6 else { continue }
            let packet = Data(buffer[4..<packetLength])
            outputPackets.append(packet)
            outputProtocols.append(NSNumber(value: protocolFamily))
            packetsToSystem += 1
            bytesToSystem += packet.count
            if !hasRecordedXrayPacket {
                hasRecordedXrayPacket = true
                TunnelDiagnostics.record(source: "Tunnel", message: "核心已向系统回写 IP 流量。")
            }
        }
        if !outputPackets.isEmpty {
            packetFlow.writePackets(outputPackets, withProtocols: outputProtocols)
        }
        // DispatchSourceRead does not guarantee another callback while the
        // descriptor remains readable after a bounded drain. Cellular links
        // often deliver larger bursts, so continue draining on the serial
        // queue after yielding one batch instead of waiting for another socket
        // edge and adding a full network-latency worth of queueing.
        if processedPackets == maximumPacketsPerOutputDrain, isRunning {
            queue.async { [weak self] in
                self?.forwardPacketsFromXray()
            }
        }
    }

    private func flushPendingFrames() {
        pendingPacketCursor = 0
        while pendingPacketCursor < pendingPackets.count, isRunning {
            let packet = pendingPackets[pendingPacketCursor]
            switch sendPacketToXray(packet) {
            case .sent:
                pendingPacketCursor += 1
                pendingFrameBytes -= packet.byteCount
            case .backpressured:
                compactPendingPackets()
                schedulePendingFrameRetryIfNeeded()
                return
            case let .failed(code):
                pendingPacketCursor += 1
                pendingFrameBytes -= packet.byteCount
                droppedPacketsFromSystem += 1
                recordSendFailureIfNeeded(code: code)
            }
        }
        compactPendingPackets()
        cancelPendingFrameRetryIfNeeded()
    }

    private func compactPendingPackets() {
        guard pendingPacketCursor > 0 else { return }
        pendingPackets.removeFirst(pendingPacketCursor)
        pendingPacketCursor = 0
    }

    private func enqueuePendingPacket(_ packet: PacketToXray) {
        guard pendingPackets.count < maximumPendingFrames,
              pendingFrameBytes + packet.byteCount <= maximumPendingBytes else {
            droppedPacketsFromSystem += 1
            return
        }
        pendingPackets.append(packet)
        pendingFrameBytes += packet.byteCount
    }

    private func sendPacketToXray(_ packet: PacketToXray) -> SendResult {
        guard !packet.payload.isEmpty else { return .sent }
        var header = [
            UInt8(0), UInt8(0), UInt8(0),
            UInt8(truncatingIfNeeded: packet.protocolFamily)
        ]
        let sent = header.withUnsafeMutableBytes { headerBytes in
            packet.payload.withUnsafeBytes { payloadBytes in
                var vectors = [
                    iovec(iov_base: headerBytes.baseAddress, iov_len: headerBytes.count),
                    iovec(
                        iov_base: UnsafeMutableRawPointer(mutating: payloadBytes.baseAddress),
                        iov_len: payloadBytes.count
                    )
                ]
                // Packet Tunnel callbacks must never block on the core. A
                // bounded queue handles temporary socket backpressure instead.
                return writev(flowDescriptor, &vectors, 2)
            }
        }
        if sent == packet.byteCount {
            return .sent
        }
        let code = sent < 0 ? errno : EMSGSIZE
        if code == EAGAIN || code == EWOULDBLOCK || code == ENOBUFS {
            return .backpressured
        }
        return .failed(code)
    }

    private func recordSendFailureIfNeeded(code: Int32) {
        guard !hasRecordedSendFailure else { return }
        hasRecordedSendFailure = true
        TunnelDiagnostics.record(source: "Tunnel", message: "系统流量交给核心时发生不可恢复错误（代码 \(code)）。")
    }

    private func schedulePendingFrameRetryIfNeeded() {
        guard !pendingPackets.isEmpty, pendingFrameRetryTimer == nil, isRunning else { return }
        let timer = DispatchSource.makeTimerSource(queue: queue)
        timer.schedule(deadline: .now() + .milliseconds(5), repeating: .milliseconds(5))
        timer.setEventHandler { [weak self] in
            self?.flushPendingFrames()
        }
        pendingFrameRetryTimer = timer
        timer.resume()
    }

    private func cancelPendingFrameRetryIfNeeded() {
        guard pendingPackets.isEmpty else { return }
        pendingFrameRetryTimer?.cancel()
        pendingFrameRetryTimer = nil
    }

    private func stopLocked() {
        guard isRunning else { return }
        isRunning = false
        outputSource?.cancel()
        outputSource = nil
        pendingFrameRetryTimer?.cancel()
        pendingFrameRetryTimer = nil
        if droppedPacketsFromSystem > 0 {
            TunnelDiagnostics.record(
                source: "Tunnel",
                message: "核心繁忙期间丢弃了 \(droppedPacketsFromSystem) 个已超过缓冲上限的数据包。"
            )
        }
        TunnelDiagnostics.record(
            source: "Tunnel",
            message: "数据通道已停止（系统→核心 \(packetsFromSystem) 包，核心→系统 \(packetsToSystem) 包）。"
        )
        pendingPackets.removeAll(keepingCapacity: false)
        pendingPacketCursor = 0
        pendingFrameBytes = 0
    }

    private func configureSocketBuffers() {
        // A socketpair has an independent receive queue at each endpoint. The
        // previous setup increased only the system -> Xray path; the reverse
        // Xray -> system path retained its small default queue and throttled
        // downloads whenever Packet Flow briefly yielded to the system.
        let size: Int32 = 8 * 1_024 * 1_024
        configureSocketBuffer(flowDescriptor, option: SO_SNDBUF, size: size)
        configureSocketBuffer(flowDescriptor, option: SO_RCVBUF, size: size)
        configureSocketBuffer(xrayDescriptor, option: SO_SNDBUF, size: size)
        configureSocketBuffer(xrayDescriptor, option: SO_RCVBUF, size: size)
    }

    private func configureSocketBuffer(_ descriptor: Int32, option: Int32, size: Int32) {
        var requestedSize = size
        _ = withUnsafePointer(to: &requestedSize) {
            setsockopt(
                descriptor,
                SOL_SOCKET,
                option,
                $0,
                socklen_t(MemoryLayout<Int32>.size)
            )
        }
    }

    private func closeDescriptors() {
        descriptorLock.lock()
        defer { descriptorLock.unlock() }
        guard !descriptorsClosed else { return }
        descriptorsClosed = true
        close(xrayDescriptor)
        close(flowDescriptor)
    }
}

private struct PacketToXray {
    let protocolFamily: Int32
    let payload: Data

    var byteCount: Int { MemoryLayout<Int32>.size + payload.count }
}

private enum SendResult {
    case sent
    case backpressured
    case failed(Int32)
}
