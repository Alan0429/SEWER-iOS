# Xray iOS bridge

This Go package produces a local iOS XCFramework for the Packet Tunnel extension:

```sh
$(go env GOPATH)/bin/gomobile init
make framework
```

The dependency is pinned to Xray Core source commit `5d17b872edde3024a5b906d9cd6c7a3ad4973d81` (upstream main, 2026-11-14), licensed under MPL-2.0. Distribution must retain the required Xray notices and make the source form of any modified MPL-covered files available in accordance with that license.

The bridge only accepts a local JSON configuration and the file descriptor supplied by the system Network Extension. It must not fetch configuration, executables, rules, or certificates at runtime.
