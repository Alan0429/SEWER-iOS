// Package xraybridge exposes the minimum lifecycle API required by the iOS
// Packet Tunnel extension. It is compiled into an XCFramework with gomobile.
package xraybridge

import (
	"errors"
	"os"
	"runtime/debug"
	"strconv"
	"sync"

	"github.com/xtls/xray-core/core"
	_ "github.com/xtls/xray-core/main/distro/all"
	_ "github.com/xtls/xray-core/proxy/tun"
)

var (
	instanceMu sync.Mutex
	instance   *core.Instance
	stopping   bool
)

// Start validates the caller-provided tunnel descriptor and starts one Xray
// instance from a local JSON configuration. Configuration is never fetched or
// executed from a remote endpoint.
func Start(configJSON string, tunnelFileDescriptor int) error {
	if configJSON == "" {
		return errors.New("xray configuration is empty")
	}
	if tunnelFileDescriptor < 0 {
		return errors.New("invalid tunnel file descriptor")
	}
	// Network Extension processes have a small jetsam allowance. Keep Go's
	// soft heap limit below the extension budget so long-lived video sessions
	// trigger collection instead of being killed without a Swift stop callback.
	debug.SetMemoryLimit(40 << 20)
	debug.SetGCPercent(75)

	instanceMu.Lock()
	defer instanceMu.Unlock()
	if instance != nil || stopping {
		return errors.New("xray is already running or stopping")
	}
	if err := os.Setenv("XRAY_TUN_FD", strconv.Itoa(tunnelFileDescriptor)); err != nil {
		return err
	}

	started, err := core.StartInstance("json", []byte(configJSON))
	if err != nil {
		return err
	}
	instance = started
	return nil
}

// IsRunning reports whether this bridge still owns a live Xray instance. The
// packet tunnel heartbeat uses it to recover if the core exits independently
// of the Network Extension process.
func IsRunning() bool {
	instanceMu.Lock()
	defer instanceMu.Unlock()
	return instance != nil && !stopping
}

// Stop closes the core before returning. Network Extension considers the
// provider stopped only after stopTunnel returns; waiting for Xray's instance
// to release its TUN readers prevents iOS from leaving the VPN in a stale
// "disconnecting" state and makes a subsequent connection deterministic.
func Stop() error {
	instanceMu.Lock()
	if instance == nil {
		instanceMu.Unlock()
		return nil
	}
	if stopping {
		instanceMu.Unlock()
		return nil
	}
	current := instance
	instance = nil
	stopping = true
	instanceMu.Unlock()

	err := current.Close()
	instanceMu.Lock()
	stopping = false
	instanceMu.Unlock()
	return err
}
