import Foundation
import Network
import Security

struct SewerEdgeOptimization: Codable {
    let primaryAddress: String
    let standbyAddresses: [String]
    let latencyMilliseconds: Int
    let measuredAt: Date
}

actor SewerEdgeOptimizer {
    static let shared = SewerEdgeOptimizer()

    private let cacheKeyPrefix = "sewer.edge-optimization.v1."
    private let freshness: TimeInterval = 10 * 60

    func cachedAddress(for node: SewerNode) -> String? {
        guard let value = cached(for: node),
              Self.isPublicIPv4(value.primaryAddress) else { return nil }
        return value.primaryAddress
    }

    func optimizedAddress(for node: SewerNode) async -> String? {
        await optimization(for: node)?.primaryAddress
    }

    func optimizedAddresses(for node: SewerNode) async -> [String] {
        guard let optimization = await optimization(for: node) else { return [] }
        return ([optimization.primaryAddress] + optimization.standbyAddresses)
            .filter(Self.isPublicIPv4)
            .reduce(into: [String]()) { result, address in
                if !result.contains(address) { result.append(address) }
            }
    }

    private func optimization(for node: SewerNode) async -> SewerEdgeOptimization? {
        if let cached = cached(for: node),
           Date().timeIntervalSince(cached.measuredAt) < freshness,
           Self.isPublicIPv4(cached.primaryAddress) {
            return cached
        }
        guard supports(node) else { return nil }
        guard let endpoint = try? XrayConfigurationFactory.remoteEndpoint(for: node) else { return nil }
        let task = Task<[String: Any]?, Never> {
            let ranges = await Self.fetchCloudFrontPrefixes()
            return ["candidates": ranges] as [String: Any]?
        }
        return await optimize(node: node, endpoint: endpoint, rangesTask: task)
    }

    func failover(for node: SewerNode) {
        guard let host = try? XrayConfigurationFactory.remoteHost(for: node),
              let cached = cached(for: node) else { return }
        let remaining = cached.standbyAddresses.filter {
            Self.isPublicIPv4($0) && $0 != cached.primaryAddress
        }
        if let next = remaining.first {
            save(
                SewerEdgeOptimization(
                    primaryAddress: next,
                    standbyAddresses: Array(remaining.dropFirst()),
                    latencyMilliseconds: cached.latencyMilliseconds,
                    measuredAt: Date()
                ),
                host: host
            )
        } else {
            UserDefaults.standard.removeObject(forKey: cacheKeyPrefix + host.lowercased())
        }
    }

    nonisolated func supports(_ node: SewerNode) -> Bool {
        guard node.scheme.caseInsensitiveCompare("vless") == .orderedSame,
              let host = try? XrayConfigurationFactory.remoteHost(for: node) else { return false }
        return SewerBootstrapResolver.isProtectedHostname(host)
    }

    private func optimize(
        node: SewerNode,
        endpoint: (host: String, port: Int),
        rangesTask: Task<[String: Any]?, Never>
    ) async -> SewerEdgeOptimization? {
        let bootstrap = ((try? await SewerBootstrapResolver.shared.resolveIPv4(endpoint.host)) ?? [])
            .filter(Self.isPublicIPv4)
        guard !bootstrap.isEmpty else { return nil }
        var candidates = Set(bootstrap)
        candidates.formUnion(Self.nearby(bootstrap, perHost: 6))
        if let loaded = await rangesTask.value,
           let ips = loaded["candidates"] as? [String] {
            candidates.formUnion(ips.filter(Self.isPublicIPv4))
        }
        let candidateList = candidates.filter(Self.isPublicIPv4).prefix(96).map { $0 }
        guard !candidateList.isEmpty else { return nil }
        if Task.isCancelled { return nil }

        var firstPass: [(String, Int)] = []
        await withTaskGroup(of: (String, Int?).self) { group in
            var iterator = candidateList.makeIterator()
            for _ in 0..<min(12, candidateList.count) {
                if let address = iterator.next() {
                    group.addTask { (address, await Self.probeTLS(address, endpoint: endpoint, timeout: 1.5)) }
                }
            }
            while let result = await group.next() {
                if Task.isCancelled {
                    group.cancelAll()
                    return
                }
                if let latency = result.1 { firstPass.append((result.0, latency)) }
                if let address = iterator.next() {
                    group.addTask { (address, await Self.probeTLS(address, endpoint: endpoint, timeout: 1.5)) }
                }
            }
        }
        if Task.isCancelled { return nil }
        let finalists = firstPass.sorted { $0.1 < $1.1 }.prefix(6)
        guard !finalists.isEmpty else { return nil }

        var qualities: [(String, Int, Int, Int)] = []
        await withTaskGroup(of: (String, [Int]).self) { group in
            for candidate in finalists {
                group.addTask {
                    var samples: [Int] = [candidate.1]
                    for _ in 0..<3 {
                        if let latency = await Self.probeTLS(candidate.0, endpoint: endpoint, timeout: 2.5) {
                            samples.append(latency)
                        }
                    }
                    return (candidate.0, samples)
                }
            }
            for await (address, samples) in group {
                if Task.isCancelled {
                    group.cancelAll()
                    return
                }
                guard samples.count >= 3 else { continue }
                let median = Self.median(samples)
                let jitter = Self.median(samples.map { abs($0 - median) })
                qualities.append((address, median, jitter, samples.count))
            }
        }
        if Task.isCancelled { return nil }
        guard let best = qualities.min(by: {
            ($0.1 + $0.2) < ($1.1 + $1.2)
        }) else { return nil }
        let standby = qualities
            .filter { $0.0 != best.0 }
            .sorted { ($0.1 + $0.2) < ($1.1 + $1.2) }
            .prefix(3)
            .map(\.0)
        let value = SewerEdgeOptimization(
            primaryAddress: best.0,
            standbyAddresses: Array(standby),
            latencyMilliseconds: best.1,
            measuredAt: Date()
        )
        save(value, host: endpoint.host)
        return value
    }

    private func cached(for node: SewerNode) -> SewerEdgeOptimization? {
        guard let host = try? XrayConfigurationFactory.remoteHost(for: node),
              let data = UserDefaults.standard.data(forKey: cacheKeyPrefix + host.lowercased()) else { return nil }
        return try? JSONDecoder().decode(SewerEdgeOptimization.self, from: data)
    }

    private func save(_ value: SewerEdgeOptimization, host: String) {
        guard let data = try? JSONEncoder().encode(value) else { return }
        UserDefaults.standard.set(data, forKey: cacheKeyPrefix + host.lowercased())
    }

    private static func probeTLS(
        _ address: String,
        endpoint: (host: String, port: Int),
        timeout: TimeInterval
    ) async -> Int? {
        guard let port = NWEndpoint.Port(rawValue: UInt16(endpoint.port)) else { return nil }
        let started = DispatchTime.now().uptimeNanoseconds
        let tls = NWProtocolTLS.Options()
        sec_protocol_options_set_tls_server_name(tls.securityProtocolOptions, endpoint.host)
        sec_protocol_options_set_min_tls_protocol_version(tls.securityProtocolOptions, .TLSv12)
        let parameters = NWParameters(tls: tls, tcp: NWProtocolTCP.Options())
        let connection = NWConnection(host: NWEndpoint.Host(address), port: port, using: parameters)
        let gate = SewerProbeGate()
        connection.stateUpdateHandler = { state in
            switch state {
            case .ready:
                if gate.take() {
                    let elapsed = Int((DispatchTime.now().uptimeNanoseconds - started) / 1_000_000)
                    connection.cancel()
                    gate.resume(elapsed)
                }
            case .failed, .cancelled:
                if gate.take() { gate.resume(nil) }
            default:
                break
            }
        }
        connection.start(queue: .global(qos: .utility))
        let connectionTask = Task<Int?, Never> {
            await withCheckedContinuation { continuation in
                gate.install(continuation)
            }
        }
        return await withTaskGroup(of: Int?.self) { group in
            group.addTask {
                await connectionTask.value
            }
            group.addTask {
                try? await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
                return nil
            }
            let result = await group.next() ?? nil
            group.cancelAll()
            connection.cancel()
            return result
        }
    }

    private static func fetchCloudFrontPrefixes() async -> [String] {
        do {
            let response = try await SewerHTTPTransport.perform(
                host: "ip-ranges.amazonaws.com",
                method: "GET",
                path: "/ip-ranges.json",
                headers: ["Accept": "application/json", "User-Agent": SewerClientIdentity.userAgent],
                timeout: 8,
                maxResponseBytes: 8 * 1_048_576
            )
            guard (200...299).contains(response.status),
                  let root = try JSONSerialization.jsonObject(with: response.body) as? [String: Any],
                  let prefixes = root["prefixes"] as? [[String: Any]] else { return [] }
            var result: [String] = []
            for item in prefixes {
                guard (item["service"] as? String)?.caseInsensitiveCompare("CLOUDFRONT") == .orderedSame,
                      let region = item["region"] as? String,
                      let cidr = item["ip_prefix"] as? String,
                      let parsed = parseIPv4Prefix(cidr) else { continue }
                let upperRegion = region.uppercased()
                guard upperRegion == "GLOBAL" || upperRegion.hasPrefix("AP-") else { continue }
                let samples = upperRegion == "GLOBAL" ? 1 : 4
                for index in 0..<samples {
                    let offset = UInt32.random(in: 1...max(parsed.count - 2, 1)) + UInt32(index)
                    result.append(ipv4String(parsed.start + (offset % parsed.count)))
                }
            }
            return Array(Set(result)).prefix(64).map { $0 }
        } catch {
            return []
        }
    }

    private static func nearby(_ addresses: [String], perHost: Int) -> [String] {
        var result: [String] = []
        for address in addresses {
            let parts = address.split(separator: ".").compactMap { Int($0) }
            guard parts.count == 4, isPublicIPv4(address) else { continue }
            let prefix = "\(parts[0]).\(parts[1]).\(parts[2])"
            for index in 0..<max(perHost, 0) {
                let last = 23 + (index * 47 + parts[3]) % 230
                if last != parts[3] { result.append("\(prefix).\(last)") }
            }
        }
        return Array(Set(result))
    }

    private static func parseIPv4Prefix(_ value: String) -> (start: UInt32, count: UInt32)? {
        let parts = value.split(separator: "/")
        guard parts.count == 2,
              let base = parseIPv4(String(parts[0])),
              let bits = Int(parts[1]), bits >= 16, bits <= 32 else { return nil }
        let count = UInt32(1) << UInt32(32 - bits)
        return (base, max(count, 1))
    }

    private static func parseIPv4(_ value: String) -> UInt32? {
        let parts = value.split(separator: ".").compactMap { UInt32($0) }
        guard parts.count == 4, parts.allSatisfy({ $0 <= 255 }) else { return nil }
        return parts[0] << 24 | parts[1] << 16 | parts[2] << 8 | parts[3]
    }

    private static func ipv4String(_ value: UInt32) -> String {
        "\((value >> 24) & 255).\((value >> 16) & 255).\((value >> 8) & 255).\(value & 255)"
    }

    private static func isPublicIPv4(_ address: String) -> Bool {
        SewerBootstrapResolver.isPublicIPv4(address)
    }

    private static func median(_ samples: [Int]) -> Int {
        guard !samples.isEmpty else { return 0 }
        let values = samples.sorted()
        return values.count.isMultiple(of: 2)
            ? (values[values.count / 2 - 1] + values[values.count / 2]) / 2
            : values[values.count / 2]
    }
}

private final class SewerProbeGate: @unchecked Sendable {
    private let lock = NSLock()
    private var continuation: CheckedContinuation<Int?, Never>?
    private var completedResult: Int?? = nil
    private var consumed = false

    func install(_ continuation: CheckedContinuation<Int?, Never>) {
        lock.lock()
        self.continuation = continuation
        let pending = completedResult
        completedResult = nil
        lock.unlock()
        if let pending { continuation.resume(returning: pending) }
    }

    func take() -> Bool {
        lock.lock()
        defer { lock.unlock() }
        guard !consumed else { return false }
        consumed = true
        return true
    }

    func resume(_ result: Int?) {
        lock.lock()
        if let continuation {
            self.continuation = nil
            lock.unlock()
            continuation.resume(returning: result)
        } else {
            completedResult = result
            lock.unlock()
        }
    }
}
