import Foundation
import Security

enum SessionStore {
    private static let service = "top.sewer.client.ios"
    private static let account = "session"

    static func save(_ session: SewerSession) throws {
        let data = try JSONEncoder().encode(session)
        try clear()
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account,
            kSecValueData: data,
            kSecAttrAccessible: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        guard SecItemAdd(query as CFDictionary, nil) == errSecSuccess else {
            throw SewerAPIError.server("无法安全保存登录状态。")
        }
    }

    static func load() throws -> SewerSession? {
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account,
            kSecReturnData: true,
            kSecMatchLimit: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data else {
            throw SewerAPIError.server("无法读取安全登录状态。")
        }
        return try JSONDecoder().decode(SewerSession.self, from: data)
    }

    static func clear() throws {
        let query: [CFString: Any] = [kSecClass: kSecClassGenericPassword, kSecAttrService: service, kSecAttrAccount: account]
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw SewerAPIError.server("无法清除登录状态。")
        }
    }
}

enum SubscriptionCacheStore {
    private static let service = "top.sewer.client.ios"
    private static let account = "subscription-cache"

    static func save(_ cache: SubscriptionCache) throws {
        let data = try JSONEncoder().encode(cache)
        try clear()
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account,
            kSecValueData: data,
            kSecAttrAccessible: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        guard SecItemAdd(query as CFDictionary, nil) == errSecSuccess else {
            throw SewerAPIError.server("无法安全保存线路配置。")
        }
    }

    static func load() throws -> SubscriptionCache? {
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account,
            kSecReturnData: true,
            kSecMatchLimit: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data else {
            throw SewerAPIError.server("无法读取本地线路配置。")
        }
        return try JSONDecoder().decode(SubscriptionCache.self, from: data)
    }

    static func clear() throws {
        let query: [CFString: Any] = [kSecClass: kSecClassGenericPassword, kSecAttrService: service, kSecAttrAccount: account]
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw SewerAPIError.server("无法清除本地线路配置。")
        }
    }
}

enum AccountSummaryStore {
    private static let service = "top.sewer.client.ios"
    private static let account = "account-summary-cache"

    static func save(_ summary: SewerAccountSummary) throws {
        let data = try JSONEncoder().encode(summary)
        try clear()
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account,
            kSecValueData: data,
            kSecAttrAccessible: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ]
        guard SecItemAdd(query as CFDictionary, nil) == errSecSuccess else {
            throw SewerAPIError.server("无法安全保存账户信息。")
        }
    }

    static func load() throws -> SewerAccountSummary? {
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account,
            kSecReturnData: true,
            kSecMatchLimit: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        if status == errSecItemNotFound { return nil }
        guard status == errSecSuccess, let data = result as? Data else {
            throw SewerAPIError.server("无法读取账户信息。")
        }
        return try JSONDecoder().decode(SewerAccountSummary.self, from: data)
    }

    static func clear() throws {
        let query: [CFString: Any] = [kSecClass: kSecClassGenericPassword, kSecAttrService: service, kSecAttrAccount: account]
        let status = SecItemDelete(query as CFDictionary)
        guard status == errSecSuccess || status == errSecItemNotFound else {
            throw SewerAPIError.server("无法清除账户信息。")
        }
    }
}
