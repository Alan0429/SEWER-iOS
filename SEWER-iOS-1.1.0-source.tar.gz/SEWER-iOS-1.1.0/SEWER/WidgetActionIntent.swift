import AppIntents
import Foundation

@available(iOS 18.0, *)
struct ToggleSewerConnectionIntent: AppIntent {
    static var title: LocalizedStringResource = "切换 SEWER 连接"
    static var description = IntentDescription("打开 SEWER 并切换网络连接状态。")
    // Packet Tunnel sessions are owned by the containing application. iOS can
    // run a Control Center App Intent in its extension process, but it cannot
    // reliably start that session there. Requesting the URL hands the action to
    // the signed application process, which is the supported execution context.
    static var openAppWhenRun: Bool = true

    func perform() async throws -> some IntentResult & OpensIntent {
        WidgetSharedStore.recordControlAction()
        WidgetSharedStore.requestToggle()
        return .result(opensIntent: OpenURLIntent(URL(string: "sewer://toggle")!))
    }
}
