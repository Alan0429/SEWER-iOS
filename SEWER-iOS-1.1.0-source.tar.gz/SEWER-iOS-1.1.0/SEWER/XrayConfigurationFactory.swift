import Foundation

enum XrayConfigurationError: LocalizedError {
    case unsupportedProtocol(String)
    case invalidNode
    case unsupportedTransport(String)
    case unsupportedSecurity(String)
    case missingRealityParameter(String)
    case insecureTrojan
    case insecureTLS
    case invalidXHTTPExtra

    var errorDescription: String? {
        switch self {
        case .unsupportedProtocol(let value): return "iOS 当前不支持 %@ 线路。".appLocalized(arguments: value.uppercased())
        case .invalidNode: return "线路配置不完整。".appLocalized
        case .unsupportedTransport(let value): return "不支持的传输方式：%@。".appLocalized(arguments: value)
        case .unsupportedSecurity(let value): return "不支持的安全设置：%@。".appLocalized(arguments: value)
        case .missingRealityParameter(let value): return "Reality 线路缺少参数：%@。".appLocalized(arguments: value)
        case .insecureTrojan: return "Trojan 线路必须使用 TLS 或 Reality。".appLocalized
        case .insecureTLS: return "线路要求跳过证书校验，已为安全起见拒绝连接。".appLocalized
        case .invalidXHTTPExtra: return "XHTTP 线路的 extra 参数无效。".appLocalized
        }
    }
}

struct XrayConfigurationFactory {
    private static let supportedProtocols: Set<String> = ["vless", "trojan"]

    static func supports(_ node: SewerNode) -> Bool {
        guard hasSupportedScheme(node) else { return false }
        return (try? validate(node)) != nil
    }

    private static func hasSupportedScheme(_ node: SewerNode) -> Bool {
        supportedProtocols.contains(node.scheme.lowercased())
    }

    static func make(
        for node: SewerNode,
        routingMode: SewerRoutingMode,
        optimizedAddresses: [String] = [],
        resolvedAddresses: [String] = []
    ) throws -> String {
        guard hasSupportedScheme(node) else { throw XrayConfigurationError.unsupportedProtocol(node.scheme) }
        let uri = try connectionComponents(for: node)
        guard let originalAddress = uri.host,
              let port = uri.port,
              let credential = uri.user?.removingPercentEncoding,
              !credential.isEmpty else {
            throw XrayConfigurationError.invalidNode
        }

        var query: [String: String] = [:]
        for item in uri.queryItems ?? [] where query[item.name] == nil {
            if let value = item.value {
                query[item.name] = value
            }
        }
        let poolAddresses = optimizedAddresses.reduce(into: [String]()) { result, address in
            let value = address.trimmingCharacters(in: .whitespacesAndNewlines)
            if !value.isEmpty, !result.contains(value) { result.append(value) }
        }
        let primaryAddress = poolAddresses.first ?? originalAddress
        let muxActive = isMuxActive(for: node)
        var outbound = try makeOutbound(
            protocol: node.scheme,
            address: primaryAddress,
            fallbackServerName: originalAddress,
            port: port,
            credential: credential,
            query: query,
            muxEnabled: muxActive
        )
        outbound["tag"] = "proxy"

        var outbounds: [[String: Any]] = [outbound]
        if muxActive {
            var mediaOutbound = outbound
            mediaOutbound["tag"] = "proxy-media"
            mediaOutbound.removeValue(forKey: "mux")
            outbounds.append(mediaOutbound)
        }

        var proxyBalancerTag: String?
        var mediaBalancerTag: String?
        var balancers: [[String: Any]] = []
        if poolAddresses.count > 1 {
            var proxySelector: [String] = []
            var mediaSelector: [String] = []
            for (index, address) in poolAddresses.enumerated() {
                let proxyTag = "sewer-edge-\(index + 1)"
                proxySelector.append(proxyTag)
                outbounds.append(clone(outbound, address: address, tag: proxyTag))
                if muxActive {
                    let mediaTag = "sewer-media-edge-\(index + 1)"
                    mediaSelector.append(mediaTag)
                    var mediaOutbound = outbound
                    mediaOutbound.removeValue(forKey: "mux")
                    outbounds.append(clone(mediaOutbound, address: address, tag: mediaTag))
                }
            }
            proxyBalancerTag = "sewer-edge-balancer"
            balancers.append(balancer(tag: proxyBalancerTag!, selector: proxySelector))
            if muxActive {
                mediaBalancerTag = "sewer-media-balancer"
                balancers.append(balancer(tag: mediaBalancerTag!, selector: mediaSelector))
            }
        }

        var log: [String: Any] = ["loglevel": "warning"]
        if let errorLogPath = TunnelDiagnostics.prepareXrayErrorLog() {
            log["error"] = errorLogPath
        }

        var routing: [String: Any] = [
            "domainStrategy": "AsIs",
            "rules": routingRules(
                for: routingMode,
                proxyBalancerTag: proxyBalancerTag,
                mediaBalancerTag: mediaBalancerTag,
                mediaUsesDedicatedOutbound: muxActive
            )
        ]
        if !balancers.isEmpty { routing["balancers"] = balancers }

        var config: [String: Any] = [
            "log": log,
            "dns": dnsConfiguration(proxyHost: originalAddress, resolvedAddresses: resolvedAddresses),
            "inbounds": [[
                "tag": "tun-in",
                "port": 0,
                "protocol": "tun",
                "settings": ["name": "utun", "mtu": 1500],
                "sniffing": ["enabled": true, "destOverride": ["http", "tls", "quic"]]
            ]],
            "outbounds": outbounds + [
                ["tag": "direct", "protocol": "freedom", "settings": [:]],
                ["tag": "dns-out", "protocol": "dns", "settings": [:]],
                ["tag": "block", "protocol": "blackhole", "settings": [:]]
            ],
            "routing": routing
        ]
        if poolAddresses.count > 1 {
            var subjectSelector = ["sewer-edge-"]
            if muxActive { subjectSelector.append("sewer-media-edge-") }
            config["observatory"] = [
                "subjectSelector": subjectSelector,
                "probeUrl": "https://cp.cloudflare.com/generate_204",
                "probeInterval": "10s",
                "enableConcurrency": true
            ]
        }

        let data = try JSONSerialization.data(withJSONObject: config, options: [.sortedKeys])
        guard let json = String(data: data, encoding: .utf8) else { throw XrayConfigurationError.invalidNode }
        return json
    }

    private static func dnsConfiguration(proxyHost: String, resolvedAddresses: [String]) -> [String: Any] {
        var hosts: [String: Any] = [:]
        let validAddresses = resolvedAddresses.filter { !$0.isEmpty }
        if !validAddresses.isEmpty { hosts[proxyHost] = validAddresses }
        return [
            "tag": "dns",
            "hosts": hosts,
            "servers": [
                ["address": "1.1.1.1", "tag": "remote-dns"]
            ]
        ]
    }

    private static func routingRules(
        for mode: SewerRoutingMode,
        proxyBalancerTag: String?,
        mediaBalancerTag: String?,
        mediaUsesDedicatedOutbound: Bool
    ) -> [[String: Any]] {
        var dnsRule: [String: Any] = [
            "type": "field",
            "inboundTag": ["dns"]
        ]
        dnsRule.merge(targetFields(balancerTag: proxyBalancerTag, outboundTag: "proxy")) { _, new in new }
        var rules: [[String: Any]] = [dnsRule, [
            "type": "field",
            "inboundTag": ["tun-in"],
            "port": "53",
            "outboundTag": "dns-out"
        ], [
            "type": "field",
            "domain": ["domain:sewer.top", "domain:sewer.com.cn"],
            "outboundTag": "direct"
        ], [
            "type": "field",
            "ip": ["geoip:private"],
            "outboundTag": "direct"
        ], [
            "type": "field",
            "domain": ["geosite:private"],
            "outboundTag": "direct"
        ], [
            "type": "field",
            "ip": ["224.0.0.0/4", "ff00::/8"],
            "outboundTag": "direct"
        ]]
        if mediaUsesDedicatedOutbound {
            var mediaRule: [String: Any] = [
                "type": "field",
                "domain": mediaDomains
            ]
            mediaRule.merge(targetFields(balancerTag: mediaBalancerTag, outboundTag: "proxy-media")) { _, new in new }
            rules.append(mediaRule)
        }
        var udpRule: [String: Any] = [
            "type": "field",
            "network": "udp"
        ]
        udpRule.merge(targetFields(balancerTag: proxyBalancerTag, outboundTag: "proxy")) { _, new in new }
        rules.append(udpRule)
        var dnsProviderIPRule: [String: Any] = [
            "type": "field",
            "ip": dnsProviderAddresses
        ]
        dnsProviderIPRule.merge(targetFields(balancerTag: proxyBalancerTag, outboundTag: "proxy")) { _, new in new }
        rules.append(dnsProviderIPRule)
        var dnsProviderDomainRule: [String: Any] = [
            "type": "field",
            "domain": dnsProviderDomains
        ]
        dnsProviderDomainRule.merge(targetFields(balancerTag: proxyBalancerTag, outboundTag: "proxy")) { _, new in new }
        rules.append(dnsProviderDomainRule)
        if mode == .splitTunnel {
            rules.append([
                "type": "field",
                "ip": ["geoip:cn"],
                "outboundTag": "direct"
            ])
            rules.append([
                "type": "field",
                "domain": ["geosite:cn"],
                "outboundTag": "direct"
            ])
        }
        var tcpRule: [String: Any] = ["type": "field", "network": "tcp"]
        tcpRule.merge(targetFields(balancerTag: proxyBalancerTag, outboundTag: "proxy")) { _, new in new }
        rules.append(tcpRule)
        return rules
    }

    private static func targetFields(balancerTag: String?, outboundTag: String) -> [String: Any] {
        if let balancerTag { return ["balancerTag": balancerTag] }
        return ["outboundTag": outboundTag]
    }

    private static func balancer(tag: String, selector: [String]) -> [String: Any] {
        [
            "tag": tag,
            "selector": selector,
            "fallbackTag": "proxy",
            "strategy": ["type": "leastPing"]
        ]
    }

    private static func clone(_ outbound: [String: Any], address: String, tag: String) -> [String: Any] {
        var result = outbound
        result["tag"] = tag
        if var settings = result["settings"] as? [String: Any] {
            if var vnext = settings["vnext"] as? [[String: Any]], !vnext.isEmpty {
                vnext[0]["address"] = address
                settings["vnext"] = vnext
            } else if var servers = settings["servers"] as? [[String: Any]], !servers.isEmpty {
                servers[0]["address"] = address
                settings["servers"] = servers
            }
            result["settings"] = settings
        }
        return result
    }

    private static let dnsProviderAddresses = [
        "223.5.5.5", "223.6.6.6", "1.12.12.12", "120.53.53.53",
        "1.1.1.1", "1.0.0.1"
    ]

    private static let dnsProviderDomains = [
        "domain:alidns.com", "domain:doh.pub", "domain:dot.pub",
        "domain:cloudflare-dns.com", "domain:one.one.one.one"
    ]

    private static let mediaDomains = [
        "domain:tiktok.com", "domain:tiktokv.com", "domain:tiktokcdn.com",
        "domain:tiktokv.us", "domain:tiktokw.us", "domain:tiktokcdn-us.com",
        "domain:tiktokcdn-eu.com", "domain:ttlivecdn.com", "domain:ttlivecdn.net",
        "domain:byteoversea.com", "domain:byteimg.com", "domain:ibytedtos.com",
        "domain:muscdn.com", "domain:pstatp.com", "domain:snssdk.com"
    ]

    static func remoteHost(for node: SewerNode) throws -> String {
        guard hasSupportedScheme(node), let host = try connectionComponents(for: node).host, !host.isEmpty else {
            throw XrayConfigurationError.invalidNode
        }
        return host
    }

    private static func validate(_ node: SewerNode) throws {
        let uri = try connectionComponents(for: node)
        guard let host = uri.host,
              let port = uri.port,
              let credential = uri.user?.removingPercentEncoding,
              !credential.isEmpty else {
            throw XrayConfigurationError.invalidNode
        }
        var query: [String: String] = [:]
        for item in uri.queryItems ?? [] where query[item.name] == nil {
            if let value = item.value { query[item.name] = value }
        }
        _ = try makeOutbound(
            protocol: node.scheme,
            address: host,
            fallbackServerName: host,
            port: port,
            credential: credential,
            query: query,
            muxEnabled: node.isMuxEnabled
        )
    }

    static func remoteEndpoint(for node: SewerNode) throws -> (host: String, port: Int) {
        let uri = try connectionComponents(for: node)
        guard let host = uri.host, let port = uri.port else {
            throw XrayConfigurationError.invalidNode
        }
        return (host, port)
    }

    private static func makeOutbound(
        protocol scheme: String,
        address: String,
        fallbackServerName: String,
        port: Int,
        credential: String,
        query: [String: String],
        muxEnabled: Bool
    ) throws -> [String: Any] {
        var streamSettings = try streamSettings(
            query: query,
            fallbackServerName: fallbackServerName,
            defaultSecurity: scheme == "trojan" ? "tls" : "none"
        )
        streamSettings["sockopt"] = [
            "tcpNoDelay": true,
            "tcpFastOpen": true,
            "tcpKeepAliveIdle": 45
        ]
        let settings: [String: Any]
        switch scheme {
        case "vless":
            settings = [
                "vnext": [[
                    "address": address,
                    "port": port,
                    "users": [[
                        "id": credential,
                        "encryption": query["encryption"] ?? "none",
                        "flow": query["flow"] ?? ""
                    ]]
                ]]
            ]
        case "trojan":
            guard (streamSettings["security"] as? String) != "none" else {
                throw XrayConfigurationError.insecureTrojan
            }
            settings = [
                "servers": [[
                    "address": address,
                    "port": port,
                    "password": credential
                ]]
            ]
        default:
            throw XrayConfigurationError.unsupportedProtocol(scheme)
        }

        var outbound: [String: Any] = [
            "tag": "proxy",
            "protocol": scheme,
            "settings": settings,
            "streamSettings": streamSettings
        ]
        // TCP mux is only useful for a plain VLESS TCP outbound. HTTP-based
        // transports already multiplex traffic, and Xray mux over WS/XHTTP/
        // gRPC/HTTPUpgrade introduces head-of-line blocking that sharply
        // reduces sustained video and live throughput. Trojan mux is not
        // supported by the current core.
        let transport = (query["type"] ?? "tcp").lowercased()
        let effectiveMux = muxEnabled
            && scheme.caseInsensitiveCompare("vless") == .orderedSame
            && transport == "tcp"
        if effectiveMux {
            outbound["mux"] = muxConfiguration(for: query)
        }
        return outbound
    }

    static func isMuxActive(for node: SewerNode) -> Bool {
        guard node.isMuxEnabled,
              node.scheme.caseInsensitiveCompare("vless") == .orderedSame,
              let uri = URLComponents(string: node.rawURI) else { return false }
        let transport = uri.queryItems?.first(where: {
            $0.name.caseInsensitiveCompare("type") == .orderedSame
        })?.value?.lowercased() ?? "tcp"
        return transport == "tcp"
    }

    private static func muxConfiguration(for query: [String: String]) -> [String: Any] {
        // Match the macOS client's Xray defaults. Vision does not use ordinary
        // TCP multiplexing; it uses XUDP multiplexing instead.
        let usesVision = !(query["flow"] ?? "").trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        if usesVision {
            return [
                "enabled": true,
                "concurrency": -1,
                "xudpConcurrency": 16,
                "xudpProxyUDP443": "allow"
            ]
        }
        return [
            "enabled": true,
            "concurrency": 8
        ]
    }

    private static func connectionComponents(for node: SewerNode) throws -> URLComponents {
        guard let uri = URLComponents(string: node.rawURI),
              uri.host != nil,
              let port = uri.port,
              (1...65_535).contains(port),
              uri.user?.removingPercentEncoding?.isEmpty == false else {
            throw XrayConfigurationError.invalidNode
        }
        return uri
    }

    private static func streamSettings(
        query: [String: String],
        fallbackServerName: String,
        defaultSecurity: String
    ) throws -> [String: Any] {
        let transport = (query["type"] ?? "tcp").lowercased()
        guard ["tcp", "ws", "xhttp", "grpc", "httpupgrade"].contains(transport) else {
            throw XrayConfigurationError.unsupportedTransport(transport)
        }

        let requestedSecurity = query["security"]?
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .lowercased()
        let security: String
        switch requestedSecurity {
        case nil, "":
            security = defaultSecurity
        case "xtls":
            // Older VLESS TCP subscriptions encode XTLS as a stream security
            // value. Modern Xray represents the transport as TLS and keeps the
            // XTLS variant in the VLESS `flow` field.
            security = "tls"
        case "none", "tls", "reality":
            security = requestedSecurity!
        default:
            throw XrayConfigurationError.unsupportedSecurity(requestedSecurity!)
        }

        var settings: [String: Any] = ["network": transport, "security": security]
        // The subscribed route uses an explicit SNI first, then falls back to
        // the transport host. This matters for domain-fronted lines whose dial
        // address is an IP address but whose certificate belongs to the HTTP host.
        let transportHost = firstTransportHost(from: query)
        let serverName = firstServerName(from: query["sni"])
            ?? transportHost
            ?? fallbackServerName
        switch security {
        case "tls":
            guard !allowsInsecureCertificate(from: query) else {
                throw XrayConfigurationError.insecureTLS
            }
            var tlsSettings: [String: Any] = [
                "serverName": serverName,
                "allowInsecure": false,
                "fingerprint": query["fp"] ?? "chrome"
            ]
            if let alpn = alpnProtocols(from: query), !alpn.isEmpty {
                tlsSettings["alpn"] = alpn
            }
            settings["tlsSettings"] = tlsSettings
        case "reality":
            guard let publicKey = query["pbk"], !publicKey.isEmpty else {
                throw XrayConfigurationError.missingRealityParameter("pbk")
            }
            settings["realitySettings"] = [
                "serverName": serverName,
                "fingerprint": query["fp"] ?? "chrome",
                "publicKey": publicKey,
                "shortId": query["sid"] ?? "",
                "spiderX": query["spx"] ?? ""
            ]
        default:
            break
        }

        if transport == "ws" {
            var webSocket: [String: Any] = ["path": query["path"] ?? "/"]
            if let host = query["host"], !host.isEmpty {
                // Current Xray exposes the WebSocket Host independently. The
                // legacy headers.Host form is deprecated and slated for removal.
                webSocket["host"] = host
            }
            settings["wsSettings"] = webSocket
        } else if transport == "xhttp" {
            var xhttp: [String: Any] = [
                "path": query["path"] ?? "/",
                "host": query["host"] ?? serverName,
                "mode": query["mode"] ?? "auto"
            ]
            if let extra = query["extra"], !extra.isEmpty {
                let data = Data(extra.utf8)
                guard data.count <= 32_768,
                      let value = try? JSONSerialization.jsonObject(with: data),
                      value is [String: Any] else {
                    throw XrayConfigurationError.invalidXHTTPExtra
                }
                xhttp["extra"] = value
            }
            settings["xhttpSettings"] = xhttp
        } else if transport == "grpc" {
            let mode = query["mode"]?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            settings["grpcSettings"] = [
                "serviceName": query["serviceName"] ?? "",
                "authority": query["authority"] ?? "",
                "multiMode": mode == "multi"
            ]
        } else if transport == "httpupgrade" {
            settings["httpupgradeSettings"] = ["path": query["path"] ?? "/", "host": query["host"] ?? serverName]
        }

        return settings
    }

    private static func firstServerName(from value: String?) -> String? {
        guard let value else { return nil }
        let name = value
            .split(separator: ",", maxSplits: 1, omittingEmptySubsequences: true)
            .first?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return name.isEmpty ? nil : name
    }

    private static func firstTransportHost(from query: [String: String]) -> String? {
        firstServerName(from: query["host"])
    }

    private static func alpnProtocols(from query: [String: String]) -> [String]? {
        guard let value = query["alpn"] else { return nil }
        let protocols = value
            .split(separator: ",")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
        return protocols.isEmpty ? nil : protocols
    }

    private static func allowsInsecureCertificate(from query: [String: String]) -> Bool {
        let values = [query["allowInsecure"], query["insecure"]]
        return values.contains { value in
            switch value?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
            case "1", "true", "yes", "on": return true
            default: return false
            }
        }
    }
}
