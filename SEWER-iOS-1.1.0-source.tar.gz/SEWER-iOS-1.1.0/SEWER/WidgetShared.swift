import Foundation

enum WidgetSharedConstants {
    static let appGroup = "group.top.sewer.client.ios"
    static let snapshotKey = "sewer.widget.snapshot.v1"
    static let pendingActionKey = "sewer.widget.pending-action.v1"
    static let pendingActionTimestampKey = "sewer.widget.pending-action-at.v1"
    static let statusWidgetKind = "SewerStatusWidget"
    static let controlActionTimestampKey = "sewer.widget.control-action-at.v1"
    static let controlActionErrorKey = "sewer.widget.control-action-error.v1"
    static let controlActionDetailsKey = "sewer.widget.control-action-details.v1"
}

struct SewerWidgetSnapshot {
    let remainingTraffic: String
    let routeName: String
    let planName: String
    let expiresAt: Date?
    let connectionState: String
    let healthState: String
    let latencyMilliseconds: Int
    let updatedAt: Date

    static let empty = SewerWidgetSnapshot(
        remainingTraffic: "--",
        routeName: "",
        planName: "",
        expiresAt: nil,
        connectionState: "disconnected",
        healthState: "unknown",
        latencyMilliseconds: 0,
        updatedAt: .distantPast
    )
}

enum WidgetSharedStore {
    private static var defaults: UserDefaults? {
        UserDefaults(suiteName: WidgetSharedConstants.appGroup)
    }

    static func save(snapshot: SewerWidgetSnapshot) {
        defaults?.set([
            "remainingTraffic": snapshot.remainingTraffic,
            "routeName": snapshot.routeName,
            "planName": snapshot.planName,
            "expiresAt": snapshot.expiresAt?.timeIntervalSince1970 ?? 0,
            "connectionState": snapshot.connectionState,
            "healthState": snapshot.healthState,
            "latencyMilliseconds": snapshot.latencyMilliseconds,
            "updatedAt": snapshot.updatedAt.timeIntervalSince1970
        ], forKey: WidgetSharedConstants.snapshotKey)
    }

    static func loadSnapshot() -> SewerWidgetSnapshot {
        guard let values = defaults?.dictionary(forKey: WidgetSharedConstants.snapshotKey),
              let remainingTraffic = values["remainingTraffic"] as? String,
              let routeName = values["routeName"] as? String,
              let connectionState = values["connectionState"] as? String else {
            return .empty
        }
        let timestamp = values["updatedAt"] as? Double ?? 0
        let expiresTimestamp = values["expiresAt"] as? Double ?? 0
        return SewerWidgetSnapshot(
            remainingTraffic: remainingTraffic,
            routeName: routeName,
            planName: values["planName"] as? String ?? "",
            expiresAt: expiresTimestamp > 0 ? Date(timeIntervalSince1970: expiresTimestamp) : nil,
            connectionState: connectionState,
            healthState: values["healthState"] as? String ?? "unknown",
            latencyMilliseconds: values["latencyMilliseconds"] as? Int ?? 0,
            updatedAt: Date(timeIntervalSince1970: timestamp)
        )
    }

    static func requestToggle() {
        defaults?.set("toggle", forKey: WidgetSharedConstants.pendingActionKey)
        defaults?.set(Date().timeIntervalSince1970, forKey: WidgetSharedConstants.pendingActionTimestampKey)
    }

    static func recordControlAction(
        error: String? = nil,
        status: Int? = nil,
        managerCount: Int? = nil,
        hadConnectionIntent: Bool? = nil
    ) {
        defaults?.set(Date().timeIntervalSince1970, forKey: WidgetSharedConstants.controlActionTimestampKey)
        if let status, let managerCount, let hadConnectionIntent {
            defaults?.set([
                "status": status,
                "managerCount": managerCount,
                "hadConnectionIntent": hadConnectionIntent
            ], forKey: WidgetSharedConstants.controlActionDetailsKey)
        }
        if let error, !error.isEmpty {
            defaults?.set(error, forKey: WidgetSharedConstants.controlActionErrorKey)
        } else {
            defaults?.removeObject(forKey: WidgetSharedConstants.controlActionErrorKey)
        }
    }

    static func consumeToggleRequest(maxAge: TimeInterval = 60) -> Bool {
        guard defaults?.string(forKey: WidgetSharedConstants.pendingActionKey) == "toggle" else {
            return false
        }
        defaults?.removeObject(forKey: WidgetSharedConstants.pendingActionKey)
        let requestedAt = defaults?.double(forKey: WidgetSharedConstants.pendingActionTimestampKey) ?? 0
        defaults?.removeObject(forKey: WidgetSharedConstants.pendingActionTimestampKey)
        return requestedAt > 0 && Date().timeIntervalSince1970 - requestedAt <= maxAge
    }

    static var usesEnglish: Bool {
        let preferenceKey = "sewer.app-language.v1"
        let preference = defaults?.string(forKey: preferenceKey)
            ?? UserDefaults.standard.string(forKey: preferenceKey)

        switch preference {
        case "en":
            return true
        case "zh-Hans":
            return false
        default:
            return !(Locale.preferredLanguages.first?.lowercased().hasPrefix("zh") ?? false)
        }
    }
}
