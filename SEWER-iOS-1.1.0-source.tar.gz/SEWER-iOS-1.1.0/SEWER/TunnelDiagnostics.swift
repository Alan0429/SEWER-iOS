import Darwin
import Foundation

struct TunnelDiagnosticEvent: Codable, Identifiable, Equatable {
    let id: UUID
    let timestamp: Date
    let source: String
    let message: String
}

enum TunnelDiagnostics {
    private static let suiteName = "group.top.sewer.client.ios"
    private static let eventsKey = "sewer.tunnel.diagnostics.v1"
    private static let stopCompletedAtKey = "sewer.tunnel.stop-completed-at.v1"
    private static let eventLimit = 80
    private static let xrayDiagnosticsDirectory = "XrayDiagnostics"
    private static let xrayErrorLogName = "error.log"
    private static let lastAliveKey = "sewer.tunnel.last-alive-at.v1"
    private static let processStartedAtKey = "sewer.tunnel.process-started-at.v1"

    static func record(source: String, message: String) {
        var current = events()
        current.append(TunnelDiagnosticEvent(id: UUID(), timestamp: Date(), source: source, message: message))
        if current.count > eventLimit {
            current.removeFirst(current.count - eventLimit)
        }
        guard let data = try? JSONEncoder().encode(current) else { return }
        defaults.set(data, forKey: eventsKey)
    }

    static func events() -> [TunnelDiagnosticEvent] {
        guard let data = defaults.data(forKey: eventsKey),
              let value = try? JSONDecoder().decode([TunnelDiagnosticEvent].self, from: data) else {
            return []
        }
        return value.sorted { $0.timestamp > $1.timestamp }
    }

    static func clear() {
        defaults.removeObject(forKey: eventsKey)
    }

    static func markStopCompleted() {
        defaults.set(Date().timeIntervalSince1970, forKey: stopCompletedAtKey)
    }

    static func stopCompletedAt() -> Date? {
        let value = defaults.double(forKey: stopCompletedAtKey)
        return value > 0 ? Date(timeIntervalSince1970: value) : nil
    }

    // The extension writes these markers while it is alive. If a tunnel drops
    // and the most recent marker predates the drop, the extension process was
    // most likely terminated by the system (memory pressure, crash) instead of
    // being asked to stop, in which case stopTunnel never runs.
    static func markProcessStarted() {
        defaults.set(Date().timeIntervalSince1970, forKey: processStartedAtKey)
    }

    static func processStartedAt() -> Date? {
        let value = defaults.double(forKey: processStartedAtKey)
        return value > 0 ? Date(timeIntervalSince1970: value) : nil
    }

    static func markAlive() {
        defaults.set(Date().timeIntervalSince1970, forKey: lastAliveKey)
    }

    static func lastAliveAt() -> Date? {
        let value = defaults.double(forKey: lastAliveKey)
        return value > 0 ? Date(timeIntervalSince1970: value) : nil
    }

    static func memoryFootprintDescription() -> String {
        var info = task_vm_info()
        var count = mach_msg_type_number_t(
            MemoryLayout<task_vm_info>.size / MemoryLayout<natural_t>.size
        )
        let result = withUnsafeMutablePointer(to: &info) { pointer in
            pointer.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                task_info(mach_task_self_, task_flavor_t(TASK_VM_INFO), $0, &count)
            }
        }
        guard result == KERN_SUCCESS else { return "未知" }
        let megabytes = Double(info.phys_footprint) / (1_024 * 1_024)
        return String(format: "%.1f MB", megabytes)
    }

    static func errorSummary(_ error: Error) -> String {
        let value = error as NSError
        let domain = value.domain.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !domain.isEmpty else { return "未知错误（代码 \(value.code)）" }
        return "\(domain)（代码 \(value.code)）"
    }

    static func prepareXrayErrorLog() -> String? {
        guard let url = xrayErrorLogURL() else { return nil }
        try? Data().write(to: url, options: .atomic)
        return url.path
    }

    static func xrayErrorSummary() -> String? {
        guard let url = xrayErrorLogURL(),
              let handle = try? FileHandle(forReadingFrom: url) else {
            return nil
        }
        defer { try? handle.close() }
        guard let data = try? handle.read(upToCount: 262_144),
              let contents = String(data: data, encoding: .utf8),
              !contents.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return nil
        }
        defer { clearXrayErrorLog() }
        let value = contents.lowercased()
        if value.contains("handshake") || value.contains("tls") || value.contains("reality") {
            return "核心报告 TLS 或 Reality 握手异常。"
        }
        if value.contains("timeout") || value.contains("timed out") {
            return "核心报告连接超时。"
        }
        if value.contains("dns") || value.contains("resolve") || value.contains("lookup") {
            return "核心报告 DNS 解析异常。"
        }
        if value.contains("refused") || value.contains("unreachable") || value.contains("no route") {
            return "核心报告远端网络不可达。"
        }
        return "核心报告运行时错误。"
    }

    static func clearXrayErrorLog() {
        guard let url = xrayErrorLogURL() else { return }
        try? FileManager.default.removeItem(at: url)
    }

    private static var defaults: UserDefaults {
        UserDefaults(suiteName: suiteName) ?? .standard
    }

    private static func xrayErrorLogURL() -> URL? {
        guard let container = FileManager.default.containerURL(
            forSecurityApplicationGroupIdentifier: suiteName
        ) else {
            return nil
        }
        let directory = container.appendingPathComponent(xrayDiagnosticsDirectory, isDirectory: true)
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        return directory.appendingPathComponent(xrayErrorLogName)
    }
}
