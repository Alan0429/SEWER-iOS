import BackgroundTasks
import SwiftUI
import WidgetKit

@main
struct SEWERApp: App {
    @StateObject private var appModel = AppModel()
    @AppStorage(AppLanguage.preferenceKey) private var appLanguage = AppLanguage.system.rawValue

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(appModel)
                .environment(\.locale, AppLanguage.locale(for: appLanguage))
                // Most app copy uses the explicit `appLocalized` lookup so
                // dynamic status text can be translated too. SwiftUI does not
                // automatically invalidate those strings when only `locale`
                // changes, so rebuild the presentation tree for each selected
                // language while retaining the shared AppModel state.
                .id("sewer-language-\(appLanguage)")
                .onAppear { AppLanguage.persist(appLanguage) }
                .onChange(of: appLanguage) { newValue in
                    AppLanguage.persist(newValue)
                    appModel.localizationDidChange()
                    WidgetCenter.shared.reloadAllTimelines()
                }
                .onOpenURL { url in
                    Task { @MainActor in
                        await appModel.handleWidgetURL(url)
                    }
                }
        }
    }
}

@MainActor
final class BackgroundConnectionRefresh {
    static let shared = BackgroundConnectionRefresh()
    static let taskIdentifier = "top.sewer.client.ios.connection-refresh"

    private weak var model: AppModel?
    private var isRegistered = false

    private init() {}

    func register(with model: AppModel) {
        self.model = model
        guard !isRegistered else { return }
        isRegistered = true

        BGTaskScheduler.shared.register(
            forTaskWithIdentifier: Self.taskIdentifier,
            using: nil
        ) { [weak self] task in
            Task { @MainActor in
                self?.handle(task)
            }
        }
    }

    func schedule() {
        BGTaskScheduler.shared.cancel(taskRequestWithIdentifier: Self.taskIdentifier)
        let request = BGAppRefreshTaskRequest(identifier: Self.taskIdentifier)
        // iOS decides the exact time. This is a recovery safety net; Packet
        // Tunnel On Demand remains responsible for immediate reconnects.
        request.earliestBeginDate = Date().addingTimeInterval(15 * 60)
        do {
            try BGTaskScheduler.shared.submit(request)
        } catch {
            TunnelDiagnostics.record(source: "客户端", message: "系统未接受后台连接恢复任务。")
        }
    }

    func cancel() {
        BGTaskScheduler.shared.cancel(taskRequestWithIdentifier: Self.taskIdentifier)
    }

    private func handle(_ task: BGTask) {
        guard let refreshTask = task as? BGAppRefreshTask else {
            task.setTaskCompleted(success: false)
            return
        }

        let cancellation = BackgroundWorkCancellation()
        refreshTask.expirationHandler = {
            cancellation.cancel()
        }
        let work = Task { @MainActor [weak self] in
            guard let self, let model = self.model else {
                refreshTask.setTaskCompleted(success: false)
                return
            }
            guard !cancellation.isCancelled else {
                refreshTask.setTaskCompleted(success: false)
                return
            }
            await model.refreshConnectionInBackground()
            refreshTask.setTaskCompleted(success: !Task.isCancelled && !cancellation.isCancelled)
        }
        cancellation.install(work)
    }
}

private final class BackgroundWorkCancellation: @unchecked Sendable {
    private let lock = NSLock()
    private var task: Task<Void, Never>?
    private var cancelled = false

    var isCancelled: Bool {
        lock.lock()
        defer { lock.unlock() }
        return cancelled
    }

    func install(_ task: Task<Void, Never>) {
        lock.lock()
        self.task = task
        let shouldCancel = cancelled
        lock.unlock()
        if shouldCancel { task.cancel() }
    }

    func cancel() {
        lock.lock()
        cancelled = true
        let task = self.task
        lock.unlock()
        task?.cancel()
    }
}
