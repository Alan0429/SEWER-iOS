import Foundation

struct APIEnvelope<Value: Decodable>: Decodable {
    let status: String?
    let message: String?
    let data: Value?
}

struct AuthenticationResponse: Decodable {
    let authData: String
    let token: String?
    let isAdmin: Bool

    enum CodingKeys: String, CodingKey {
        case authData = "auth_data"
        case token
        case isAdmin = "is_admin"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        authData = try container.decode(String.self, forKey: .authData)
        token = try container.decodeIfPresent(String.self, forKey: .token)
        isAdmin = try container.decodeIfPresent(Bool.self, forKey: .isAdmin) ?? false
    }
}

struct SubscriptionResponse: Decodable {
    let transferEnable: Int64?
    let upload: Int64?
    let download: Int64?
    let usedTraffic: Int64?
    let remainingTraffic: Int64?
    let totalRemainingTraffic: Int64?
    let expiredAt: Int64?
    let nextResetAt: Int64?
    let isEnterprise: Bool
    let multiPlanEnabled: Bool
    let speedLimitMbps: Int?
    let plan: SewerPlanInfo?
    let planTransferEnable: Int64?
    let planUpload: Int64?
    let planDownload: Int64?
    let planUsedTraffic: Int64?
    let planRemainingTraffic: Int64?
    let userPlans: [SewerUserPlan]
    let subscriptionV3: SewerSubscriptionGrant?

    enum CodingKeys: String, CodingKey {
        case transferEnable = "transfer_enable"
        case upload = "u"
        case download = "d"
        case usedTraffic = "used_traffic"
        case remainingTraffic = "remaining_traffic"
        case totalRemainingTraffic = "total_remaining_traffic"
        case expiredAt = "expired_at"
        case nextResetAt = "next_reset_at"
        case isEnterprise = "is_enterprise"
        case multiPlanEnabled = "multi_plan_enabled"
        case speedLimitMbps = "speed_limit"
        case plan
        case planTransferEnable = "plan_transfer_enable"
        case planUpload = "plan_upload"
        case planDownload = "plan_download"
        case planUsedTraffic = "plan_used_traffic"
        case planRemainingTraffic = "plan_remaining_traffic"
        case userPlans = "user_plans"
        case subscriptionV3 = "subscription_v3"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        transferEnable = try container.decodeIfPresent(Int64.self, forKey: .transferEnable)
        upload = try container.decodeIfPresent(Int64.self, forKey: .upload)
        download = try container.decodeIfPresent(Int64.self, forKey: .download)
        usedTraffic = try container.decodeIfPresent(Int64.self, forKey: .usedTraffic)
        remainingTraffic = try container.decodeIfPresent(Int64.self, forKey: .remainingTraffic)
        totalRemainingTraffic = try container.decodeIfPresent(Int64.self, forKey: .totalRemainingTraffic)
        expiredAt = try container.decodeIfPresent(Int64.self, forKey: .expiredAt)
        nextResetAt = try container.decodeIfPresent(Int64.self, forKey: .nextResetAt)
        isEnterprise = try container.decodeIfPresent(Bool.self, forKey: .isEnterprise) ?? false
        multiPlanEnabled = try container.decodeIfPresent(Bool.self, forKey: .multiPlanEnabled) ?? false
        speedLimitMbps = try container.decodeIfPresent(Int.self, forKey: .speedLimitMbps)
        plan = try container.decodeIfPresent(SewerPlanInfo.self, forKey: .plan)
        planTransferEnable = try container.decodeIfPresent(Int64.self, forKey: .planTransferEnable)
        planUpload = try container.decodeIfPresent(Int64.self, forKey: .planUpload)
        planDownload = try container.decodeIfPresent(Int64.self, forKey: .planDownload)
        planUsedTraffic = try container.decodeIfPresent(Int64.self, forKey: .planUsedTraffic)
        planRemainingTraffic = try container.decodeIfPresent(Int64.self, forKey: .planRemainingTraffic)
        userPlans = try container.decodeIfPresent([SewerUserPlan].self, forKey: .userPlans) ?? []
        subscriptionV3 = try container.decodeIfPresent(SewerSubscriptionGrant.self, forKey: .subscriptionV3)
    }
}

struct SewerPlanInfo: Codable, Equatable {
    let id: Int64
    let name: String?
    let speedLimitMbps: Int?

    enum CodingKeys: String, CodingKey {
        case id
        case name
        case speedLimitMbps = "speed_limit"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(Int64.self, forKey: .id) ?? 0
        name = try container.decodeIfPresent(String.self, forKey: .name)
        speedLimitMbps = try container.decodeIfPresent(Int.self, forKey: .speedLimitMbps)
    }
}

struct SewerUserPlan: Codable, Equatable {
    let id: Int64
    let planID: Int64
    let plan: SewerPlanInfo?
    let transferEnable: Int64
    let upload: Int64
    let download: Int64
    let used: Int64?
    let remaining: Int64?
    let primaryRemaining: Int64?
    let expiredAt: Int64?
    let nextResetAt: Int64?
    let nodeNames: [String]
    let displayName: String?

    init(
        id: Int64,
        planID: Int64,
        plan: SewerPlanInfo?,
        transferEnable: Int64,
        upload: Int64,
        download: Int64,
        used: Int64?,
        remaining: Int64?,
        primaryRemaining: Int64?,
        expiredAt: Int64?,
        nextResetAt: Int64?,
        nodeNames: [String],
        displayName: String?
    ) {
        self.id = id
        self.planID = planID
        self.plan = plan
        self.transferEnable = transferEnable
        self.upload = upload
        self.download = download
        self.used = used
        self.remaining = remaining
        self.primaryRemaining = primaryRemaining
        self.expiredAt = expiredAt
        self.nextResetAt = nextResetAt
        self.nodeNames = nodeNames
        self.displayName = displayName
    }

    enum CodingKeys: String, CodingKey {
        case id
        case planID = "plan_id"
        case plan
        case transferEnable = "transfer_enable"
        case upload = "u"
        case download = "d"
        case used
        case remaining
        case primaryRemaining = "primary_remaining"
        case expiredAt = "expired_at"
        case nextResetAt = "next_reset_at"
        case nodeNames = "node_names"
        case displayName = "display_name"
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(Int64.self, forKey: .id) ?? 0
        planID = try container.decodeIfPresent(Int64.self, forKey: .planID) ?? 0
        plan = try container.decodeIfPresent(SewerPlanInfo.self, forKey: .plan)
        transferEnable = try container.decodeIfPresent(Int64.self, forKey: .transferEnable) ?? 0
        upload = try container.decodeIfPresent(Int64.self, forKey: .upload) ?? 0
        download = try container.decodeIfPresent(Int64.self, forKey: .download) ?? 0
        used = try container.decodeIfPresent(Int64.self, forKey: .used)
        remaining = try container.decodeIfPresent(Int64.self, forKey: .remaining)
        primaryRemaining = try container.decodeIfPresent(Int64.self, forKey: .primaryRemaining)
        expiredAt = try container.decodeIfPresent(Int64.self, forKey: .expiredAt)
        nextResetAt = try container.decodeIfPresent(Int64.self, forKey: .nextResetAt)
        nodeNames = try container.decodeIfPresent([String].self, forKey: .nodeNames) ?? []
        displayName = try container.decodeIfPresent(String.self, forKey: .displayName)
    }

    func access(isEnterprise: Bool) -> SewerSubscriptionAccess {
        let fallbackUsed = max(upload, 0) > Int64.max - max(download, 0)
            ? Int64.max
            : max(upload, 0) + max(download, 0)
        return SewerSubscriptionAccess(
            expiredAt: expiredAt,
            nextResetAt: nextResetAt,
            transferEnable: max(transferEnable, 0),
            used: max(used ?? fallbackUsed, 0),
            isEnterprise: isEnterprise,
            speedLimitMbps: max(plan?.speedLimitMbps ?? 0, 0)
        )
    }
}

struct SewerSubscriptionAccess: Equatable {
    let expiredAt: Int64?
    let nextResetAt: Int64?
    let transferEnable: Int64
    let used: Int64
    let isEnterprise: Bool
    let speedLimitMbps: Int

    func isExpired(at now: Int64 = Int64(Date().timeIntervalSince1970)) -> Bool {
        guard let expiredAt, expiredAt > 0 else { return false }
        return expiredAt <= now
    }

    func isTrafficExhausted() -> Bool {
        transferEnable > 0 && used >= transferEnable
    }
}

enum SewerPlanDenialReason: Equatable {
    case none
    case expired
    case trafficExhausted
    case unresolved
    case unavailable
}

struct SewerLinePlanValidation: Equatable {
    let allowed: Bool
    let reason: SewerPlanDenialReason
    let lineName: String
    let planID: Int64
    let planName: String?
    let access: SewerSubscriptionAccess?
}

enum SewerSubscriptionPolicy {
    static func validateCurrentLine(
        summary: SubscriptionResponse?,
        lineName: String?,
        now: Int64 = Int64(Date().timeIntervalSince1970)
    ) -> SewerLinePlanValidation {
        let selectedName = lineName?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard let summary, !selectedName.isEmpty else {
            return SewerLinePlanValidation(
                allowed: false,
                reason: .unavailable,
                lineName: selectedName,
                planID: 0,
                planName: nil,
                access: nil
            )
        }
        return validateCurrentLine(
            plans: allPlans(summary),
            isEnterprise: summary.isEnterprise,
            lineName: selectedName,
            now: now
        )
    }

    static func validateCurrentLine(
        plans: [SewerUserPlan],
        isEnterprise: Bool,
        lineName: String?,
        now: Int64 = Int64(Date().timeIntervalSince1970)
    ) -> SewerLinePlanValidation {
        let selectedName = lineName?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !selectedName.isEmpty else {
            return SewerLinePlanValidation(
                allowed: false,
                reason: .unavailable,
                lineName: selectedName,
                planID: 0,
                planName: nil,
                access: nil
            )
        }
        guard let matched = findUniquePlan(plans: plans, lineName: selectedName) else {
            return SewerLinePlanValidation(
                allowed: false,
                reason: .unresolved,
                lineName: selectedName,
                planID: 0,
                planName: nil,
                access: nil
            )
        }

        let access = matched.access(isEnterprise: isEnterprise)
        let planID = matched.planID > 0 ? matched.planID : (matched.plan?.id ?? matched.id)
        let planName = planDisplayName(matched)
        let reason: SewerPlanDenialReason
        if access.isExpired(at: now) {
            reason = .expired
        } else if access.isTrafficExhausted() {
            reason = .trafficExhausted
        } else {
            reason = .none
        }
        return SewerLinePlanValidation(
            allowed: reason == .none,
            reason: reason,
            lineName: selectedName,
            planID: planID,
            planName: planName,
            access: access
        )
    }

    static func planDisplayName(_ plan: SewerUserPlan) -> String? {
        if let value = plan.displayName?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty {
            return value
        }
        if let value = plan.plan?.name?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty {
            return value
        }
        return plan.nodeNames.first { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
    }

    private static func allPlans(_ summary: SubscriptionResponse) -> [SewerUserPlan] {
        if !summary.userPlans.isEmpty { return summary.userPlans }
        let hasPlanData = summary.plan != nil
            || summary.planTransferEnable != nil
            || summary.planUsedTraffic != nil
            || summary.planUpload != nil
            || summary.planDownload != nil
            || (summary.transferEnable ?? 0) > 0
            || (summary.upload ?? 0) > 0
            || (summary.download ?? 0) > 0
        guard hasPlanData else { return [] }
        return [SewerUserPlan(
            id: summary.plan?.id ?? 0,
            planID: summary.plan?.id ?? 0,
            plan: summary.plan,
            transferEnable: summary.planTransferEnable ?? summary.transferEnable ?? 0,
            upload: summary.planUpload ?? summary.upload ?? 0,
            download: summary.planDownload ?? summary.download ?? 0,
            used: summary.planUsedTraffic ?? summary.usedTraffic,
            remaining: summary.planRemainingTraffic
                ?? summary.totalRemainingTraffic
                ?? summary.remainingTraffic,
            primaryRemaining: nil,
            expiredAt: summary.expiredAt,
            nextResetAt: summary.nextResetAt,
            nodeNames: [],
            displayName: summary.plan?.name
        )]
    }

    private static func findUniquePlan(plans: [SewerUserPlan], lineName: String) -> SewerUserPlan? {
        guard !plans.isEmpty else { return nil }
        let normalizedLine = normalize(lineName)
        let lineWithoutDate = stripTrailingDate(normalizedLine)
        var matches: [SewerUserPlan] = []
        var seen = Set<String>()
        for plan in plans {
            let matched = planLineNames(plan).contains { candidate in
                let normalizedCandidate = normalize(candidate)
                return normalizedCandidate == normalizedLine
                    || stripTrailingDate(normalizedCandidate) == lineWithoutDate
            }
            guard matched else { continue }
            let identity = "\(plan.id):\(plan.planID):\(plan.plan?.id ?? 0)"
            if seen.insert(identity).inserted { matches.append(plan) }
        }
        if matches.count == 1 { return matches[0] }
        if matches.isEmpty, plans.count == 1 { return plans[0] }
        return nil
    }

    private static func planLineNames(_ plan: SewerUserPlan) -> [String] {
        [plan.displayName, plan.plan?.name].compactMap { $0 } + plan.nodeNames
    }

    private static func normalize(_ value: String) -> String {
        value
            .folding(options: [.caseInsensitive, .diacriticInsensitive, .widthInsensitive], locale: .current)
            .lowercased()
            .replacingOccurrences(of: "～", with: "~")
            .replacingOccurrences(of: "〜", with: "~")
            .replacingOccurrences(of: "－", with: "-")
            .replacingOccurrences(of: "—", with: "-")
            .replacingOccurrences(of: "–", with: "-")
            .components(separatedBy: .whitespacesAndNewlines)
            .joined()
    }

    private static func stripTrailingDate(_ value: String) -> String {
        // Subscription providers use both separated dates (2026-12-31,
        // 2026_12_31) and compact dates (20261231) as line-name suffixes.
        // Treat both forms as the same route identity so a date rollover does
        // not make a valid per-plan mapping look ambiguous.
        let pattern = #"(?:[-_./]?\s*(?:20\d{2}[-_./]?\d{1,2}[-_./]\d{1,2}|20\d{6}))\s*$"#
        guard let range = value.range(of: pattern, options: .regularExpression) else { return value }
        return String(value[..<range.lowerBound])
            .trimmingCharacters(in: CharacterSet(charactersIn: "-_./"))
    }
}

struct AccountProfileResponse: Decodable {
    let userType: String?
    let typeLabel: String?
    let companyName: String?

    enum CodingKeys: String, CodingKey {
        case userType = "user_type"
        case typeLabel = "type_label"
        case companyName = "company_name"
    }
}

struct SewerSubscriptionBundle {
    let response: SubscriptionResponse
    let nodes: [SewerNode]
}

enum SewerRoutingMode: String, Codable, CaseIterable {
    case splitTunnel
    case fullTunnel

    var title: String {
        switch self {
        case .splitTunnel: return "智能模式".appLocalized
        case .fullTunnel: return "全局模式".appLocalized
        }
    }

    var detail: String {
        switch self {
        case .splitTunnel: return "根据智能分流规则，本地、私有网络及指定流量直连，其余流量经受保护通道传输。".appLocalized
        case .fullTunnel: return "除服务基础设施所需直连流量外，所有网络流量经受保护通道传输。".appLocalized
        }
    }
}

struct SewerAccountSummary: Codable, Equatable {
    let transferEnable: Int64
    let upload: Int64
    let download: Int64
    let userType: String?
    let typeLabel: String?
    let isEnterprise: Bool
    let companyName: String?
    let expiredAt: Int64?
    let nextResetAt: Int64?
    let userPlans: [SewerUserPlan]?
    let refreshedAt: Date

    init(
        subscription: SubscriptionResponse,
        profile: AccountProfileResponse?,
        isAdmin: Bool = false,
        refreshedAt: Date = Date()
    ) {
        transferEnable = max(subscription.transferEnable ?? 0, 0)
        upload = max(subscription.upload ?? 0, 0)
        download = max(subscription.download ?? 0, 0)
        userType = isAdmin ? "admin" : profile?.userType
        typeLabel = profile?.typeLabel
        isEnterprise = subscription.isEnterprise
        companyName = profile?.companyName
        expiredAt = subscription.expiredAt
        nextResetAt = subscription.nextResetAt
        userPlans = subscription.userPlans.isEmpty ? nil : subscription.userPlans
        self.refreshedAt = refreshedAt
    }

    var remainingBytes: Int64 {
        max(transferEnable - upload - download, 0)
    }

    var usedBytes: Int64 {
        min(max(upload + download, 0), transferEnable)
    }

    var trafficDescription: String {
        Self.formattedBytes(remainingBytes)
    }

    var totalTrafficDescription: String {
        Self.formattedBytes(transferEnable)
    }

    var usedTrafficDescription: String {
        Self.formattedBytes(usedBytes)
    }

    var normalizedCompanyName: String? {
        let value = companyName?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return value.isEmpty ? nil : value
    }

    var displayUserType: String {
        if ["admin", "administrator"].contains(
            userType?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() ?? ""
        ) {
            return "管理员".appLocalized
        }
        if let value = typeLabel?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty {
            return value.appLocalized
        }
        switch userType?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() {
        case "enterprise", "company": return "企业套餐".appLocalized
        case "personal": return "个人套餐".appLocalized
        default: break
        }
        return isEnterprise ? "企业套餐".appLocalized : "个人套餐".appLocalized
    }

    private static func formattedBytes(_ bytes: Int64) -> String {
        let units = ["B", "KB", "MB", "GB", "TB"]
        var value = Double(max(bytes, 0))
        var index = 0
        while value >= 1024, index < units.count - 1 {
            value /= 1024
            index += 1
        }
        if index == 0 {
            return "\(Int(value)) B"
        }
        return String(format: "%.2f %@", value, units[index])
    }
}

struct SewerSession: Codable, Equatable {
    let email: String
    let authorization: String
    let token: String?
    let baseURL: String
    let isAdmin: Bool

    enum CodingKeys: String, CodingKey {
        case email
        case authorization
        case token
        case baseURL
        case isAdmin
    }

    init(email: String, authorization: String, token: String?, baseURL: String, isAdmin: Bool = false) {
        self.email = email
        self.authorization = authorization
        self.token = token
        self.baseURL = baseURL
        self.isAdmin = isAdmin
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        email = try container.decode(String.self, forKey: .email)
        authorization = try container.decode(String.self, forKey: .authorization)
        token = try container.decodeIfPresent(String.self, forKey: .token)
        baseURL = try container.decodeIfPresent(String.self, forKey: .baseURL)
            ?? "https://api.sewer.com.cn"
        isAdmin = try container.decodeIfPresent(Bool.self, forKey: .isAdmin) ?? false
    }
}

struct SewerNode: Codable, Identifiable, Equatable {
    let id: String
    let scheme: String
    let name: String
    let rawURI: String

    var displayProtocol: String { scheme.uppercased() }

    // Keep this in sync with the URI convention used by the macOS client.
    // Mux is server-selected through the subscription and is not enabled for
    // ordinary lines unless the subscription explicitly opts in.
    var isMuxEnabled: Bool {
        guard let components = URLComponents(string: rawURI),
              let value = components.queryItems?.first(where: {
                  $0.name.compare("mux", options: .caseInsensitive) == .orderedSame
              })?.value?.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() else {
            return false
        }
        return ["1", "true", "on"].contains(value)
    }
}

struct SewerNoticePage: Decodable, Equatable {
    let data: [SewerNotice]
    let total: Int
}

struct SewerNotice: Decodable, Identifiable, Equatable {
    let id: Int
    let title: String
    let content: String
    let isShown: Bool
    let imageURL: URL?
    let tags: [String]
    let createdAt: Int
    let updatedAt: Int

    enum CodingKeys: String, CodingKey {
        case id
        case title
        case content
        case isShown = "show"
        case imageURL = "img_url"
        case tags
        case createdAt = "created_at"
        case updatedAt = "updated_at"
    }

    var displayDate: String {
        AppLanguage.formattedDate(
            Date(timeIntervalSince1970: TimeInterval(createdAt)),
            dateStyle: .abbreviated,
            timeStyle: .shortened
        )
    }

    var safeImageURL: URL? {
        guard let imageURL,
              imageURL.scheme?.lowercased() == "https",
              imageURL.user == nil,
              imageURL.password == nil,
              imageURL.port == nil || imageURL.port == 443,
              let host = imageURL.host?.lowercased(),
              SewerBootstrapResolver.isSewerHostname(host) else {
            return nil
        }
        return imageURL
    }
}

struct SubscriptionCache: Codable {
    let nodes: [SewerNode]
    let refreshedAt: Date
}
