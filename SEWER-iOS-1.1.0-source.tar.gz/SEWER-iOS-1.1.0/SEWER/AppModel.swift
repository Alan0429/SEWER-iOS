import CryptoKit
import Combine
import Foundation
import Network
import UIKit
import WidgetKit

enum ConnectionHealth: Equatable {
    case notChecked
    case checking
    case available(latencyMilliseconds: Int)
    case unavailable

    var description: String {
        switch self {
        case .notChecked: return "待检测".appLocalized
        case .checking: return "验证中".appLocalized
        case let .available(latencyMilliseconds):
            let latencyText = String(latencyMilliseconds).prefix(2)
            return "正常 · %@ ms".appLocalized(arguments: String(latencyText))
        case .unavailable: return "异常".appLocalized
        }
    }

    var isAvailable: Bool {
        if case .available = self {
            return true
        }
        return false
    }

    var isChecking: Bool {
        if case .checking = self {
            return true
        }
        return false
    }

    var isUnavailable: Bool {
        if case .unavailable = self { return true }
        return false
    }
}

enum ConnectionAttemptPhase: Equatable {
    case idle
    case checkingInternet
    case checkingPlan
    case establishingTunnel
    case reconnecting(attempt: Int)

    var isInProgress: Bool {
        self != .idle
    }

    var detail: String {
        switch self {
        case .idle: return ""
        case .checkingInternet: return "正在检查网络状态".appLocalized
        case .checkingPlan: return "正在确认当前线路套餐和有效期".appLocalized
        case .establishingTunnel: return "正在建立安全通道".appLocalized
        case let .reconnecting(attempt): return "连接中断，正在自动重连（第 %d 次）".appLocalized(arguments: attempt)
        }
    }
}

@MainActor
final class AppModel: ObservableObject {
    @Published private(set) var session: SewerSession?
    @Published private(set) var isLoggingIn = false
    @Published private(set) var isRefreshingSubscription = false
    @Published private(set) var subscriptionError: String?
    @Published private(set) var subscriptionRefreshedAt: Date?
    @Published private(set) var isRefreshingHomeData = false
    @Published private(set) var isConnecting = false
    @Published var message: String?
    @Published var hasAcceptedDataNotice: Bool
    @Published private(set) var hasAcceptedFirstConnectionNotice: Bool
    @Published private(set) var showsFirstConnectionNotice = false
    @Published private(set) var nodes: [SewerNode]
    @Published var selectedNodeID: String?
    @Published private(set) var accountSummary: SewerAccountSummary?
    @Published private(set) var routingMode: SewerRoutingMode
    @Published private(set) var connectionHealth: ConnectionHealth = .notChecked
    @Published private(set) var connectionPhase: ConnectionAttemptPhase = .idle
    @Published private(set) var currentLinePlanValidation: SewerLinePlanValidation?
    @Published private(set) var keepConnected: Bool
    @Published private(set) var accelerationEnabled: Bool
    @Published private(set) var accelerationStatus: String?
    private var keepConnectedPausedByManualDisconnect: Bool
    private var connectionAttemptCancelled = false
    @Published private(set) var tunnelDiagnostics: [TunnelDiagnosticEvent]
    @Published private(set) var notices: [SewerNotice] = []
    @Published private(set) var noticeTotal = 0
    @Published private(set) var isRefreshingNotices = false
    @Published private(set) var noticeError: String?
    @Published private(set) var pendingNotice: SewerNotice?

    let api = SewerAPIClient()
    let vpn = VPNService()
    private var vpnStateObserver: AnyCancellable?
    private var vpnStatusObserver: AnyCancellable?
    private var vpnRecoveryObserver: AnyCancellable?
    private var appLifecycleObserver: AnyCancellable?
    private var automaticRecoveryTask: Task<Void, Never>?
    private var connectivityMonitorTask: Task<Void, Never>?
    private var consecutiveConnectivityFailures = 0
    private var planValidationTick = 0
    private var hasLoadedNotices = false
    private var nextNoticePage = 1

    var isBusy: Bool {
        isLoggingIn || isRefreshingSubscription || isRefreshingHomeData || isConnecting
    }

    init() {
        let restoredSession = try? SessionStore.load()
        session = restoredSession
        hasAcceptedDataNotice = UserDefaults.standard.bool(forKey: "sewer.data-notice.accepted.v2")
        hasAcceptedFirstConnectionNotice = UserDefaults.standard.bool(forKey: "sewer.first-connection-notice.accepted.v1")
        let restoredSubscription = restoredSession == nil ? nil : try? SubscriptionCacheStore.load()
        nodes = restoredSubscription?.nodes ?? []
        subscriptionRefreshedAt = restoredSubscription?.refreshedAt
        selectedNodeID = UserDefaults.standard.string(forKey: "sewer.selected-node-id.v1")
        accountSummary = restoredSession == nil ? nil : (try? AccountSummaryStore.load())
        routingMode = SewerRoutingMode(rawValue: UserDefaults.standard.string(forKey: "sewer.routing-mode.v1") ?? "") ?? .splitTunnel
        keepConnected = UserDefaults.standard.bool(forKey: "sewer.keep-connected.v1")
        accelerationEnabled = UserDefaults.standard.object(forKey: "sewer.edge-acceleration.v1") as? Bool ?? false
        accelerationStatus = nil
        keepConnectedPausedByManualDisconnect = UserDefaults.standard.bool(forKey: "sewer.keep-connected-paused.v1")
        tunnelDiagnostics = TunnelDiagnostics.events()
        if keepConnected && !keepConnectedPausedByManualDisconnect {
            vpn.setKeepConnected(true)
        }
        if restoredSession == nil {
            // A sign-out can be interrupted by process termination after the
            // Keychain session is cleared but before Network Extension cleanup
            // finishes. Never leave an authenticated tunnel running on a cold
            // launch that has no session.
            Task { await vpn.removeConfigurationAfterLogout() }
        }
        BackgroundConnectionRefresh.shared.register(with: self)
        if keepConnected && !keepConnectedPausedByManualDisconnect {
            BackgroundConnectionRefresh.shared.schedule()
        }
        // SwiftUI observes AppModel, not its nested VPNService instance. Relay
        // VPN status changes so connection controls update without requiring a
        // separate page refresh.
        vpnStateObserver = vpn.objectWillChange
            .receive(on: RunLoop.main)
            .sink { [weak self] _ in
                self?.objectWillChange.send()
                self?.publishWidgetSnapshot()
            }
        vpnStatusObserver = vpn.$status
            .receive(on: RunLoop.main)
            .sink { [weak self] status in
                guard let self else { return }
                if status == .connected {
                    self.startConnectivityMonitor()
                } else if status != .connecting && status != .reasserting {
                    self.stopConnectivityMonitor()
                }
            }
        vpnRecoveryObserver = vpn.$unexpectedDisconnectID
            .dropFirst()
            .receive(on: RunLoop.main)
            .sink { [weak self] identifier in
                self?.scheduleAutomaticRecovery(for: identifier)
            }
        appLifecycleObserver = NotificationCenter.default.publisher(
            for: UIApplication.didBecomeActiveNotification
        )
        .receive(on: RunLoop.main)
        .sink { [weak self] _ in
            Task { @MainActor [weak self] in
                await self?.refreshVPNStateAfterReturningToForeground()
            }
        }
        publishWidgetSnapshot()
    }

    func acceptDataNotice() {
        UserDefaults.standard.set(true, forKey: "sewer.data-notice.accepted.v2")
        hasAcceptedDataNotice = true
    }

    func acceptFirstConnectionNotice() {
        UserDefaults.standard.set(true, forKey: "sewer.first-connection-notice.accepted.v1")
        hasAcceptedFirstConnectionNotice = true
        showsFirstConnectionNotice = false
        Task { await performConnectionAction() }
    }

    func dismissFirstConnectionNotice() {
        showsFirstConnectionNotice = false
    }

    func localizationDidChange() {
        message = nil
        subscriptionError = nil
        noticeError = nil
        accelerationStatus = nil
    }

    func login(email: String, password: String) async {
        guard hasAcceptedDataNotice else {
            message = "请先阅读并确认数据使用说明。".appLocalized
            return
        }
        guard !email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty, !password.isEmpty else {
            message = "请输入邮箱和密码。".appLocalized
            return
        }
        guard !isLoggingIn else { return }

        isLoggingIn = true
        defer { isLoggingIn = false }
        subscriptionError = nil
        do {
            let login = try await api.login(email: email, password: password)
            let value = SewerSession(
                email: email,
                authorization: login.authentication.authData,
                token: login.authentication.token,
                baseURL: login.baseURL,
                isAdmin: login.authentication.isAdmin
            )
            try SessionStore.save(value)
            api.clearDeviceIdentity()
            try? SubscriptionCacheStore.clear()
            try? AccountSummaryStore.clear()
            UserDefaults.standard.removeObject(forKey: "sewer.selected-node-id.v1")
            session = value
            nodes = []
            subscriptionRefreshedAt = nil
            selectedNodeID = nil
            currentLinePlanValidation = nil
            await refreshSubscription(force: true)
            await refreshAccountSummary(force: true)
            await refreshNotices(force: true)
            publishWidgetSnapshot()
        } catch {
            message = error.localizedDescription
        }
    }

    func logout() {
        let previousSession = session
        do {
            // Do not present a logged-out UI while a failed Keychain deletion
            // could silently restore the same authenticated session on the next
            // launch. Keep the current state and let the user retry instead.
            try SessionStore.clear()
        } catch {
            message = error.localizedDescription
            return
        }
        cancelConnectionAttempt()
        keepConnected = false
        UserDefaults.standard.set(false, forKey: "sewer.keep-connected.v1")
        keepConnectedPausedByManualDisconnect = false
        UserDefaults.standard.set(false, forKey: "sewer.keep-connected-paused.v1")
        vpn.setKeepConnected(false)
        BackgroundConnectionRefresh.shared.cancel()
        Task { await vpn.removeConfigurationAfterLogout() }
        TunnelDiagnostics.record(source: "客户端", message: "已退出当前账户。")
        refreshTunnelDiagnostics()
        connectionHealth = .notChecked
        connectionPhase = .idle
        isConnecting = false
        try? SubscriptionCacheStore.clear()
        try? AccountSummaryStore.clear()
        session = nil
        nodes = []
        subscriptionRefreshedAt = nil
        selectedNodeID = nil
        currentLinePlanValidation = nil
        accountSummary = nil
        notices = []
        noticeTotal = 0
        noticeError = nil
        pendingNotice = nil
        subscriptionError = nil
        hasLoadedNotices = false
        nextNoticePage = 1
        UserDefaults.standard.removeObject(forKey: "sewer.selected-node-id.v1")
        publishWidgetSnapshot()
        api.clearDeviceIdentity()
        if let previousSession {
            Task {
                try? await api.acknowledgeLogout(for: previousSession)
            }
        }
    }

    func refreshSubscription(force: Bool = false) async {
        guard let session else { return }
        if !force, let cache = try? SubscriptionCacheStore.load(), Date().timeIntervalSince(cache.refreshedAt) < 12 * 60 * 60 {
            let previousNode = nodes.first { $0.id == selectedNodeID }
            nodes = cache.nodes
            subscriptionRefreshedAt = cache.refreshedAt
            reconcileSelectedNode(afterLoading: cache.nodes, previousNode: previousNode)
            subscriptionError = nil
            publishWidgetSnapshot()
            return
        }
        guard !isRefreshingSubscription else { return }

        isRefreshingSubscription = true
        defer { isRefreshingSubscription = false }
        do {
            let bundle = try await api.subscription(for: session)
            let loaded = bundle.nodes
            // A sign-out or a newer login may happen while the request is in
            // flight. Do not restore the previous account's private nodes.
            guard self.session == session else { return }
            let cache = SubscriptionCache(nodes: loaded, refreshedAt: Date())
            try SubscriptionCacheStore.save(cache)
            subscriptionRefreshedAt = cache.refreshedAt
            let previousNode = nodes.first { $0.id == selectedNodeID }
            nodes = loaded
            reconcileSelectedNode(afterLoading: loaded, previousNode: previousNode)
            subscriptionError = nil
            publishWidgetSnapshot()
        } catch {
            if self.session == session {
                subscriptionError = error.localizedDescription
            }
        }
    }

    func selectNode(_ node: SewerNode) {
        guard !vpn.isActive else {
            message = "请先断开当前连接后再切换线路。".appLocalized
            return
        }
        guard SewerCoreRouter.supports(node) else {
            message = "当前线路的协议、传输或安全设置不受支持。".appLocalized
            return
        }
        selectedNodeID = node.id
        currentLinePlanValidation = nil
        UserDefaults.standard.set(node.id, forKey: "sewer.selected-node-id.v1")
        if accelerationEnabled, !SewerEdgeOptimizer.shared.supports(node) {
            accelerationStatus = "当前线路不支持智能加速。".appLocalized
        } else if accelerationEnabled {
            accelerationStatus = "将在连接时自动选择低延迟边缘节点。".appLocalized
        } else {
            accelerationStatus = nil
        }
        publishWidgetSnapshot()
    }

    func selectRoutingMode(_ mode: SewerRoutingMode) {
        guard !vpn.isActive else {
            message = "请先断开当前连接后再切换路由模式。".appLocalized
            return
        }
        routingMode = mode
        UserDefaults.standard.set(mode.rawValue, forKey: "sewer.routing-mode.v1")
    }

    func setAccelerationEnabled(_ enabled: Bool) {
        guard !vpn.isActive else {
            message = "请先断开连接后再切换智能加速。".appLocalized
            return
        }
        if enabled, let selectedNode, !SewerEdgeOptimizer.shared.supports(selectedNode) {
            message = "当前线路不支持智能加速。".appLocalized
            return
        }
        accelerationEnabled = enabled
        accelerationStatus = enabled ? "将在连接时自动选择低延迟边缘节点。" : nil
        UserDefaults.standard.set(enabled, forKey: "sewer.edge-acceleration.v1")
    }

    var selectedNode: SewerNode? {
        nodes.first { $0.id == selectedNodeID }
    }

    func linePlanValidation(for node: SewerNode) -> SewerLinePlanValidation? {
        guard let plans = accountSummary?.userPlans, !plans.isEmpty else { return nil }
        return SewerSubscriptionPolicy.validateCurrentLine(
            plans: plans,
            isEnterprise: accountSummary?.isEnterprise ?? false,
            lineName: node.name
        )
    }

    var accountTypeDescription: String {
        if session?.isAdmin == true {
            return "管理员".appLocalized
        }
        return accountSummary?.displayUserType ?? ""
    }

    var canConnectSelectedNode: Bool {
        selectedNode.map(SewerCoreRouter.supports) ?? false
    }

    var canChangeSelectedNode: Bool {
        !vpn.isActive
    }

    var canChangeRoutingMode: Bool {
        !vpn.isActive
    }

    var connectionActionTitle: String {
        if vpn.isStoppingInBackground { return "正在完成断开".appLocalized }
        if case .reconnecting = connectionPhase { return "停止重连".appLocalized }
        if connectionPhase.isInProgress { return "连接中".appLocalized }
        switch vpn.status {
        case .connected: return "断开连接".appLocalized
        case .connecting, .reasserting: return "取消连接".appLocalized
        case .disconnecting: return "重试断开".appLocalized
        default: return "连接".appLocalized
        }
    }

    var connectionActionDisabled: Bool {
        if vpn.isStoppingInBackground { return true }
        if connectionPhase.isInProgress { return false }
        if vpn.isActive {
            return false
        }
        return isBusy || !canConnectSelectedNode
    }

    var subscriptionStatusDescription: String {
        guard let refreshedAt = subscriptionRefreshedAt else {
            return "尚未更新".appLocalized
        }
        if Date().timeIntervalSince(refreshedAt) < 60 {
            return "刚刚更新".appLocalized
        }
        return "更新于 %@".appLocalized(arguments: AppLanguage.formattedDate(
            refreshedAt,
            dateStyle: .abbreviated,
            timeStyle: .shortened
        ))
    }

    func prepareHome() async {
        do {
            try await vpn.load()
        } catch {
            // Packet Tunnel preferences are not available in Simulator and can be
            // temporarily unavailable before first configuration on a device.
            // A user-initiated connection retries this operation and surfaces a
            // meaningful error only if it still cannot proceed.
        }
        await consumePendingWidgetActionIfNeeded()
        await refreshSubscription()
        await refreshAccountSummary()
        await refreshNotices()
        // VPN preferences can outlive the app process. Once the cached route
        // list is available, handle a recovery event that arrived during the
        // initial load instead of losing it because no node was selectable yet.
        if vpn.unexpectedDisconnectID > 0 {
            scheduleAutomaticRecovery(for: vpn.unexpectedDisconnectID)
        }
        await ensureKeepConnectedConnection()
        refreshTunnelDiagnostics()
    }

    private func ensureKeepConnectedConnection() async {
        guard keepConnected,
              !keepConnectedPausedByManualDisconnect,
              session != nil,
              selectedNode != nil,
              !vpn.isActive,
              !isConnecting else { return }
        connectionAttemptCancelled = false
        do {
            try await vpn.load()
        } catch {
            // connectSelectedNode will surface a user-facing error if the
            // system VPN service remains unavailable.
        }
        if vpn.shouldAutomaticallyRecover {
            scheduleAutomaticRecovery(for: max(vpn.unexpectedDisconnectID, 1))
        } else {
            // First-time enablement has no saved manager yet. Create it now;
            // subsequent failures are handled by the persistent recovery loop.
            await connectSelectedNode(automaticRecovery: true)
            if vpn.status != .connected, vpn.shouldAutomaticallyRecover {
                scheduleAutomaticRecovery(for: max(vpn.unexpectedDisconnectID, 1))
            }
        }
    }

    private func refreshVPNStateAfterReturningToForeground() async {
        guard session != nil else { return }
        do {
            try await vpn.load()
        } catch {
            return
        }
        await consumePendingWidgetActionIfNeeded()
        if vpn.status == .connected {
            startConnectivityMonitor()
        }
        if keepConnected && !keepConnectedPausedByManualDisconnect {
            await ensureKeepConnectedConnection()
        } else if !vpn.isActive, vpn.unexpectedDisconnectID > 0 {
            connectionAttemptCancelled = false
            scheduleAutomaticRecovery(for: vpn.unexpectedDisconnectID)
        }
    }

    // Background refresh is deliberately narrow: it restores an existing
    // user-requested tunnel and does not fetch subscriptions or probe sites.
    func refreshConnectionInBackground() async {
        guard session != nil,
              keepConnected,
              !keepConnectedPausedByManualDisconnect else {
            BackgroundConnectionRefresh.shared.cancel()
            return
        }
        defer { BackgroundConnectionRefresh.shared.schedule() }
        do {
            try await vpn.load()
        } catch {
            TunnelDiagnostics.record(source: "客户端", message: "后台恢复时无法读取系统 VPN 配置。")
            refreshTunnelDiagnostics()
            return
        }
        if !vpn.isActive {
            connectionAttemptCancelled = false
            await ensureKeepConnectedConnection()
        }
        if vpn.status == .connected {
            startConnectivityMonitor()
        } else {
            stopConnectivityMonitor()
        }
        publishWidgetSnapshot()
        refreshTunnelDiagnostics()
    }

    func refreshConnectionHealth() async {
        consecutiveConnectivityFailures = 0
        _ = await checkConnectivityHealth(showChecking: true)
    }

    @discardableResult
    private func checkConnectivityHealth(showChecking: Bool) async -> Bool {
        guard vpn.status == .connected else {
            connectionHealth = .notChecked
            return false
        }
        let previousHealth = connectionHealth
        if showChecking { connectionHealth = .checking }
        let result = await TunnelConnectivityProbe.check()
        guard !Task.isCancelled, vpn.status == .connected else { return false }
        if result.available {
            consecutiveConnectivityFailures = 0
            connectionHealth = .available(latencyMilliseconds: result.latencyMilliseconds)
            publishWidgetSnapshot()
            if !previousHealth.isAvailable {
                TunnelDiagnostics.record(
                    source: "客户端",
                    message: "线路端到端连通性检测通过。"
                )
            }
            return true
        }
        connectionHealth = .unavailable
        publishWidgetSnapshot()
        if !previousHealth.isUnavailable {
            TunnelDiagnostics.record(
                source: "客户端",
                message: "线路端到端连通性检测失败，将继续观察并在连续异常时自动重建。"
            )
        }
        return false
    }

    private func startConnectivityMonitor() {
        guard connectivityMonitorTask == nil,
              vpn.status == .connected,
              session != nil else { return }
        consecutiveConnectivityFailures = 0
        planValidationTick = 0
        connectivityMonitorTask = Task { [weak self] in
            defer { self?.connectivityMonitorTask = nil }
            try? await Task.sleep(nanoseconds: 15_000_000_000)
            while !Task.isCancelled {
                guard let self,
                      self.session != nil,
                      self.vpn.status == .connected else { return }
                let available = await self.checkConnectivityHealth(showChecking: false)
                if !available, self.vpn.status == .connected {
                    self.consecutiveConnectivityFailures += 1
                    if self.consecutiveConnectivityFailures >= 2 {
                        await self.recoverStalledTunnel()
                        return
                    }
                }
                self.planValidationTick += 1
                if self.planValidationTick >= 15,
                   let node = self.selectedNode,
                   let session = self.session {
                    self.planValidationTick = 0
                    if let validation = await self.fetchCurrentLinePlanValidation(for: node, session: session) {
                        self.currentLinePlanValidation = validation
                        self.publishWidgetSnapshot()
                        if !validation.allowed {
                            self.message = self.planDenialMessage(validation)
                            self.stopConnectivityMonitor()
                            await self.vpn.disconnect()
                            self.connectionHealth = .notChecked
                            return
                        }
                    }
                }
                try? await Task.sleep(nanoseconds: 20_000_000_000)
            }
        }
    }

    private func stopConnectivityMonitor() {
        connectivityMonitorTask?.cancel()
        connectivityMonitorTask = nil
        consecutiveConnectivityFailures = 0
        planValidationTick = 0
    }

    private func recoverStalledTunnel() async {
        guard !isConnecting,
              vpn.status == .connected,
              session != nil,
              selectedNode != nil,
              vpn.shouldAutomaticallyRecover else { return }
        connectionHealth = .unavailable
        connectionPhase = .reconnecting(attempt: 1)
        TunnelDiagnostics.record(
            source: "客户端",
            message: "保护通道连续检测异常，正在无感重建 Tunnel。"
        )
        await vpn.disconnect(keepConnectionIntent: true)
        await vpn.waitUntilStopped(timeout: 6)
        guard !Task.isCancelled else { return }
        await connectSelectedNode(automaticRecovery: true)
        if vpn.status != .connected, vpn.shouldAutomaticallyRecover {
            scheduleAutomaticRecovery(for: max(vpn.unexpectedDisconnectID, 1))
        }
    }

    private func fetchCurrentLinePlanValidation(
        for node: SewerNode,
        session: SewerSession
    ) async -> SewerLinePlanValidation? {
        do {
            let summary = try await api.accountSummary(for: session)
            guard self.session == session else { return nil }
            let validation = SewerSubscriptionPolicy.validateCurrentLine(
                summary: summary,
                lineName: node.name
            )
            TunnelDiagnostics.record(
                source: "客户端",
                message: validation.allowed
                    ? "当前线路套餐校验通过。"
                    : "当前线路套餐校验未通过：\(validation.reason)."
            )
            return validation
        } catch {
            TunnelDiagnostics.record(
                source: "客户端",
                message: "当前线路套餐校验请求失败：\(TunnelDiagnostics.errorSummary(error))"
            )
            return nil
        }
    }

    private func planDenialMessage(_ validation: SewerLinePlanValidation) -> String {
        let planLabel = validation.planName.map { "「\($0)」" } ?? ""
        switch validation.reason {
        case .expired:
            let expiry = formattedPlanDate(validation.access?.expiredAt)
            return "当前线路所属套餐%@已于 %@ 到期。其他套餐不受影响，请切换到有效线路。".appLocalized(arguments: planLabel, expiry)
        case .trafficExhausted:
            let used = formattedTraffic(validation.access?.used ?? 0)
            let total = formattedTraffic(validation.access?.transferEnable ?? 0)
            return "当前线路所属套餐%@流量已用尽（已用 %@ / 总量 %@）。其他套餐不受影响，请切换到可用线路。".appLocalized(arguments: planLabel, used, total)
        case .unresolved:
            return "无法确定当前线路绑定的套餐。请刷新线路后重试，避免错误使用其他套餐状态。".appLocalized
        case .unavailable, .none:
            return "暂时无法确认当前线路套餐和有效期，请检查网络后重试。".appLocalized
        }
    }

    private func formattedPlanDate(_ timestamp: Int64?) -> String {
        guard let timestamp, timestamp > 0 else { return "--" }
        return AppLanguage.formattedDate(
            Date(timeIntervalSince1970: TimeInterval(timestamp)),
            dateStyle: .abbreviated,
            timeStyle: .shortened
        )
    }

    private func formattedTraffic(_ bytes: Int64) -> String {
        let units = ["B", "KB", "MB", "GB", "TB"]
        var value = Double(max(bytes, 0))
        var index = 0
        while value >= 1_024, index < units.count - 1 {
            value /= 1_024
            index += 1
        }
        return index == 0 ? "\(Int(value)) B" : String(format: "%.2f %@", value, units[index])
    }

    func refreshHomeData() async {
        guard !isRefreshingHomeData else { return }
        isRefreshingHomeData = true
        defer { isRefreshingHomeData = false }
        await refreshSubscription(force: true)
        await refreshAccountSummary(force: true)
        await refreshNotices(force: true)
    }

    func refreshLinesAndPlanStatus() async {
        await refreshSubscription(force: true)
        await refreshAccountSummary(force: true)
        if let node = selectedNode,
           let validation = linePlanValidation(for: node) {
            currentLinePlanValidation = validation
            publishWidgetSnapshot()
        }
    }

    var hasMoreNotices: Bool {
        notices.count < noticeTotal
    }

    func refreshNotices(force: Bool = false) async {
        guard let session else { return }
        guard force || !hasLoadedNotices else { return }
        guard !isRefreshingNotices else { return }

        isRefreshingNotices = true
        noticeError = nil
        defer { isRefreshingNotices = false }
        do {
            let page = try await api.notices(for: session, currentPage: 1)
            guard self.session == session else { return }
            notices = page.data
            noticeTotal = max(page.total, page.data.count)
            hasLoadedNotices = true
            nextNoticePage = 2
            updatePendingNotice(for: session)
        } catch {
            guard self.session == session else { return }
            noticeError = error.localizedDescription
        }
    }

    func loadMoreNotices() async {
        guard let session, hasMoreNotices, !isRefreshingNotices else { return }

        isRefreshingNotices = true
        noticeError = nil
        defer { isRefreshingNotices = false }
        let nextPage = max(nextNoticePage, 2)
        do {
            let page = try await api.notices(for: session, currentPage: nextPage)
            guard self.session == session else { return }
            let existingIDs = Set(notices.map(\.id))
            let additions = page.data.filter { !existingIDs.contains($0.id) }
            notices.append(contentsOf: additions)
            noticeTotal = max(page.total, notices.count)
            nextNoticePage = nextPage + 1
            if additions.isEmpty {
                noticeTotal = notices.count
            }
        } catch {
            guard self.session == session else { return }
            noticeError = error.localizedDescription
        }
    }

    func acknowledgePendingNotice() {
        guard let session, let pendingNotice else { return }
        let key = noticeAcknowledgementKey(for: session)
        let previous = UserDefaults.standard.integer(forKey: key)
        UserDefaults.standard.set(max(previous, pendingNotice.id), forKey: key)
        self.pendingNotice = nil
    }

    private func updatePendingNotice(for session: SewerSession) {
        guard pendingNotice == nil,
              let newest = notices.filter(\.isShown).max(by: { $0.id < $1.id }) else {
            return
        }
        let acknowledgedID = UserDefaults.standard.integer(forKey: noticeAcknowledgementKey(for: session))
        if newest.id > acknowledgedID {
            pendingNotice = newest
        }
    }

    private func noticeAcknowledgementKey(for session: SewerSession) -> String {
        let hash = SHA256.hash(data: Data(session.email.lowercased().utf8))
        let identity = hash.prefix(12).map { String(format: "%02x", $0) }.joined()
        return "sewer.notice.acknowledged.v1.\(identity)"
    }

    func refreshAccountSummary(force: Bool = false) async {
        guard let session else { return }
        if !force,
           let cached = try? AccountSummaryStore.load(),
           Date().timeIntervalSince(cached.refreshedAt) < 5 * 60 {
            accountSummary = cached
            return
        }

        do {
            let subscription = try await api.accountSummary(for: session)
            // A temporary failure of the optional account-label endpoint must not
            // prevent traffic information from being shown or a tunnel from starting.
            let profile = try? await api.accountProfile(for: session)
            let summary = SewerAccountSummary(
                subscription: subscription,
                profile: profile,
                isAdmin: session.isAdmin
            )
            guard self.session == session else { return }
            try? AccountSummaryStore.save(summary)
            accountSummary = summary
            publishWidgetSnapshot()
        } catch {
            // The route panel already presents service errors and a Retry
            // action. Avoid blocking the home screen with a duplicate modal on
            // every cold launch while the optional account summary is delayed.
        }
    }

    func performConnectionAction() async {
        guard !vpn.isStoppingInBackground else { return }
        if vpn.isActive || connectionPhase.isInProgress {
            stopConnectivityMonitor()
            // A manual disconnect pauses Keep Connected for this session, but
            // preserves the user's switch preference. The next explicit
            // Connect resumes the preference automatically.
            if keepConnected {
                keepConnectedPausedByManualDisconnect = true
                UserDefaults.standard.set(true, forKey: "sewer.keep-connected-paused.v1")
                vpn.setKeepConnected(false)
                BackgroundConnectionRefresh.shared.cancel()
                TunnelDiagnostics.record(source: "客户端", message: "手动断开已暂停保持连接，下次连接将自动恢复。")
            }
            cancelConnectionAttempt()
            await vpn.disconnect()
            connectionHealth = .notChecked
            connectionPhase = .idle
            refreshTunnelDiagnostics()
            return
        }
        guard hasAcceptedFirstConnectionNotice else {
            showsFirstConnectionNotice = true
            return
        }
        if keepConnected && keepConnectedPausedByManualDisconnect {
            keepConnectedPausedByManualDisconnect = false
            UserDefaults.standard.set(false, forKey: "sewer.keep-connected-paused.v1")
            vpn.setKeepConnected(true)
            BackgroundConnectionRefresh.shared.schedule()
            TunnelDiagnostics.record(source: "客户端", message: "已恢复保持连接。")
        }
        await connectSelectedNode()
    }

    func setKeepConnected(_ enabled: Bool) async {
        keepConnected = enabled
        UserDefaults.standard.set(enabled, forKey: "sewer.keep-connected.v1")
        keepConnectedPausedByManualDisconnect = false
        UserDefaults.standard.set(false, forKey: "sewer.keep-connected-paused.v1")
        vpn.setKeepConnected(enabled)
        if !enabled {
            BackgroundConnectionRefresh.shared.cancel()
            let cancellingAutomaticRecovery = automaticRecoveryTask != nil
            automaticRecoveryTask?.cancel()
            automaticRecoveryTask = nil
            if cancellingAutomaticRecovery {
                connectionAttemptCancelled = true
            }
            if connectionPhase.isInProgress, vpn.isActive {
                await vpn.disconnect()
            }
            return
        }
        BackgroundConnectionRefresh.shared.schedule()
        await ensureKeepConnectedConnection()
    }

    func cancelConnectionAttempt() {
        connectionAttemptCancelled = true
        automaticRecoveryTask?.cancel()
        automaticRecoveryTask = nil
        stopConnectivityMonitor()
    }

    func connectSelectedNode(automaticRecovery: Bool = false) async {
        guard hasAcceptedFirstConnectionNotice else {
            showsFirstConnectionNotice = true
            return
        }
        guard let session else {
            message = "登录状态已失效，请重新登录。".appLocalized
            return
        }
        guard let node = selectedNode else {
            message = "请先选择线路。".appLocalized
            return
        }
        guard !isConnecting else { return }
        guard !vpn.isStoppingInBackground else {
            message = "系统正在完成上一次断开，请稍候再连接。".appLocalized
            return
        }
        if !automaticRecovery {
            automaticRecoveryTask?.cancel()
            automaticRecoveryTask = nil
        }
        // Diagnostics belong to one connection attempt. Clearing both shared
        // event storage and the core error file prevents an earlier session's
        // outcome from being mistaken for the new attempt.
        if !automaticRecovery {
            TunnelDiagnostics.clear()
        }
        TunnelDiagnostics.clearXrayErrorLog()
        if !automaticRecovery {
            tunnelDiagnostics = []
        }
        connectionHealth = .notChecked
        connectionPhase = automaticRecovery ? .reconnecting(attempt: 1) : .checkingInternet
        isConnecting = true
        connectionAttemptCancelled = false
        defer {
            isConnecting = false
            connectionPhase = .idle
            refreshTunnelDiagnostics()
        }
        guard await ConnectivityProbe.networkPathIsAvailable() else {
            connectionHealth = .notChecked
            TunnelDiagnostics.record(source: "客户端".appLocalized, message: "连接前网络状态不可用。".appLocalized)
            if !automaticRecovery {
                message = "连接失败！请先检查网络连接。".appLocalized
            }
            return
        }

        connectionPhase = .checkingPlan
        guard let validation = await fetchCurrentLinePlanValidation(for: node, session: session) else {
            currentLinePlanValidation = nil
            message = "暂时无法确认当前线路所属套餐和有效期，请检查网络后重试。".appLocalized
            return
        }
        currentLinePlanValidation = validation
        publishWidgetSnapshot()
        guard validation.allowed else {
            message = planDenialMessage(validation)
            return
        }

        // A transient interruption can hit any stage while establishing the
        // tunnel or waiting for the system to report connected. Retry the whole
        // attempt a few times with a short backoff instead of failing on the
        // first hiccup. The system-level
        // on-demand rule covers interruptions while the app is backgrounded.
        let maximumAttempts = automaticRecovery ? 6 : 3
        for attempt in 1...maximumAttempts {
            if connectionAttemptCancelled { return }
            if automaticRecovery {
                connectionPhase = .reconnecting(attempt: attempt)
                if attempt > 1 {
                    TunnelDiagnostics.record(source: "客户端", message: "连接中断，正在自动重连（第 \(attempt) 次）。")
                    // Keep automatic recovery responsive. A short yield gives
                    // iOS time to publish the previous stop without imposing
                    // the long exponential delays used for manual attempts.
                    for _ in 0..<2 {
                        if connectionAttemptCancelled { return }
                        try? await Task.sleep(nanoseconds: 250_000_000)
                    }
                    if connectionAttemptCancelled { return }
                }
                guard await ConnectivityProbe.networkPathIsAvailable() else {
                    TunnelDiagnostics.record(source: "客户端", message: "等待系统网络恢复后继续自动重连。")
                    // Return to the persistent recovery loop. It waits with a
                    // short bounded delay instead of spinning through all six
                    // attempts while the device has no usable network path.
                    return
                }
            } else if attempt > 1 {
                connectionPhase = .reconnecting(attempt: attempt)
                TunnelDiagnostics.record(source: "客户端", message: "连接中断，正在自动重连（第 \(attempt) 次）。")
                let backoffSeconds = UInt64(1 << (attempt - 1))
                for _ in 0..<(backoffSeconds * 4) {
                    if connectionAttemptCancelled { return }
                    try? await Task.sleep(nanoseconds: 250_000_000)
                }
                if connectionAttemptCancelled { return }
                guard await ConnectivityProbe.networkPathIsAvailable() else {
                    continue
                }
            }

            connectionHealth = .checking
            if !automaticRecovery {
                connectionPhase = .establishingTunnel
            }
            TunnelDiagnostics.record(source: "客户端".appLocalized, message: "连接前网络状态正常。".appLocalized)

            var attemptSucceeded = false
            var attemptReason: String?
            do {
                var optimizedAddresses: [String] = []
                if accelerationEnabled, SewerEdgeOptimizer.shared.supports(node) {
                    accelerationStatus = "正在测试低延迟边缘节点…".appLocalized
                    optimizedAddresses = await SewerEdgeOptimizer.shared.optimizedAddresses(for: node)
                    if connectionAttemptCancelled { return }
                    accelerationStatus = optimizedAddresses.isEmpty
                        ? "当前网络未找到更优边缘节点，将使用自动线路。".appLocalized
                        : "智能加速已启用 · %d 个健康边缘".appLocalized(arguments: optimizedAddresses.count)
                } else {
                    accelerationStatus = nil
                }
                try await vpn.connect(
                    using: node,
                    routingMode: routingMode,
                    optimizedAddresses: optimizedAddresses
                )
                let connectionResult = await vpn.waitUntilConnected()
                switch connectionResult {
                case .connected:
                    attemptSucceeded = true
                case let .failed(reason):
                    attemptReason = reason
                }
            } catch {
                attemptReason = error.localizedDescription
                TunnelDiagnostics.record(
                    source: "客户端".appLocalized,
                    message: "连接请求失败：%@".appLocalized(arguments: TunnelDiagnostics.errorSummary(error))
                )
            }

            if attemptSucceeded {
                TunnelDiagnostics.record(source: "客户端".appLocalized, message: "Tunnel 已建立。".appLocalized)
                startConnectivityMonitor()
                await checkConnectivityHealth(showChecking: true)
                return
            }

            if accelerationEnabled, SewerEdgeOptimizer.shared.supports(node) {
                await SewerEdgeOptimizer.shared.failover(for: node)
            }

            // Establishment failed. Tear down anything the system may still be
            // completing, then retry unless this was the final attempt.
            await vpn.disconnect(keepConnectionIntent: automaticRecovery)
            connectionHealth = .notChecked
            if attempt < maximumAttempts {
                TunnelDiagnostics.record(source: "客户端", message: "连接过程中断，正在自动重连。")
                await vpn.waitUntilStopped()
                continue
            }
            await vpn.waitUntilStopped()
            if automaticRecovery {
                TunnelDiagnostics.record(source: "客户端", message: "本轮自动重连未成功，立即开始下一轮恢复。")
            } else if let reason = attemptReason {
                message = "连接失败：%@".appLocalized(arguments: reason)
            } else {
                message = "连接失败。请检查线路，并确认系统已允许 SEWER 的 VPN 配置。".appLocalized
            }
            return
        }
    }

    private func scheduleAutomaticRecovery(for identifier: Int) {
        guard identifier > 0,
              automaticRecoveryTask == nil,
              !isConnecting,
              !connectionAttemptCancelled,
              session != nil,
              selectedNode != nil,
              !vpn.isActive,
              vpn.shouldAutomaticallyRecover else {
            return
        }

        connectionHealth = .notChecked
        connectionPhase = .reconnecting(attempt: 1)
        TunnelDiagnostics.record(source: "客户端", message: "保护通道意外中断，正在立即自动恢复。")
        refreshTunnelDiagnostics()
        automaticRecoveryTask = Task { [weak self] in
            defer {
                // The task may be cancelled while waiting for the system or
                // while the app is backgrounded. Always release the handle so
                // a later status event can schedule a fresh recovery.
                self?.automaticRecoveryTask = nil
            }
            // Keep retrying until the user explicitly cancels the connection
            // intent. Connect On Demand may already be recovering the tunnel;
            // wait for that attempt before starting another one.
            while !Task.isCancelled,
                  let self,
                  self.vpn.shouldAutomaticallyRecover,
                  !self.connectionAttemptCancelled,
                  self.session != nil,
                  self.selectedNode != nil {
                if self.vpn.status == .connected {
                    return
                }
                if self.vpn.status == .connecting || self.vpn.status == .reasserting {
                    if case .connected = await self.vpn.waitUntilConnected(timeout: 20) {
                        return
                    }
                }
                guard !self.vpn.isActive else {
                    try? await Task.sleep(nanoseconds: 250_000_000)
                    continue
                }
                guard await ConnectivityProbe.networkPathIsAvailable() else {
                    // Retry promptly when connectivity returns without a tight
                    // MainActor loop or repeatedly alerting the user.
                    try? await Task.sleep(nanoseconds: 1_000_000_000)
                    continue
                }
                self.connectionPhase = .reconnecting(attempt: 1)
                await self.connectSelectedNode(automaticRecovery: true)
                guard !Task.isCancelled,
                      self.vpn.shouldAutomaticallyRecover,
                      !self.connectionAttemptCancelled else {
                    return
                }
                if self.vpn.status == .connected {
                    return
                }
                if self.vpn.isActive {
                    await self.vpn.waitUntilStopped(timeout: 5)
                }
                // Immediate next cycle; this yield prevents a tight actor loop
                // while keeping recovery responsive during an outage.
                await Task.yield()
            }
        }
    }

    func refreshTunnelDiagnostics() {
        tunnelDiagnostics = TunnelDiagnostics.events()
    }

    func handleWidgetURL(_ url: URL) async {
        guard url.scheme?.lowercased() == "sewer" else { return }
        // The AppIntent queues exactly one pending action before opening this
        // URL. Consuming it here must not queue a second action, otherwise a
        // cold launch can connect and immediately disconnect again.
        await consumePendingWidgetActionIfNeeded()
    }

    func consumePendingWidgetActionIfNeeded() async {
        guard WidgetSharedStore.consumeToggleRequest() else { return }
        guard session != nil else { return }
        await performConnectionAction()
    }

    private func publishWidgetSnapshot() {
        let state: String
        switch vpn.status {
        case .connected:
            state = "connected"
        case .connecting, .reasserting:
            state = "connecting"
        default:
            state = "disconnected"
        }
        let healthState: String
        let latencyMilliseconds: Int
        switch connectionHealth {
        case .available(let latency):
            healthState = "available"
            latencyMilliseconds = latency
        case .checking:
            healthState = "checking"
            latencyMilliseconds = 0
        case .unavailable:
            healthState = "unavailable"
            latencyMilliseconds = 0
        case .notChecked:
            healthState = "unknown"
            latencyMilliseconds = 0
        }
        let planExpiry = currentLinePlanValidation?.access?.expiredAt.flatMap { timestamp -> Date? in
            guard timestamp > 0 else { return nil }
            return Date(timeIntervalSince1970: TimeInterval(timestamp))
        }
        WidgetSharedStore.save(snapshot: SewerWidgetSnapshot(
            remainingTraffic: accountSummary?.trafficDescription ?? "--",
            routeName: selectedNode?.name ?? "",
            planName: currentLinePlanValidation?.planName ?? "",
            expiresAt: planExpiry,
            connectionState: state,
            healthState: healthState,
            latencyMilliseconds: latencyMilliseconds,
            updatedAt: Date()
        ))
        WidgetCenter.shared.reloadTimelines(ofKind: WidgetSharedConstants.statusWidgetKind)
        if #available(iOS 18.0, *) {
            ControlCenter.shared.reloadControls(ofKind: "top.sewer.client.ios.control")
        }
    }

    func clearTunnelDiagnostics() {
        TunnelDiagnostics.clear()
        tunnelDiagnostics = []
    }

    var tunnelDiagnosticsText: String {
        tunnelDiagnostics.reversed().map { event in
            "[\(AppLanguage.formattedDate(event.timestamp, dateStyle: .numeric, timeStyle: .standard))] \(event.source)：\(event.message)"
        }.joined(separator: "\n")
    }

    private func reconcileSelectedNode(afterLoading loaded: [SewerNode], previousNode: SewerNode?) {
        if let selectedNodeID, loaded.contains(where: { $0.id == selectedNodeID }) {
            return
        }

        // Subscription providers commonly rotate an endpoint while retaining its
        // display name. Keep a uniquely identifiable user choice in that case.
        if let previousNode {
            let replacements = loaded.filter {
                $0.scheme == previousNode.scheme && $0.name == previousNode.name
            }
            if replacements.count == 1, let replacement = replacements.first {
                selectedNodeID = replacement.id
                UserDefaults.standard.set(replacement.id, forKey: "sewer.selected-node-id.v1")
                return
            }
        }

        if let defaultNode = loaded.first(where: SewerCoreRouter.supports) ?? loaded.first {
            selectedNodeID = defaultNode.id
            UserDefaults.standard.set(defaultNode.id, forKey: "sewer.selected-node-id.v1")
        } else {
            selectedNodeID = nil
            UserDefaults.standard.removeObject(forKey: "sewer.selected-node-id.v1")
        }
    }
}

private final class NetworkPathProbe: @unchecked Sendable {
    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "top.sewer.client.ios.network-path")
    private let lock = NSLock()
    private var hasResult = false
    private var continuation: CheckedContinuation<Bool, Never>?

    func result() async -> Bool {
        await withCheckedContinuation { continuation in
            lock.lock()
            self.continuation = continuation
            lock.unlock()
            monitor.pathUpdateHandler = { [weak self] path in
                self?.finish(path.status == .satisfied)
            }
            monitor.start(queue: queue)
            queue.asyncAfter(deadline: .now() + 3) { [weak self] in
                self?.finish(false)
            }
        }
    }

    private func finish(_ available: Bool) {
        lock.lock()
        guard !hasResult, let continuation else {
            lock.unlock()
            return
        }
        hasResult = true
        self.continuation = nil
        lock.unlock()
        monitor.cancel()
        continuation.resume(returning: available)
    }
}

private enum ConnectivityProbe {
    static func networkPathIsAvailable() async -> Bool {
        await NetworkPathProbe().result()
    }
}

private enum TunnelConnectivityProbe {
    private static let probeURL = URL(string: "https://captive.apple.com/hotspot-detect.html")!

    static func check() async -> (available: Bool, latencyMilliseconds: Int) {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 6
        configuration.timeoutIntervalForResource = 8
        configuration.waitsForConnectivity = false
        let session = URLSession(configuration: configuration)
        defer { session.invalidateAndCancel() }

        var request = URLRequest(url: probeURL)
        request.httpMethod = "GET"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.timeoutInterval = 6
        request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")
        let startedAt = Date()
        do {
            let (_, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse,
                  (200...399).contains(http.statusCode) else {
                return (false, 0)
            }
            let latency = Int(Date().timeIntervalSince(startedAt) * 1_000)
            return (true, max(latency, 1))
        } catch {
            return (false, 0)
        }
    }
}
