import Foundation

enum AppLanguage: String, CaseIterable {
    case system
    case simplifiedChinese = "zh-Hans"
    case english = "en"

    static let preferenceKey = "sewer.app-language.v1"
    private static let appGroupIdentifier = "group.top.sewer.client.ios"

    static func locale(for identifier: String) -> Locale {
        switch AppLanguage(rawValue: identifier) ?? .system {
        case .system:
            return .autoupdatingCurrent
        case .simplifiedChinese:
            return Locale(identifier: "zh-Hans")
        case .english:
            return Locale(identifier: "en")
        }
    }

    static func persist(_ identifier: String) {
        let value = AppLanguage(rawValue: identifier)?.rawValue ?? AppLanguage.system.rawValue
        UserDefaults.standard.set(value, forKey: preferenceKey)
        UserDefaults(suiteName: appGroupIdentifier)?.set(value, forKey: preferenceKey)
    }

    static func formattedDate(
        _ date: Date,
        dateStyle: Date.FormatStyle.DateStyle,
        timeStyle: Date.FormatStyle.TimeStyle
    ) -> String {
        date.formatted(
            Date.FormatStyle(
                date: dateStyle,
                time: timeStyle,
                locale: Locale(identifier: resourceIdentifier)
            )
        )
    }

    static var resourceIdentifier: String {
        let preference = UserDefaults.standard.string(forKey: preferenceKey)
            ?? UserDefaults(suiteName: appGroupIdentifier)?.string(forKey: preferenceKey)
            ?? AppLanguage.system.rawValue

        switch AppLanguage(rawValue: preference) ?? .system {
        case .simplifiedChinese:
            return "zh-Hans"
        case .english:
            return "en"
        case .system:
            let systemLanguage = Locale.preferredLanguages.first?.lowercased() ?? ""
            return systemLanguage.hasPrefix("zh") ? "zh-Hans" : "en"
        }
    }
}

enum AppLocalization {
    static func text(_ key: String) -> String {
        let bundle = localizedBundle ?? .main
        return bundle.localizedString(forKey: key, value: key, table: "Localizable")
    }

    static func format(_ key: String, arguments: [CVarArg]) -> String {
        String(
            format: text(key),
            locale: Locale(identifier: AppLanguage.resourceIdentifier),
            arguments: arguments
        )
    }

    private static var localizedBundle: Bundle? {
        guard let path = Bundle.main.path(
            forResource: AppLanguage.resourceIdentifier,
            ofType: "lproj"
        ) else {
            return nil
        }
        return Bundle(path: path)
    }
}

extension String {
    var appLocalized: String {
        AppLocalization.text(self)
    }

    func appLocalized(arguments: CVarArg...) -> String {
        AppLocalization.format(self, arguments: arguments)
    }
}
