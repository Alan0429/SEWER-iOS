import Foundation

enum SingBoxConfigurationError: LocalizedError {
    case invalidNode
    case unsupportedScheme(String)
    case unsupportedShadowsocksPlugin

    var errorDescription: String? {
        switch self {
        case .invalidNode:
            return "SOCKS5 或 Shadowsocks 线路配置不完整。".appLocalized
        case .unsupportedScheme(let value):
            return "sing-box 不支持 %@ 线路。".appLocalized(arguments: value.uppercased())
        case .unsupportedShadowsocksPlugin:
            return "当前 iOS 客户端仅支持内置 obfs-local 与 v2ray-plugin，其他 Shadowsocks 插件不可用。".appLocalized
        }
    }
}

struct SingBoxConfigurationFactory {
    private static let supportedSchemes: Set<String> = ["socks", "socks5", "socks5h", "ss"]
    private static let supportedShadowsocksPlugins: Set<String> = ["obfs-local", "v2ray-plugin"]

    static func supports(_ node: SewerNode) -> Bool {
        guard supportedSchemes.contains(node.scheme.lowercased()) else { return false }
        return (try? make(for: node, routingMode: .splitTunnel, resolvedAddresses: [])) != nil
    }

    static func remoteHost(for node: SewerNode) throws -> String {
        switch node.scheme.lowercased() {
        case "socks", "socks5", "socks5h":
            let components = try socksComponents(for: node)
            guard let host = components.host, !host.isEmpty else { throw SingBoxConfigurationError.invalidNode }
            return host
        case "ss":
            return try shadowsocksEndpoint(for: node).host
        default:
            throw SingBoxConfigurationError.unsupportedScheme(node.scheme)
        }
    }

    static func make(
        for node: SewerNode,
        routingMode: SewerRoutingMode,
        resolvedAddresses: [String]
    ) throws -> String {
        let remoteHost = try remoteHost(for: node)
        let proxy = try outbound(for: node)
        var rules: [[String: Any]] = [
            ["action": "sniff"],
            ["protocol": "dns", "action": "hijack-dns"],
            [
                "domain_suffix": ["sewer.top", "sewer.com.cn", "sewer-dns.top"],
                "outbound": "direct"
            ],
            ["ip_is_private": true, "outbound": "direct"]
        ]
        if routingMode == .splitTunnel {
            rules.append([
                "domain_suffix": [".cn"],
                "outbound": "direct"
            ])
        }

        var dnsServers: [[String: Any]] = [[
                "type": "tcp",
                "tag": "remote-dns",
                "server": "1.1.1.1",
                "detour": "proxy"
            ]]
        var dnsRules: [[String: Any]] = []
        var dns: [String: Any] = [
            "servers": dnsServers,
            "final": "remote-dns",
            "strategy": "prefer_ipv4"
        ]
        if !resolvedAddresses.isEmpty {
            // Keep the subscribed hostname in the outbound so SIP003 TLS and
            // certificate handling retain the original SNI. The app supplies
            // addresses obtained through its protected bootstrap resolver, so
            // sing-box does not need to query a polluted local resolver.
            dnsServers.append([
                "type": "hosts",
                "tag": "pinned-hosts",
                "path": [],
                "predefined": [remoteHost: resolvedAddresses]
            ])
            dnsRules.append([
                "domain": [remoteHost],
                "server": "pinned-hosts"
            ])
            dns["servers"] = dnsServers
            dns["rules"] = dnsRules
        }

        let config: [String: Any] = [
            "log": ["level": "warn"],
            "dns": dns,
            "inbounds": [[
                "type": "tun",
                "tag": "tun-in",
                "address": ["10.254.0.2/24", "fd00:254::2/64"],
                "mtu": 1500,
                "auto_route": false,
                "strict_route": false
            ]],
            "outbounds": [
                proxy,
                ["type": "direct", "tag": "direct"]
            ],
            "route": [
                "rules": rules,
                "final": "proxy",
                "auto_detect_interface": false,
                "default_domain_resolver": "remote-dns"
            ]
        ]

        let data = try JSONSerialization.data(withJSONObject: config, options: [.sortedKeys])
        guard let json = String(data: data, encoding: .utf8) else {
            throw SingBoxConfigurationError.invalidNode
        }
        return json
    }

    private static func outbound(for node: SewerNode) throws -> [String: Any] {
        let host = try remoteHost(for: node)
        switch node.scheme.lowercased() {
        case "socks", "socks5", "socks5h":
            let components = try socksComponents(for: node)
            guard let port = components.port, (1...65_535).contains(port) else {
                throw SingBoxConfigurationError.invalidNode
            }
            var outbound: [String: Any] = [
                "type": "socks",
                "tag": "proxy",
                "server": host,
                "server_port": port,
                "version": "5"
            ]
            let username = components.user?.removingPercentEncoding ?? ""
            let password = components.password?.removingPercentEncoding ?? ""
            if !username.isEmpty { outbound["username"] = username }
            if !password.isEmpty { outbound["password"] = password }
            return outbound
        case "ss":
            let endpoint = try shadowsocksEndpoint(for: node)
            var outbound: [String: Any] = [
                "type": "shadowsocks",
                "tag": "proxy",
                "server": host,
                "server_port": endpoint.port,
                "method": endpoint.method,
                "password": endpoint.password
            ]
            if !endpoint.plugin.isEmpty {
                let pluginParts = endpoint.plugin.split(separator: ";", maxSplits: 1, omittingEmptySubsequences: false)
                guard let pluginName = pluginParts.first.map(String.init),
                      supportedShadowsocksPlugins.contains(pluginName) else {
                    throw SingBoxConfigurationError.unsupportedShadowsocksPlugin
                }
                outbound["plugin"] = pluginName
                if pluginParts.count > 1, !pluginParts[1].isEmpty {
                    outbound["plugin_opts"] = String(pluginParts[1])
                }
            }
            return outbound
        default:
            throw SingBoxConfigurationError.unsupportedScheme(node.scheme)
        }
    }

    private static func socksComponents(for node: SewerNode) throws -> URLComponents {
        guard let components = URLComponents(string: node.rawURI),
              let port = components.port,
              (1...65_535).contains(port) else {
            throw SingBoxConfigurationError.invalidNode
        }
        return components
    }

    private struct ShadowsocksEndpoint {
        let method: String
        let password: String
        let host: String
        let port: Int
        let plugin: String
    }

    private static func shadowsocksEndpoint(for node: SewerNode) throws -> ShadowsocksEndpoint {
        let raw = node.rawURI
        guard raw.lowercased().hasPrefix("ss://") else { throw SingBoxConfigurationError.invalidNode }
        var body = String(raw.dropFirst("ss://".count))
        if let fragment = body.firstIndex(of: "#") { body = String(body[..<fragment]) }
        var query = ""
        if let mark = body.firstIndex(of: "?") {
            query = String(body[body.index(after: mark)...])
            body = String(body[..<mark])
        }
        body = body.trimmingCharacters(in: CharacterSet(charactersIn: "/"))

        let credential: String
        let endpointText: String
        if let at = body.lastIndex(of: "@") {
            credential = String(body[..<at])
            endpointText = String(body[body.index(after: at)...])
        } else {
            guard let decoded = decodeBase64(body),
                  let decodedText = String(data: decoded, encoding: .utf8),
                  let at = decodedText.lastIndex(of: "@") else {
                throw SingBoxConfigurationError.invalidNode
            }
            credential = String(decodedText[..<at])
            endpointText = String(decodedText[decodedText.index(after: at)...])
        }

        let credentialText: String
        if credential.contains(":") {
            credentialText = credential.removingPercentEncoding ?? credential
        } else {
            guard let decoded = decodeBase64(credential),
                  let value = String(data: decoded, encoding: .utf8) else {
                throw SingBoxConfigurationError.invalidNode
            }
            credentialText = value
        }
        guard let colon = credentialText.firstIndex(of: ":") else {
            throw SingBoxConfigurationError.invalidNode
        }
        let method = String(credentialText[..<colon])
        let password = String(credentialText[credentialText.index(after: colon)...])
        guard !method.isEmpty, !password.isEmpty else { throw SingBoxConfigurationError.invalidNode }

        guard let endpoint = URLComponents(string: "ss://\(endpointText)"),
              let host = endpoint.host, !host.isEmpty,
              let port = endpoint.port, (1...65_535).contains(port) else {
            throw SingBoxConfigurationError.invalidNode
        }
        let queryItems = URLComponents(string: "https://sewer.invalid/?\(query)")?.queryItems ?? []
        let plugin = queryItems.first(where: { $0.name.caseInsensitiveCompare("plugin") == .orderedSame })?
            .value?
            .trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        return ShadowsocksEndpoint(
            method: method,
            password: password,
            host: host,
            port: port,
            plugin: plugin
        )
    }

    private static func decodeBase64(_ value: String) -> Data? {
        var normalized = value
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
            .components(separatedBy: .whitespacesAndNewlines)
            .joined()
        normalized += String(repeating: "=", count: (4 - normalized.count % 4) % 4)
        return Data(base64Encoded: normalized)
    }
}

enum SewerCoreRouter {
    static func requiresSingBox(_ node: SewerNode) -> Bool {
        SingBoxConfigurationFactory.supports(node)
    }

    static func supports(_ node: SewerNode) -> Bool {
        XrayConfigurationFactory.supports(node) || requiresSingBox(node)
    }

    static func kind(for node: SewerNode) throws -> String {
        if requiresSingBox(node) { return "sing-box" }
        if XrayConfigurationFactory.supports(node) { return "xray" }
        throw XrayConfigurationError.unsupportedProtocol(node.scheme)
    }

    static func remoteHost(for node: SewerNode) throws -> String {
        if requiresSingBox(node) {
            return try SingBoxConfigurationFactory.remoteHost(for: node)
        }
        return try XrayConfigurationFactory.remoteHost(for: node)
    }
}
