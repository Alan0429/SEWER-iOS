import NetworkExtension
import SwiftUI
import UIKit

struct RootView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        Group {
            if !model.hasAcceptedDataNotice {
                DataNoticeView()
            } else if model.session == nil {
                LoginView()
            } else {
                HomeView()
            }
        }
        .tint(SewerPalette.blue)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.24), value: model.hasAcceptedDataNotice)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.24), value: model.session != nil)
        .alert("SEWER", isPresented: Binding(get: { model.message != nil }, set: { if !$0 { model.message = nil } })) {
            Button("确定", role: .cancel) { model.message = nil }
        } message: {
            Text(model.message ?? "")
        }
    }
}

private struct DataNoticeView: View {
    @EnvironmentObject private var model: AppModel
    @State private var showsPrivacyPolicy = false

    var body: some View {
        ScrollView {
            VStack(spacing: 26) {
                Spacer(minLength: 52)
                HStack {
                    Spacer()
                    LanguagePickerMenu()
                }
                SewerBrandLockup(subtitle: "企业网络安全访问")
                    .frame(maxWidth: .infinity)
                    .sewerEntryMotion(delay: 0)
                VStack(alignment: .leading, spacing: 12) {
                    Text("数据使用说明")
                        .font(.title2.weight(.semibold))
                        .foregroundStyle(SewerPalette.ink)
                    Text("我们处理账户标识、所选线路、设备连接状态和提供服务所需的网络技术数据。连接前仅使用系统网络状态判断，不会连接第三方网站进行探测；SEWER 与 AWS 线路域名优先使用 223.5.5.5、1.12.12.12 的 DNS over HTTPS，失败时才回落普通 DNS。隧道建立后设备 IPv4/IPv6 DNS 使用 Cloudflare 1.1.1.1 并通过所选线路转发，UDP、WebRTC/STUN 与 IPv6 流量不会绕过隧道从物理网络泄露。智能加速仅读取 Amazon 公共边缘范围并测试线路延迟。连接后如线路中断，系统会在您保持连接意图期间自动恢复。路由分类数据随客户端版本内置，不会在运行时下载。我们不出售这些数据，也不用于广告或广告定向。".appLocalized)
                        .font(.body)
                        .foregroundStyle(SewerPalette.muted)
                        .fixedSize(horizontal: false, vertical: true)
                    Text("连接后，为发现卡顿或假死，客户端会通过保护线路访问 Apple 网络状态页和 Cloudflare 连通性端点，仅处理 HTTP 状态、延迟及必要网络元数据。".appLocalized)
                        .font(.footnote)
                        .foregroundStyle(SewerPalette.muted)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .sewerEntryMotion(delay: 0.05)
                Button("我已阅读并同意") { model.acceptDataNotice() }
                    .buttonStyle(FilledActionButtonStyle(tint: SewerPalette.blue))
                    .sewerEntryMotion(delay: 0.1)
                Button("查看隐私政策") { showsPrivacyPolicy = true }
                    .font(.footnote)
                    .foregroundStyle(SewerPalette.muted)
                    .buttonStyle(.plain)
                    .sewerEntryMotion(delay: 0.14)
                Spacer(minLength: 36)
            }
            .frame(maxWidth: 680)
            .frame(maxWidth: .infinity)
            .padding(24)
        }
        .background(SewerPalette.canvas.ignoresSafeArea())
        .sheet(isPresented: $showsPrivacyPolicy) { PrivacyPolicyView() }
    }
}

private struct FirstConnectionNoticeView: View {
    let onAccept: () -> Void
    let onCancel: () -> Void

    private let items: [(String, String, String)] = [
        (
            "DNS 保护",
            "shippingbox.and.arrow.backward.fill",
            "连接后 IPv4/IPv6 DNS 将强制通过 Cloudflare 1.1.1.1 并经所选线路转发，不直接使用 Wi-Fi 或蜂窝网络的 DNS。"
        ),
        (
            "UDP 与 WebRTC",
            "shield.lefthalf.filled",
            "公网 UDP、WebRTC/STUN 与公网 IPv6 会进入受保护通道；局域网、私有网络和组播保持直连。"
        ),
        (
            "安全解析",
            "checkmark.shield.fill",
            "连接前，SEWER、AWS 边缘及位于这些受保护域名下的线路域名优先通过 DoH 解析，普通 DNS 仅在 DoH 失败时作为回退。"
        ),
        (
            "线路与合规",
            "building.2.crop.circle",
            "请遵守账号授权范围及所在地区适用法律。智能加速只优化线路边缘，不改变流量处理目的。"
        )
    ]

    var body: some View {
        ScrollView {
            VStack(spacing: 22) {
                Spacer(minLength: 36)
                Image(systemName: "lock.shield.fill")
                    .font(.system(size: 54, weight: .semibold))
                    .foregroundStyle(SewerPalette.blue)
                    .padding(20)
                    .background(SewerPalette.blue.opacity(0.1), in: Circle())
                Text("首次连接安全告知".appLocalized)
                    .font(.title2.weight(.bold))
                    .foregroundStyle(SewerPalette.ink)
                    .multilineTextAlignment(.center)
                Text("在首次建立受保护连接前，请确认您了解以下网络处理方式。".appLocalized)
                    .font(.body)
                    .foregroundStyle(SewerPalette.muted)
                    .multilineTextAlignment(.center)
                    .fixedSize(horizontal: false, vertical: true)

                VStack(spacing: 12) {
                    ForEach(Array(items.enumerated()), id: \.offset) { _, item in
                        HStack(alignment: .top, spacing: 12) {
                            Image(systemName: item.1)
                                .font(.body.weight(.semibold))
                                .foregroundStyle(SewerPalette.blue)
                                .frame(width: 24)
                            VStack(alignment: .leading, spacing: 4) {
                                Text(item.0.appLocalized)
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundStyle(SewerPalette.ink)
                                Text(item.2.appLocalized)
                                    .font(.footnote)
                                    .foregroundStyle(SewerPalette.muted)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                            Spacer(minLength: 0)
                        }
                        .padding(14)
                        .background(.white, in: RoundedRectangle(cornerRadius: 8))
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(SewerPalette.border, lineWidth: 1))
                    }
                }

                Button("我已了解，继续连接", action: onAccept)
                    .buttonStyle(FilledActionButtonStyle(tint: SewerPalette.blue))
                Button("暂不连接", action: onCancel)
                    .font(.footnote.weight(.medium))
                    .foregroundStyle(SewerPalette.muted)
                    .buttonStyle(.plain)
                Spacer(minLength: 24)
            }
            .frame(maxWidth: 560)
            .frame(maxWidth: .infinity)
            .padding(24)
        }
        .background(SewerPalette.canvas.ignoresSafeArea())
        .interactiveDismissDisabled()
    }
}

private struct PrivacyPolicyView: View {
    @Environment(\.dismiss) private var dismiss

    private var policyURL: URL {
        let path = AppLanguage.resourceIdentifier == "en" ? "/privacy/en" : "/privacy#zh"
        return URL(string: "https://net.sewer.top\(path)")!
    }

    private let policySections: [(heading: String, content: String)] = [
        (
            "1. 适用范围",
            "本政策适用于 SEWER iOS 客户端、api.sewer.com.cn、net.sewer.top、api.sewer.top 账户服务及与其直接相关的企业网络安全访问服务。本服务仅向经深圳钛氦科技有限公司授权的账户提供。"
        ),
        (
            "2. 我们处理的信息",
            "为提供您主动请求的服务，我们可能处理账户信息、订阅授权、所选线路和路由模式、连接与流量状态，以及建立、运行、保护和排查服务所必需的网络技术数据。登录会话、订阅缓存和账户流量摘要存储在 Apple Keychain；偏好设置存储在应用容器中。"
        ),
        (
            "3. 联网检查与内置规则",
            "点击连接后，客户端仅使用 Apple Network 框架判断系统网络路径状态，不会连接第三方网站进行连接前探测。建立线路前，SEWER 服务域名、AWS 边缘域名及位于 SEWER/AWS 域名下的线路域名优先使用阿里 DNS（223.5.5.5）、腾讯 DNS（1.12.12.12）的 DNS over HTTPS 解析；仅在 DoH 失败时回落到 1.2.4.8 与 223.5.5.5 普通 DNS。开启智能加速时，客户端会从 Amazon 公共 IP 范围接口读取 CloudFront 前缀并短期测试边缘延迟。隧道建立后，设备 IPv4/IPv6 DNS 均被强制使用 Cloudflare 的 1.1.1.1 并通过所选线路转发；UDP、WebRTC/STUN 与 IPv6 流量进入受保护通道，避免通过 Wi-Fi 或蜂窝网络直接泄露。解析和加速服务可能接收查询域名、线路出口 IP、时间和必要连接信息。连接后，如线路中断或系统网络发生切换，客户端启用 Apple 的按需连接机制，在您保持连接意图期间自动恢复连接；开启“保持连接”后，网络波动或系统恢复会自动重连，手动断开会暂停自动恢复，下次手动连接时恢复。GeoIP/GeoSite 路由分类数据随 App 版本内置，只能通过 App Store 版本更新替换。"
        ),
        (
            "4. 使用、共享与跨境传输",
            "信息仅用于验证账户、提供和维护您主动请求的企业网络安全访问、排查故障、防范滥用和履行法律义务。我们不出售、出租个人信息，不用于广告、广告定向或用户画像。您主动访问第三方网站或服务时，相关流量会到达您选择的目的地；服务可能涉及您所在地区以外的服务器或服务提供方。"
        ),
        (
            "5. 保存与安全",
            "客户端中的会话、订阅和偏好数据通常会在退出登录或卸载 App 后删除。服务端账户资料和服务配置在账户服务结束后 7 天内删除或匿名化；网络访问、安全和诊断日志最长保存 7 天，法律另有要求的除外。我们采用 HTTPS、Apple Keychain、访问控制和最小权限等措施保护信息。"
        ),
        (
            "6. 您的权利、未成年人和更新",
            "在适用法律允许的范围内，您可以请求访问、更正、删除、限制处理或导出相关个人信息，也可以撤回可撤回的同意。本服务不面向未满 16 周岁的未成年人。政策发生重大变更时，我们会通过客户端、网站或其他适当方式提示。"
        )
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    SewerBrandLockup(subtitle: "隐私政策", compact: true)
                    Text("生效日期：2026 年 11 月 16 日".appLocalized)
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(SewerPalette.muted)
                    Text("SEWER 由深圳钛氦科技有限公司运营。以下为客户端内置政策摘要；完整政策以线上版本为准。".appLocalized)
                        .foregroundStyle(SewerPalette.ink)
                    Link(destination: policyURL) {
                        Label("查看线上完整隐私政策".appLocalized, systemImage: "safari")
                            .font(.subheadline.weight(.semibold))
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.bordered)
                    .tint(SewerPalette.blue)

                    ForEach(Array(policySections.enumerated()), id: \.offset) { _, section in
                        VStack(alignment: .leading, spacing: 7) {
                            Text(section.heading.appLocalized)
                                .font(.headline)
                                .foregroundStyle(SewerPalette.ink)
                            Text(section.content.appLocalized)
                                .font(.subheadline)
                                .foregroundStyle(SewerPalette.muted)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }

                    Text("隐私咨询请联系 OTP@SEWER.TOP。".appLocalized)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .padding(24)
            }
            .navigationTitle("隐私政策")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
    }
}

private struct LoginView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    @State private var email = ""
    @State private var password = ""
    @State private var showsPrivacyPolicy = false
    @FocusState private var focusedField: LoginField?

    private enum LoginField {
        case email
        case password
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                HStack {
                    Spacer()
                    LanguagePickerMenu()
                }
                if verticalSizeClass == .compact {
                    HStack(spacing: 36) {
                        SewerBrandLockup()
                            .frame(maxWidth: .infinity)
                        loginForm
                            .frame(maxWidth: 420)
                    }
                    .frame(maxWidth: 900)
                } else {
                    VStack(spacing: 26) {
                        Spacer(minLength: 50)
                        SewerBrandLockup()
                            .frame(maxWidth: .infinity)
                            .sewerEntryMotion(delay: 0)
                        loginForm
                        Spacer(minLength: 20)
                    }
                    .frame(maxWidth: 560)
                }
            }
            .frame(maxWidth: .infinity)
            .padding(24)
        }
        .background(SewerPalette.canvas.ignoresSafeArea())
        .sheet(isPresented: $showsPrivacyPolicy) { PrivacyPolicyView() }
    }

    private var loginForm: some View {
        VStack(spacing: 16) {
            VStack(spacing: 12) {
                LoginFieldRow(label: "邮箱", systemImage: "envelope") {
                    TextField("", text: $email)
                        .accessibilityLabel("邮箱".appLocalized)
                        .textContentType(.username)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)
                        .autocorrectionDisabled()
                        .focused($focusedField, equals: .email)
                        .submitLabel(.next)
                        .onSubmit { focusedField = .password }
                }
                LoginFieldRow(label: "密码", systemImage: "lock") {
                    SecureField("", text: $password)
                        .accessibilityLabel("密码".appLocalized)
                        .textContentType(.password)
                        .focused($focusedField, equals: .password)
                        .submitLabel(.go)
                        .onSubmit { login() }
                }
            }
            .sewerEntryMotion(delay: 0.05)
            Button(action: login) {
                HStack(spacing: 8) {
                    if model.isBusy { ProgressView().tint(.white) }
                    Text((model.isBusy ? "正在登录" : "登录").appLocalized)
                }
            }
            .disabled(model.isBusy || email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || password.isEmpty)
            .buttonStyle(FilledActionButtonStyle(tint: SewerPalette.blue))
            .sewerEntryMotion(delay: 0.1)
            Button("查看隐私政策") { showsPrivacyPolicy = true }
                .font(.footnote)
                .foregroundStyle(SewerPalette.muted)
                .buttonStyle(.plain)
                .sewerEntryMotion(delay: 0.14)
        }
    }

    private func login() {
        focusedField = nil
        Task {
            await model.login(
                email: email.trimmingCharacters(in: .whitespacesAndNewlines),
                password: password
            )
        }
    }
}

private struct HomeView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.dynamicTypeSize) private var dynamicTypeSize
    @State private var showsRoutePicker = false
    @State private var showsAccountSheet = false
    @State private var showsNotices = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    header.sewerEntryMotion(delay: 0)
                    connectionPanel.sewerEntryMotion(delay: 0.04)
                    connectivityPanel.sewerEntryMotion(delay: 0.06)
                    routePanel.sewerEntryMotion(delay: 0.08)
                    accountPanel.sewerEntryMotion(delay: 0.12)
                }
                .frame(maxWidth: 760)
                .frame(maxWidth: .infinity)
                .padding(.horizontal, 20)
                .padding(.vertical, 16)
            }
            .background(SewerPalette.canvas.ignoresSafeArea())
            .navigationBarTitleDisplayMode(.inline)
            .task { await model.prepareHome() }
            .sheet(isPresented: $showsRoutePicker) { RoutePickerView() }
            .sheet(isPresented: $showsAccountSheet) { AccountView() }
            .sheet(isPresented: $showsNotices) { NoticesView() }
            .fullScreenCover(isPresented: Binding(
                get: { model.showsFirstConnectionNotice },
                set: { if !$0 { model.dismissFirstConnectionNotice() } }
            )) {
                FirstConnectionNoticeView(
                    onAccept: model.acceptFirstConnectionNotice,
                    onCancel: model.dismissFirstConnectionNotice
                )
            }
            .fullScreenCover(
                isPresented: Binding(
                    get: { model.pendingNotice != nil },
                    set: { _ in }
                )
            ) {
                if let notice = model.pendingNotice {
                    NoticeAcknowledgementView(notice: notice) {
                        model.acknowledgePendingNotice()
                    }
                }
            }
        }
    }

    @ViewBuilder
    private var header: some View {
        if dynamicTypeSize.isAccessibilitySize {
            VStack(alignment: .leading, spacing: 12) {
                SewerBrandLockup(title: "SEWER", subtitle: "安全连接", compact: true)
                headerActions
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
        } else {
            HStack(alignment: .center) {
                SewerBrandLockup(title: "SEWER", subtitle: "安全连接", compact: true)
                Spacer()
                headerActions
            }
        }
    }

    private var headerActions: some View {
        HStack(spacing: 8) {
            LanguagePickerMenu()
            Text(currentClientVersionLabel())
                .font(.caption.weight(.bold))
                .foregroundStyle(SewerPalette.blue)
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(SewerPalette.blue.opacity(0.09), in: Capsule())
                .fixedSize()
            Button {
                showsNotices = true
            } label: {
                ZStack(alignment: .topTrailing) {
                    Image(systemName: "bell")
                        .font(.subheadline.weight(.semibold))
                        .frame(width: 40, height: 40)
                    if model.noticeTotal > 0 {
                        Text(model.noticeTotal > 99 ? "99+" : "\(model.noticeTotal)")
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(.white)
                            .frame(minWidth: 16, minHeight: 16)
                            .background(SewerPalette.disconnect, in: Capsule())
                            .offset(x: 3, y: -3)
                    }
                }
                .foregroundStyle(SewerPalette.blue)
                .background(SewerPalette.blue.opacity(0.09), in: RoundedRectangle(cornerRadius: 8))
            }
            .accessibilityLabel(
                model.noticeTotal > 0
                    ? "查看公告，共 %d 条".appLocalized(arguments: model.noticeTotal)
                    : "查看公告".appLocalized
            )
            Button {
                Task { await model.refreshHomeData() }
            } label: {
                Group {
                    if model.isRefreshingHomeData {
                        ProgressView().controlSize(.small)
                    } else {
                        Image(systemName: "arrow.clockwise")
                            .font(.subheadline.weight(.semibold))
                    }
                }
                .frame(width: 40, height: 40)
                .foregroundStyle(SewerPalette.blue)
                .background(SewerPalette.blue.opacity(0.09), in: RoundedRectangle(cornerRadius: 8))
            }
            .disabled(model.isBusy)
            .accessibilityLabel(
                (model.isRefreshingHomeData ? "正在刷新账户与线路信息" : "刷新账户与线路信息").appLocalized
            )
        }
    }

    private var connectionPanel: some View {
        let isConnecting = model.connectionPhase.isInProgress || model.vpn.status == .connecting || model.vpn.status == .reasserting
        return VStack(alignment: .leading, spacing: 18) {
            if dynamicTypeSize.isAccessibilitySize {
                VStack(alignment: .leading, spacing: 10) {
                    connectionHeading
                    connectionBadges(isConnecting: isConnecting)
                }
            } else {
                HStack(alignment: .top) {
                    connectionHeading
                    Spacer()
                    connectionBadges(isConnecting: isConnecting)
                }
            }

            Divider().overlay(Color.white.opacity(0.12))

            VStack(alignment: .leading, spacing: 6) {
                Text("当前线路")
                    .font(.caption)
                    .foregroundStyle(SewerPalette.slateLight)
                Text(model.selectedNode?.name ?? "尚未选择线路".appLocalized)
                    .font(.body.weight(.medium))
                    .foregroundStyle(.white)
                    .lineLimit(1)
            }

            if dynamicTypeSize.isAccessibilitySize {
                VStack(spacing: 10) {
                    SewerConnectionMetric(title: "路由模式", value: model.routingMode.title)
                    SewerConnectionMetric(title: "网络保护", value: networkProtectionValue)
                }
            } else {
                HStack(spacing: 10) {
                    SewerConnectionMetric(title: "路由模式", value: model.routingMode.title)
                    SewerConnectionMetric(title: "网络保护", value: networkProtectionValue)
                }
            }

            if isConnecting {
                SewerConnectionProgress(detail: connectionProgressDetail, tint: connectionTint)
                    .transition(reduceMotion ? .identity : .opacity.combined(with: .move(edge: .top)))
            }

            Button {
                Task { await model.performConnectionAction() }
            } label: {
                HStack(spacing: 8) {
                    if isConnecting {
                        ProgressView()
                            .controlSize(.small)
                            .tint(.white)
                    }
                    Text(model.connectionActionTitle)
                }
            }
            .disabled(model.connectionActionDisabled)
            .buttonStyle(FilledActionButtonStyle(tint: model.vpn.isActive && !isConnecting ? SewerPalette.disconnect : SewerPalette.blue))

            protectionOptions
        }
        .padding(22)
        .background(SewerPalette.midnight, in: RoundedRectangle(cornerRadius: 18))
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .stroke(connectionTint.opacity(model.vpn.isActive ? 0.42 : 0), lineWidth: 1)
        )
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.24), value: model.vpn.status)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: model.connectionHealth)
    }

    private var protectionOptions: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Image(systemName: "bolt.horizontal.circle.fill")
                    .foregroundStyle(SewerPalette.blueLight)
                VStack(alignment: .leading, spacing: 2) {
                    Text("自动优化网络")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                    Text((model.accelerationStatus ?? "自动选择低延迟健康边缘").appLocalized)
                        .font(.caption)
                        .foregroundStyle(SewerPalette.slateLight)
                        .lineLimit(1)
                }
                Spacer(minLength: 8)
                Toggle("智能加速", isOn: Binding(
                    get: { model.accelerationEnabled },
                    set: model.setAccelerationEnabled
                ))
                .labelsHidden()
                .disabled(model.vpn.isActive || model.selectedNode.map {
                    !SewerEdgeOptimizer.shared.supports($0)
                } == true)
            }
            .padding(.vertical, 11)

            Divider().overlay(Color.white.opacity(0.10))

            HStack(spacing: 10) {
                Image(systemName: "arrow.triangle.2.circlepath.circle.fill")
                    .foregroundStyle(SewerPalette.blueLight)
                VStack(alignment: .leading, spacing: 2) {
                    Text("保持连接")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                    Text("网络波动或系统恢复后自动重连")
                        .font(.caption)
                        .foregroundStyle(SewerPalette.slateLight)
                }
                Spacer(minLength: 8)
                Toggle("保持连接", isOn: Binding(
                    get: { model.keepConnected },
                    set: { enabled in
                        Task { await model.setKeepConnected(enabled) }
                    }
                ))
                .labelsHidden()
                .tint(SewerPalette.connected)
            }
            .padding(.vertical, 11)
        }
        .padding(.horizontal, 14)
        .background(Color.white.opacity(0.045), in: RoundedRectangle(cornerRadius: 12))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.white.opacity(0.10), lineWidth: 1))
    }

    private var connectivityPanel: some View {
        VStack(spacing: 14) {
            HStack(spacing: 14) {
                Image(systemName: "globe.asia.australia.fill")
                    .font(.title2)
                    .foregroundStyle(SewerPalette.blue)
                    .frame(width: 42, height: 42)
                    .background(SewerPalette.blue.opacity(0.09), in: RoundedRectangle(cornerRadius: 12))
                VStack(alignment: .leading, spacing: 3) {
                    Text("网络连通性")
                        .font(.headline.weight(.semibold))
                        .foregroundStyle(SewerPalette.ink)
                    Text(connectivityDescription)
                        .font(.footnote)
                        .foregroundStyle(connectivityTint)
                        .lineLimit(2)
                }
                Spacer(minLength: 8)
                Button {
                    Task { await model.refreshConnectionHealth() }
                } label: {
                    HStack(spacing: 5) {
                        if model.connectionHealth.isChecking {
                            ProgressView().controlSize(.small)
                        } else {
                            Image(systemName: "arrow.clockwise")
                        }
                        Text("重新检测")
                    }
                    .font(.footnote.weight(.semibold))
                }
                .buttonStyle(.plain)
                .foregroundStyle(SewerPalette.blue)
                .disabled(model.vpn.status != .connected || model.connectionHealth.isChecking)
            }
        }
        .padding(16)
        .background(.white, in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(SewerPalette.border, lineWidth: 1))
    }

    private var connectionHeading: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text("连接状态")
                .font(.caption.weight(.semibold))
                .foregroundStyle(SewerPalette.blueLight)
            Text(connectionTitle)
                .font(.title3.weight(.bold))
                .foregroundStyle(.white)
                .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: connectionTitle)
        }
    }

    private func connectionBadges(isConnecting: Bool) -> some View {
        HStack(spacing: 8) {
            SewerConnectionBadge(
                text: connectionStatusText,
                tint: connectionTint,
                pulses: isConnecting
            )
            if model.vpn.status == .connected,
               let node = model.selectedNode,
               XrayConfigurationFactory.isMuxActive(for: node) {
                Label("超级通道已启用", systemImage: "bolt.shield.fill")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(SewerPalette.blueLight)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 5)
                    .background(SewerPalette.blue.opacity(0.18), in: Capsule())
                    .accessibilityLabel("当前线路已开启 Mux 超级通道")
            }
        }
    }

    private var routePanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .center, spacing: 10) {
                routeSectionTitle
                Spacer(minLength: 8)
                refreshLineButton
            }
            subscriptionStatusLabel
            if let error = model.subscriptionError, !error.isEmpty {
                if dynamicTypeSize.isAccessibilitySize {
                    VStack(alignment: .leading, spacing: 8) {
                        subscriptionErrorLabel(error)
                        subscriptionRetryButton
                    }
                } else {
                    HStack(alignment: .top, spacing: 8) {
                        subscriptionErrorLabel(error)
                        Spacer(minLength: 4)
                        subscriptionRetryButton
                    }
                }
            }
            Button {
                showsRoutePicker = true
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: "point.3.connected.trianglepath.dotted")
                        .foregroundStyle(SewerPalette.blue)
                        .frame(width: 24)
                    VStack(alignment: .leading, spacing: 0) {
                        Text(model.selectedNode?.name ?? "选择线路".appLocalized)
                            .foregroundStyle(SewerPalette.ink)
                            .lineLimit(1)
                    }
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(SewerPalette.slate)
                }
                .padding(14)
                .background(SewerPalette.routeControlBackground, in: RoundedRectangle(cornerRadius: 10))
            }
            .buttonStyle(.plain)
            .disabled(model.nodes.isEmpty || !model.canChangeSelectedNode)

            if let validation = model.currentLinePlanValidation {
                planValidationLabel(validation)
            }

            if model.vpn.isActive {
                Text("断开连接后可切换线路。")
                    .font(.footnote)
                    .foregroundStyle(SewerPalette.muted)
            } else if let node = model.selectedNode, !SewerCoreRouter.supports(node) {
                Text("当前 iOS 版本支持 VLESS、Trojan、SOCKS5 与 Shadowsocks 线路。")
                    .font(.footnote)
                    .foregroundStyle(SewerPalette.muted)
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("路由模式")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(SewerPalette.ink)
                SewerRoutingModeControl(
                    selection: model.routingMode,
                    isEnabled: model.canChangeRoutingMode,
                    onSelect: model.selectRoutingMode
                )
                Text(model.routingMode.detail)
                    .font(.footnote)
                    .foregroundStyle(SewerPalette.muted)
                    .fixedSize(horizontal: false, vertical: true)

            }

            if model.vpn.isActive {
                Text("断开连接后可切换路由模式。")
                    .font(.footnote)
                    .foregroundStyle(SewerPalette.muted)
            }
        }
        .padding(18)
        .background(.white, in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(SewerPalette.border, lineWidth: 1))
    }

    private var routeSectionTitle: some View {
            Text("线路与路由")
            .font(.headline.weight(.semibold))
            .foregroundStyle(SewerPalette.ink)
    }

    private var refreshLineButton: some View {
        Button {
            Task { await model.refreshLinesAndPlanStatus() }
        } label: {
            HStack(spacing: 5) {
                if model.isRefreshingSubscription {
                    ProgressView().controlSize(.small)
                } else {
                    Image(systemName: "arrow.clockwise")
                }
                Text(model.isRefreshingSubscription ? "刷新中" : "刷新线路")
            }
            .font(.footnote.weight(.semibold))
        }
        .buttonStyle(.plain)
        .foregroundStyle(SewerPalette.blue)
        .disabled(model.isRefreshingSubscription || model.isBusy || model.vpn.isActive)
    }

    private func planValidationLabel(_ validation: SewerLinePlanValidation) -> some View {
        let isError = !validation.allowed
        let name = validation.planName ?? "当前套餐"
        let expiry = validation.access?.expiredAt.flatMap { timestamp -> String? in
            guard timestamp > 0 else { return nil }
            return AppLanguage.formattedDate(
                Date(timeIntervalSince1970: TimeInterval(timestamp)),
                dateStyle: .abbreviated,
                timeStyle: .shortened
            )
        } ?? "--"
        let text: String
        switch validation.reason {
        case .expired:
            text = "套餐「\(name)」已于 \(expiry) 到期"
        case .trafficExhausted:
            text = "套餐「\(name)」流量已用尽"
        case .unresolved:
            text = "无法确认当前线路所属套餐"
        case .unavailable:
            text = "套餐状态暂时不可用"
        case .none:
            text = "套餐「\(name)」· 有效期至 \(expiry)"
        }
        return Label(text, systemImage: isError ? "exclamationmark.triangle.fill" : "checkmark.seal.fill")
            .font(.footnote.weight(.medium))
            .foregroundStyle(isError ? SewerPalette.disconnect : SewerPalette.connected)
            .fixedSize(horizontal: false, vertical: true)
    }

    private var subscriptionStatusLabel: some View {
        Text(model.subscriptionStatusDescription)
            .font(.caption)
            .foregroundStyle(SewerPalette.muted)
    }

    private func subscriptionErrorLabel(_ error: String) -> some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "exclamationmark.triangle.fill")
                .foregroundStyle(SewerPalette.disconnect)
            Text(error)
                .font(.footnote)
                .foregroundStyle(SewerPalette.disconnect)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var subscriptionRetryButton: some View {
        Button("重试") {
            Task { await model.refreshSubscription(force: true) }
        }
        .font(.footnote.weight(.semibold))
        .buttonStyle(.borderless)
        .disabled(model.isRefreshingSubscription)
    }

    private var accountPanel: some View {
        HStack(spacing: 14) {
            Image(systemName: "person.crop.circle.fill")
                .font(.title2)
                .foregroundStyle(SewerPalette.blue)
                .frame(width: 42, height: 42)
                .background(SewerPalette.blue.opacity(0.09), in: RoundedRectangle(cornerRadius: 12))
            VStack(alignment: .leading, spacing: 4) {
                Text("我的账户")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(SewerPalette.muted)
                Text(accountSummaryLine)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(SewerPalette.ink)
                    .lineLimit(1)
            }
            Spacer(minLength: 8)
            Button("账户详情") { showsAccountSheet = true }
                .font(.footnote.weight(.semibold))
                .buttonStyle(.borderless)
                .foregroundStyle(SewerPalette.blue)
        }
        .padding(16)
        .background(.white, in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(SewerPalette.border, lineWidth: 1))
    }

    private var accountSummaryLine: String {
        let type = model.accountTypeDescription.isEmpty ? "个人套餐" : model.accountTypeDescription
        let traffic = model.accountSummary?.trafficDescription ?? "--"
        return "\(type) · 剩余流量 \(traffic)"
    }

    private var accountIdentity: some View {
        HStack(spacing: 12) {
            Image(systemName: "person.crop.circle")
                .font(.title2)
                .foregroundStyle(SewerPalette.blue)
            VStack(alignment: .leading, spacing: 3) {
                Text(model.session?.email ?? "")
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(SewerPalette.ink)
                    .lineLimit(1)
                if let companyName = model.accountSummary?.normalizedCompanyName {
                    Text(companyName)
                        .font(.caption)
                        .foregroundStyle(SewerPalette.muted)
                        .lineLimit(1)
                } else if !model.accountTypeDescription.isEmpty {
                    Text(model.accountTypeDescription)
                        .font(.caption)
                        .foregroundStyle(SewerPalette.muted)
                        .lineLimit(1)
                }
            }
        }
    }

    private var accountTraffic: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text("剩余流量")
                .font(.caption2)
                .foregroundStyle(SewerPalette.muted)
            Text(model.accountSummary?.trafficDescription ?? "--")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(SewerPalette.ink)
        }
    }

    private var accountManageButton: some View {
        Button("管理") { showsAccountSheet = true }
            .buttonStyle(.bordered)
            .controlSize(.small)
            .tint(SewerPalette.blue)
    }

    private var connectionTint: Color {
        if model.connectionPhase.isInProgress { return SewerPalette.blueLight }
        switch model.vpn.status {
        case .connected: return SewerPalette.connected
        case .connecting, .reasserting: return SewerPalette.blueLight
        case .disconnecting: return SewerPalette.warning
        default: return SewerPalette.slateLight
        }
    }

    private var connectivityTint: Color {
        if model.connectionPhase.isInProgress || model.connectionHealth.isChecking {
            return SewerPalette.blue
        }
        switch model.connectionHealth {
        case .available:
            return SewerPalette.connected
        case .unavailable:
            return SewerPalette.disconnect
        case .notChecked, .checking:
            return SewerPalette.muted
        }
    }

    private var connectivityDescription: String {
        guard model.vpn.status == .connected else {
            return "连接后可检测当前线路的端到端连通性"
        }
        if model.connectionPhase.isInProgress {
            return "正在确认保护通道"
        }
        return model.connectionHealth.description
    }

    private var connectionStatusText: String {
        if model.connectionPhase.isInProgress { return "连接中".appLocalized }
        switch model.vpn.status {
        case .connected: return "已保护".appLocalized
        case .connecting, .reasserting: return "连接中".appLocalized
        case .disconnecting: return "断开中".appLocalized
        default: return "未连接".appLocalized
        }
    }

    private var connectionTitle: String {
        if model.vpn.isStoppingInBackground { return "正在完成断开".appLocalized }
        if model.connectionPhase.isInProgress { return "连接中".appLocalized }
        return model.vpn.statusDescription
    }

    private var networkProtectionValue: String {
        if model.connectionPhase.isInProgress { return "连接中".appLocalized }
        guard model.vpn.status == .connected else { return "未启用".appLocalized }
        return "已启用".appLocalized
    }

    private var connectionProgressDetail: String {
        if model.connectionPhase.isInProgress {
            return model.connectionPhase.detail
        }
        return "正在验证网络".appLocalized
    }

}

private struct RoutePickerView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: AppModel

    var body: some View {
        NavigationStack {
            List {
                if model.nodes.isEmpty {
                    VStack(spacing: 10) {
                        Image(systemName: "point.3.connected.trianglepath.dotted")
                            .font(.title2)
                            .foregroundStyle(.secondary)
                        Text("尚未加载线路")
                            .font(.headline)
                        Text("刷新订阅后可选择线路。")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 36)
                    .listRowBackground(Color.clear)
                } else {
                    ForEach(model.nodes) { node in
                        let planValidation = model.linePlanValidation(for: node)
                        Button {
                            model.selectNode(node)
                            dismiss()
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: XrayConfigurationFactory.supports(node) ? "checkmark.shield" : "exclamationmark.triangle")
                                    .foregroundStyle(XrayConfigurationFactory.supports(node) ? .blue : .secondary)
                                    .frame(width: 24)
                                VStack(alignment: .leading, spacing: 0) {
                                    Text(node.name)
                                        .foregroundStyle(.primary)
                                        .lineLimit(1)
                                    if let planValidation {
                                        Text(routePlanStatus(planValidation))
                                            .font(.caption)
                                            .foregroundStyle(planValidation.allowed ? SewerPalette.connected : SewerPalette.disconnect)
                                            .lineLimit(1)
                                    }
                                }
                                Spacer()
                                if model.selectedNodeID == node.id {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundStyle(.blue)
                                }
                            }
                        }
                        .buttonStyle(.plain)
                        .disabled(!model.canChangeSelectedNode)
                    }
                }
            }
            .navigationTitle("选择线路")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
    }

    private func routePlanStatus(_ validation: SewerLinePlanValidation) -> String {
        let name = validation.planName ?? "套餐"
        switch validation.reason {
        case .expired: return "\(name) · 已过期"
        case .trafficExhausted: return "\(name) · 流量已用尽"
        case .unresolved: return "无法确认所属套餐"
        case .unavailable: return "套餐状态不可用"
        case .none: return "\(name) · 可用"
        }
    }
}

private struct NoticesView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: AppModel

    var body: some View {
        NavigationStack {
            Group {
                if model.isRefreshingNotices, model.notices.isEmpty {
                    ProgressView("正在获取公告")
                } else if model.notices.isEmpty {
                    VStack(spacing: 10) {
                        Image(systemName: "bell.slash")
                            .font(.title2)
                            .foregroundStyle(.secondary)
                        Text("暂无公告")
                            .font(.headline)
                        Text(model.noticeError ?? "当前没有需要向您展示的公告。".appLocalized)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                        Button("重新获取") {
                            Task { await model.refreshNotices(force: true) }
                        }
                        .disabled(model.isRefreshingNotices)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(36)
                } else {
                    List {
                        ForEach(model.notices) { notice in
                            NavigationLink {
                                NoticeDetailView(notice: notice)
                            } label: {
                                NoticeRow(notice: notice)
                            }
                        }

                        if model.hasMoreNotices {
                            Button {
                                Task { await model.loadMoreNotices() }
                            } label: {
                                HStack {
                                    Spacer()
                                    if model.isRefreshingNotices {
                                        ProgressView()
                                            .controlSize(.small)
                                    } else {
                                        Text("加载更多")
                                    }
                                    Spacer()
                                }
                            }
                            .disabled(model.isRefreshingNotices)
                        }
                    }
                    .listStyle(.insetGrouped)
                    .refreshable { await model.refreshNotices(force: true) }
                }
            }
            .navigationTitle("公告")
            .navigationBarTitleDisplayMode(.inline)
            .task {
                if model.notices.isEmpty {
                    await model.refreshNotices(force: true)
                }
            }
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
    }
}

private struct NoticeAcknowledgementView: View {
    let notice: SewerNotice
    let acknowledge: () -> Void

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Label("服务公告", systemImage: "bell.badge.fill")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(SewerPalette.blue)
                    Text(notice.title)
                        .font(.title2.weight(.bold))
                        .foregroundStyle(.primary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    HStack(spacing: 8) {
                        Text(notice.displayDate)
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                        NoticeTagList(tags: notice.tags)
                    }
                    if let imageURL = notice.safeImageURL {
                        SewerRemoteImage(url: imageURL)
                        .frame(maxWidth: .infinity)
                        .frame(height: 190)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    }
                    Text(notice.content)
                        .font(.body)
                        .foregroundStyle(.primary)
                        .fixedSize(horizontal: false, vertical: true)
                        .textSelection(.enabled)
                }
                .padding(24)
            }
            .background(SewerPalette.canvas.ignoresSafeArea())
            .safeAreaInset(edge: .bottom) {
                Button("我已知悉", action: acknowledge)
                    .buttonStyle(FilledActionButtonStyle(tint: SewerPalette.blue))
                    .padding(.horizontal, 24)
                    .padding(.vertical, 14)
                    .background(.ultraThinMaterial)
            }
        }
        .interactiveDismissDisabled()
    }
}

private struct NoticeRow: View {
    let notice: SewerNotice

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(notice.title)
                .font(.body.weight(.semibold))
                .foregroundStyle(.primary)
                .lineLimit(2)
            Text(notice.content)
                .font(.footnote)
                .foregroundStyle(.secondary)
                .lineLimit(2)
            HStack(spacing: 8) {
                Text(notice.displayDate)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                NoticeTagList(tags: notice.tags)
            }
        }
        .padding(.vertical, 3)
    }
}

private struct NoticeDetailView: View {
    let notice: SewerNotice

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text(notice.title)
                    .font(.title2.weight(.bold))
                    .foregroundStyle(.primary)
                    .frame(maxWidth: .infinity, alignment: .leading)
                HStack(spacing: 8) {
                    Text(notice.displayDate)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    NoticeTagList(tags: notice.tags)
                }
                if let imageURL = notice.safeImageURL {
                    SewerRemoteImage(url: imageURL)
                    .frame(maxWidth: .infinity)
                    .frame(height: 190)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
                }
                Text(notice.content)
                    .font(.body)
                    .foregroundStyle(.primary)
                    .fixedSize(horizontal: false, vertical: true)
                    .textSelection(.enabled)
            }
            .padding(20)
        }
        .background(SewerPalette.canvas.ignoresSafeArea())
        .navigationTitle("公告详情")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct SewerRemoteImage: View {
    let url: URL
    @State private var image: UIImage?
    @State private var failed = false

    var body: some View {
        Group {
            if let image {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
            } else if failed {
                Color.clear
            } else {
                ProgressView()
            }
        }
        .task(id: url) {
            guard !failed,
                  url.scheme?.lowercased() == "https",
                  let host = url.host,
                  let components = URLComponents(url: url, resolvingAgainstBaseURL: false) else {
                failed = true
                return
            }
            do {
                let basePath = components.percentEncodedPath.isEmpty ? "/" : components.percentEncodedPath
                let path = basePath + (components.percentEncodedQuery.map { "?\($0)" } ?? "")
                let response = try await SewerHTTPTransport.perform(
                    host: host,
                    method: "GET",
                    path: path,
                    headers: ["Accept": "image/*", "User-Agent": SewerClientIdentity.userAgent],
                    timeout: 12,
                    maxResponseBytes: 5 * 1_048_576
                )
                guard (200...299).contains(response.status), !Task.isCancelled else {
                    failed = true
                    return
                }
                image = UIImage(data: response.body)
                failed = image == nil
            } catch {
                failed = true
            }
        }
    }
}

private struct NoticeTagList: View {
    let tags: [String]

    var body: some View {
        HStack(spacing: 5) {
            ForEach(Array(tags.prefix(3).enumerated()), id: \.offset) { _, tag in
                Text(tag)
                    .font(.caption2.weight(.medium))
                    .foregroundStyle(SewerPalette.blue)
                    .lineLimit(1)
            }
        }
    }
}

private struct AccountView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: AppModel
    @AppStorage(AppLanguage.preferenceKey) private var appLanguage = AppLanguage.system.rawValue

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 14) {
                    accountHero
                    trafficCard
                    profileCard
                    settingsCard

                    Button {
                        Task { await model.refreshHomeData() }
                    } label: {
                        HStack(spacing: 8) {
                            if model.isRefreshingHomeData {
                                ProgressView().tint(.white)
                            } else {
                                Image(systemName: "arrow.clockwise")
                            }
                            Text(model.isRefreshingHomeData ? "同步中" : "同步订阅")
                                .font(.headline.weight(.semibold))
                        }
                    }
                    .buttonStyle(FilledActionButtonStyle(tint: SewerPalette.blue))
                    .disabled(model.isBusy)

                    Text("同步会更新线路、流量、到期状态与公告。")
                        .font(.footnote)
                        .foregroundStyle(SewerPalette.muted)

                    Button("退出登录", role: .destructive) {
                        model.logout()
                        dismiss()
                    }
                    .font(.body.weight(.semibold))
                    .foregroundStyle(SewerPalette.disconnect)
                    .padding(.vertical, 8)
                }
                .padding(20)
            }
            .background(SewerPalette.canvas.ignoresSafeArea())
            .navigationTitle("账户")
            .navigationBarTitleDisplayMode(.inline)
            .onChange(of: appLanguage) { AppLanguage.persist($0) }
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("完成") { dismiss() }
                }
            }
        }
    }

    private var accountHero: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 12) {
                Image(systemName: "person.fill")
                    .font(.title3)
                    .foregroundStyle(SewerPalette.blueLight)
                    .frame(width: 46, height: 46)
                    .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 13))
                VStack(alignment: .leading, spacing: 3) {
                    Text("我的账户")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(SewerPalette.blueLight)
                    Text(model.session?.email ?? "")
                        .font(.headline.weight(.semibold))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                }
                Spacer(minLength: 8)
                Text(currentClientVersionLabel())
                    .font(.caption.weight(.bold))
                    .foregroundStyle(SewerPalette.blueLight)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 5)
                    .background(Color.white.opacity(0.08), in: Capsule())
            }
            HStack {
                Text("套餐类型")
                    .font(.footnote)
                    .foregroundStyle(SewerPalette.slateLight)
                Spacer()
                Text(model.accountTypeDescription.isEmpty ? "个人套餐" : model.accountTypeDescription)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
            }
        }
        .padding(20)
        .background(SewerPalette.midnight, in: RoundedRectangle(cornerRadius: 18))
    }

    private var trafficCard: some View {
        VStack(alignment: .leading, spacing: 16) {
            Label("订阅用量", systemImage: "bolt.fill")
                .font(.headline.weight(.semibold))
                .foregroundStyle(SewerPalette.ink)
            HStack(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("剩余流量")
                        .font(.caption)
                        .foregroundStyle(SewerPalette.muted)
                    Text(model.accountSummary?.trafficDescription ?? "--")
                        .font(.title2.weight(.bold))
                        .foregroundStyle(SewerPalette.ink)
                }
                Spacer()
                Text("已用 \(model.accountSummary?.usedTrafficDescription ?? "--")")
                    .font(.footnote.weight(.medium))
                    .foregroundStyle(SewerPalette.muted)
            }
            ProgressView(value: trafficFraction)
                .tint(SewerPalette.blue)
            Divider()
            accountDetailRow("套餐总量", model.accountSummary?.totalTrafficDescription ?? "--")
            accountDetailRow("到期时间", accountDate(model.accountSummary?.expiredAt))
            accountDetailRow("下次重置", accountDate(model.accountSummary?.nextResetAt))
        }
        .padding(18)
        .background(.white, in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(SewerPalette.border, lineWidth: 1))
    }

    private var profileCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label("账户资料", systemImage: "building.2.fill")
                .font(.headline.weight(.semibold))
                .foregroundStyle(SewerPalette.ink)
            accountDetailRow("公司", model.accountSummary?.normalizedCompanyName ?? "--")
            accountDetailRow("账号类型", model.accountTypeDescription.isEmpty ? "个人套餐" : model.accountTypeDescription)
        }
        .padding(18)
        .background(.white, in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(SewerPalette.border, lineWidth: 1))
    }

    private var settingsCard: some View {
        VStack(spacing: 0) {
            HStack {
                Label("显示语言", systemImage: "globe")
                    .foregroundStyle(SewerPalette.ink)
                Spacer()
                Picker("显示语言", selection: $appLanguage) {
                    Text("跟随系统").tag(AppLanguage.system.rawValue)
                    Text("简体中文").tag(AppLanguage.simplifiedChinese.rawValue)
                    Text("English").tag(AppLanguage.english.rawValue)
                }
                .labelsHidden()
            }
            .padding(.vertical, 12)
            Divider()
            accountNavigationRow("连接诊断", systemImage: "stethoscope") {
                ConnectionDiagnosticsView()
            }
            Divider()
            accountNavigationRow("规则与许可", systemImage: "doc.text") {
                OpenSourceLicensesView()
            }
            Divider()
            HStack {
                Label("客户端更新", systemImage: "arrow.down.app")
                Spacer()
                Text("App Store")
                    .font(.footnote)
                    .foregroundStyle(SewerPalette.muted)
            }
            .foregroundStyle(SewerPalette.ink)
            .padding(.vertical, 12)
        }
        .padding(.horizontal, 16)
        .background(.white, in: RoundedRectangle(cornerRadius: 14))
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(SewerPalette.border, lineWidth: 1))
    }

    private func accountDetailRow(_ label: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(label)
                .font(.footnote)
                .foregroundStyle(SewerPalette.muted)
            Spacer()
            Text(value)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(SewerPalette.ink)
                .multilineTextAlignment(.trailing)
        }
    }

    private func accountNavigationRow<Destination: View>(
        _ title: String,
        systemImage: String,
        @ViewBuilder destination: () -> Destination
    ) -> some View {
        NavigationLink(destination: destination()) {
            HStack {
                Label(title, systemImage: systemImage)
                    .foregroundStyle(SewerPalette.ink)
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(SewerPalette.slateLight)
            }
            .padding(.vertical, 12)
        }
    }

    private var trafficFraction: Double {
        guard let summary = model.accountSummary,
              summary.transferEnable > 0 else { return 0 }
        return min(max(Double(summary.usedBytes) / Double(summary.transferEnable), 0), 1)
    }

    private func accountDate(_ timestamp: Int64?) -> String {
        guard let timestamp, timestamp > 0 else { return "--" }
        let seconds = timestamp > 10_000_000_000 ? Double(timestamp) / 1_000 : Double(timestamp)
        return AppLanguage.formattedDate(
            Date(timeIntervalSince1970: seconds),
            dateStyle: .abbreviated,
            timeStyle: .shortened
        )
    }
}

private struct OpenSourceLicensesView: View {
    var body: some View {
        List {
            Section("Xray Core") {
                Text("本客户端在本地 Packet Tunnel 扩展中使用 Xray Core（2026-11-14 源码版本），用于处理您主动发起的网络连接。核心不会在运行时下载、替换或执行外部代码。")
                    .fixedSize(horizontal: false, vertical: true)
                LabeledContent("许可", value: "Mozilla Public License 2.0")
                LabeledContent("源码版本", value: "5d17b872edde3024a5b906d9cd6c7a3ad4973d81")
            }
            Section("sing-box") {
                Text("本客户端同时使用 sing-box libbox（2026-02-28 源码版本）处理 SOCKS5 与 Shadowsocks 线路，并内置支持 obfs-local 与 v2ray-plugin。sing-box 以 GPLv3 授权，完整客户端源码需在分发时一并提供。")
                    .fixedSize(horizontal: false, vertical: true)
                LabeledContent("许可", value: "GNU General Public License v3.0")
                LabeledContent("源码版本", value: "73603b201141ee9bab41af76995808ccfc45209f")
            }
            Section {
                Link("查看 MPL-2.0 全文", destination: URL(string: "https://www.mozilla.org/MPL/2.0/")!)
                Link("查看 Xray Core 对应源码", destination: URL(string: "https://github.com/XTLS/Xray-core/tree/5d17b872edde3024a5b906d9cd6c7a3ad4973d81")!)
                Link("查看 GPLv3 全文", destination: URL(string: "https://www.gnu.org/licenses/gpl-3.0.html")!)
                Link("查看 sing-box 对应源码", destination: URL(string: "https://github.com/KaringX/sing-box/tree/73603b201141ee9bab41af76995808ccfc45209f")!)
                Link("查看 SEWER 完整对应源码", destination: URL(string: "https://github.com/Alan0429/SEWER-iOS/tree/v1.1.0")!)
                NavigationLink("查看随附 GPLv3 许可证文本") {
                    BundledTextResourceView(resourceName: "LICENSE", title: "GNU GPLv3")
                }
                NavigationLink("查看 sing-box 上游许可声明") {
                    BundledTextResourceView(resourceName: "LICENSE.sing-box", title: "sing-box license")
                }
            }
        }
        .navigationTitle("开源许可")
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct BundledTextResourceView: View {
    let resourceName: String
    let title: String

    private var resourceText: String {
        guard let url = Bundle.main.url(forResource: resourceName, withExtension: nil),
              let text = try? String(contentsOf: url, encoding: .utf8) else {
            return "The requested license text is unavailable in this build."
        }
        return text
    }

    var body: some View {
        ScrollView {
            Text(resourceText)
                .font(.caption.monospaced())
                .foregroundStyle(SewerPalette.ink)
                .textSelection(.enabled)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
        }
        .navigationTitle(title)
        .navigationBarTitleDisplayMode(.inline)
    }
}

private struct LanguagePickerMenu: View {
    @AppStorage(AppLanguage.preferenceKey) private var appLanguage = AppLanguage.system.rawValue

    var body: some View {
        Menu {
            Picker("显示语言", selection: $appLanguage) {
                Text("跟随系统").tag(AppLanguage.system.rawValue)
                Text("简体中文").tag(AppLanguage.simplifiedChinese.rawValue)
                Text("English").tag(AppLanguage.english.rawValue)
            }
        } label: {
            Image(systemName: "globe")
                .font(.subheadline.weight(.semibold))
                .frame(width: 40, height: 40)
                .foregroundStyle(SewerPalette.blue)
                .background(SewerPalette.blue.opacity(0.09), in: RoundedRectangle(cornerRadius: 8))
        }
        .accessibilityLabel("显示语言")
        .onChange(of: appLanguage) { AppLanguage.persist($0) }
    }
}

private struct ConnectionDiagnosticsView: View {
    @EnvironmentObject private var model: AppModel
    @State private var copied = false

    var body: some View {
        List {
            if model.tunnelDiagnostics.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "doc.text.magnifyingglass")
                        .font(.title2)
                        .foregroundStyle(.secondary)
                    Text("暂无连接日志")
                        .font(.headline)
                    Text("建立或断开连接后，这里会显示诊断事件。")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 36)
                .listRowBackground(Color.clear)
            } else {
                ForEach(model.tunnelDiagnostics) { event in
                    VStack(alignment: .leading, spacing: 5) {
                        HStack {
                            Text(event.source)
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(event.source == "Tunnel" ? SewerPalette.blue : SewerPalette.slate)
                            Spacer()
                            Text(AppLanguage.formattedDate(
                                event.timestamp,
                                dateStyle: .omitted,
                                timeStyle: .standard
                            ))
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                        Text(event.message)
                            .font(.footnote)
                            .foregroundStyle(.primary)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(.vertical, 3)
                }
            }
        }
        .navigationTitle("连接诊断")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear { model.refreshTunnelDiagnostics() }
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button {
                    model.refreshTunnelDiagnostics()
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
                .accessibilityLabel("刷新诊断日志")

                Button {
                    UIPasteboard.general.string = model.tunnelDiagnosticsText
                    copied = true
                } label: {
                    Image(systemName: "doc.on.doc")
                }
                .disabled(model.tunnelDiagnostics.isEmpty)
                .accessibilityLabel("复制诊断日志")

                Button(role: .destructive) {
                    model.clearTunnelDiagnostics()
                } label: {
                    Image(systemName: "trash")
                }
                .disabled(model.tunnelDiagnostics.isEmpty)
                .accessibilityLabel("清空诊断日志")
            }
        }
        .alert("诊断日志已复制", isPresented: $copied) {
            Button("确定", role: .cancel) {}
        }
    }
}

private struct LoginFieldRow<Content: View>: View {
    let label: String
    let systemImage: String
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            Label(label.appLocalized, systemImage: systemImage)
                .font(.subheadline)
                .foregroundStyle(SewerPalette.slate)
            content
                .padding(.horizontal, 12)
                .frame(minHeight: 48)
                .foregroundStyle(SewerPalette.ink)
                .tint(SewerPalette.blue)
                .background(.white, in: RoundedRectangle(cornerRadius: 8))
                .overlay(RoundedRectangle(cornerRadius: 8).stroke(SewerPalette.border, lineWidth: 1))
        }
    }
}

private struct SewerRoutingModeControl: View {
    let selection: SewerRoutingMode
    let isEnabled: Bool
    let onSelect: (SewerRoutingMode) -> Void

    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        HStack(spacing: 3) {
            option(.splitTunnel, systemImage: "arrow.triangle.branch")
            option(.fullTunnel, systemImage: "shield.fill")
        }
        .padding(3)
        .background(SewerPalette.routeControlBackground, in: RoundedRectangle(cornerRadius: 8))
        .overlay(RoundedRectangle(cornerRadius: 8).stroke(SewerPalette.border, lineWidth: 1))
        .accessibilityElement(children: .contain)
        .accessibilityLabel("路由模式".appLocalized)
    }

    private func option(_ mode: SewerRoutingMode, systemImage: String) -> some View {
        let isSelected = selection == mode
        return Button {
            onSelect(mode)
        } label: {
            HStack(spacing: 6) {
                Image(systemName: systemImage)
                    .font(.caption.weight(.semibold))
                Text(mode.title)
                    .font(.subheadline.weight(.semibold))
                    .lineLimit(1)
                    .minimumScaleFactor(0.82)
            }
            .foregroundStyle(isSelected ? .white : SewerPalette.slate)
            .frame(maxWidth: .infinity)
            .frame(minHeight: 40)
            .padding(.vertical, 5)
            .background(
                isSelected ? SewerPalette.blue : Color.clear,
                in: RoundedRectangle(cornerRadius: 6)
            )
            .contentShape(RoundedRectangle(cornerRadius: 6))
        }
        .buttonStyle(RouteModeButtonStyle())
        .disabled(!isEnabled)
        .opacity(isEnabled ? 1 : 0.58)
        .accessibilityLabel(mode.title.appLocalized)
        .accessibilityValue((isSelected ? "已选择" : "未选择").appLocalized)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.18), value: selection)
    }
}

private struct RouteModeButtonStyle: ButtonStyle {
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .opacity(configuration.isPressed ? 0.82 : 1)
            .scaleEffect(configuration.isPressed && !reduceMotion ? 0.985 : 1)
            .animation(reduceMotion ? nil : .easeOut(duration: 0.12), value: configuration.isPressed)
    }
}

private struct SewerBrandLockup: View {
    var title = "SEWER"
    var subtitle: String? = nil
    var compact = false

    var body: some View {
        HStack(spacing: compact ? 9 : 12) {
            SewerBrandMark(size: compact ? 36 : 54)
            VStack(alignment: .leading, spacing: 2) {
                Text(title.appLocalized)
                    .font(compact ? .headline.weight(.bold) : .title2.weight(.bold))
                    .foregroundStyle(SewerPalette.ink)
                if let subtitle {
                    Text(subtitle.appLocalized)
                        .font(compact ? .caption : .subheadline)
                        .foregroundStyle(SewerPalette.muted)
                }
            }
        }
    }
}

private struct SewerBrandMark: View {
    let size: CGFloat

    var body: some View {
        Image("SewerLogo")
            .resizable()
            .scaledToFit()
            .frame(width: size, height: size)
            .accessibilityHidden(true)
    }
}

private struct SewerConnectionBadge: View {
    let text: String
    let tint: Color
    let pulses: Bool
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var isPulsing = false

    var body: some View {
        HStack(spacing: 6) {
            Circle()
                .fill(tint)
                .frame(width: 7, height: 7)
                .scaleEffect(isPulsing ? 1.35 : 1)
                .opacity(isPulsing ? 0.65 : 1)
            Text(text.appLocalized)
                .font(.caption.weight(.semibold))
        }
        .foregroundStyle(tint)
        .padding(.horizontal, 9)
        .padding(.vertical, 6)
        .background(Color.white.opacity(0.08), in: Capsule())
        .overlay(Capsule().stroke(Color.white.opacity(0.12), lineWidth: 1))
        .onAppear { updatePulse() }
        .onChange(of: pulses) { _ in updatePulse() }
        .onChange(of: reduceMotion) { _ in updatePulse() }
    }

    private func updatePulse() {
        guard pulses, !reduceMotion else {
            withAnimation(.easeOut(duration: 0.15)) { isPulsing = false }
            return
        }
        withAnimation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true)) {
            isPulsing = true
        }
    }
}

private struct SewerConnectionMetric: View {
    let title: String
    let value: String

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(title.appLocalized)
                .font(.caption2)
                .foregroundStyle(SewerPalette.slateLight)
            Text(value.appLocalized)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

private struct SewerConnectionProgress: View {
    let detail: String
    let tint: Color
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var isAnimating = false

    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "shield.lefthalf.filled")
                .font(.body.weight(.semibold))
                .foregroundStyle(tint)
                .scaleEffect(isAnimating ? 1.08 : 0.94)
                .opacity(isAnimating ? 1 : 0.72)
            Text(detail.appLocalized)
                .font(.footnote.weight(.medium))
                .foregroundStyle(SewerPalette.slateLight)
            Spacer()
            ProgressView()
                .controlSize(.small)
                .tint(tint)
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .frame(minHeight: 42)
        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 8))
        .overlay(RoundedRectangle(cornerRadius: 8).stroke(Color.white.opacity(0.1), lineWidth: 1))
        .onAppear { updateAnimation() }
        .onChange(of: reduceMotion) { _ in updateAnimation() }
    }

    private func updateAnimation() {
        guard !reduceMotion else {
            isAnimating = false
            return
        }
        withAnimation(.easeInOut(duration: 0.75).repeatForever(autoreverses: true)) {
            isAnimating = true
        }
    }
}

private struct FilledActionButtonStyle: ButtonStyle {
    let tint: Color
    @Environment(\.isEnabled) private var isEnabled
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.body.weight(.semibold))
            .foregroundStyle(.white)
            .frame(maxWidth: .infinity)
            .frame(minHeight: 50)
            .background(isEnabled ? tint.opacity(configuration.isPressed ? 0.78 : 1) : SewerPalette.disabled, in: RoundedRectangle(cornerRadius: 8))
            .scaleEffect(configuration.isPressed && !reduceMotion ? 0.985 : 1)
            .animation(reduceMotion ? nil : .easeOut(duration: 0.12), value: configuration.isPressed)
    }
}

private struct SewerEntryMotion: ViewModifier {
    let delay: TimeInterval
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var hasAppeared = false

    func body(content: Content) -> some View {
        content
            .opacity(reduceMotion || hasAppeared ? 1 : 0)
            .offset(y: reduceMotion || hasAppeared ? 0 : 10)
            .onAppear {
                guard !reduceMotion, !hasAppeared else { return }
                withAnimation(.easeOut(duration: 0.3).delay(delay)) {
                    hasAppeared = true
                }
            }
    }
}

private extension View {
    func sewerEntryMotion(delay: TimeInterval) -> some View {
        modifier(SewerEntryMotion(delay: delay))
    }
}

private enum SewerPalette {
    static let canvas = Color(red: 244 / 255, green: 247 / 255, blue: 251 / 255)
    static let ink = Color(red: 15 / 255, green: 23 / 255, blue: 42 / 255)
    static let midnight = Color(red: 11 / 255, green: 18 / 255, blue: 32 / 255)
    static let blue = Color(red: 37 / 255, green: 99 / 255, blue: 235 / 255)
    static let blueLight = Color(red: 147 / 255, green: 197 / 255, blue: 253 / 255)
    static let muted = Color(red: 100 / 255, green: 116 / 255, blue: 139 / 255)
    static let slate = Color(red: 71 / 255, green: 85 / 255, blue: 105 / 255)
    static let slateLight = Color(red: 148 / 255, green: 163 / 255, blue: 184 / 255)
    static let border = Color(red: 226 / 255, green: 232 / 255, blue: 240 / 255)
    static let routeControlBackground = Color(red: 238 / 255, green: 242 / 255, blue: 247 / 255)
    static let connected = Color(red: 74 / 255, green: 222 / 255, blue: 128 / 255)
    static let warning = Color(red: 251 / 255, green: 191 / 255, blue: 36 / 255)
    static let disconnect = Color(red: 220 / 255, green: 38 / 255, blue: 38 / 255)
    static let disabled = Color(red: 148 / 255, green: 163 / 255, blue: 184 / 255)
}

private func currentClientVersionLabel() -> String {
    let version = Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.1.0"
    return "v\(version)"
}

#Preview("首次说明") {
    DataNoticeView()
        .environmentObject(AppModel())
}

#Preview("登录") {
    LoginView()
        .environmentObject(AppModel())
}

#Preview("主页") {
    HomeView()
        .environmentObject(AppModel())
}
