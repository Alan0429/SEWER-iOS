import Foundation
import NetworkExtension

private enum VPNServiceError: LocalizedError {
    case simulatorUnsupported
    case systemServiceUnavailable

    var errorDescription: String? {
        switch self {
        case .simulatorUnsupported:
            return "iOS 模拟器不支持建立 VPN 隧道，请在已签名的真机上测试连接。".appLocalized
        case .systemServiceUnavailable:
            return "系统 VPN 服务暂不可用。请重新打开 App 后重试；若问题持续，请重新安装已签名的客户端。".appLocalized
        }
    }
}

enum VPNConnectionAttemptResult {
    case connected
    case failed(reason: String?)
}

@MainActor
final class VPNService: ObservableObject {
    private static let diagnosticsSuiteName = "group.top.sewer.client.ios"
    private static let diagnosticsKey = "sewer.tunnel.last-start-error.v1"
    private static let connectionIntentKey = "sewer.tunnel.connection-intent.v1"
    private static let keepConnectedKey = "sewer.tunnel.keep-connected.v1"

    @Published private(set) var status: NEVPNStatus = .invalid
    // Incremented only when a tunnel that the user intended to keep active is
    // stopped by the system. AppModel uses this to start a foreground retry.
    @Published private(set) var unexpectedDisconnectID = 0
    private var manager: NETunnelProviderManager?
    private var statusObserver: NSObjectProtocol?
    private var disconnectRequestID = 0
    private var stopRequestedAt: Date?
    // This is deliberately separate from stopRequestedAt. The latter tracks
    // an asynchronous system stop operation; it must not cancel the user's
    // intent while an automatic recovery is cleaning up a failed attempt.
    private var userStopRequested = false
    @Published private var awaitingSystemStop = false
    private var configurationGeneration = 0
    private var recoveryNotificationPending = false
    private static let disconnectConfirmationTimeout: TimeInterval = 15

    var statusDescription: String {
        switch status {
        case .connected: return "已连接".appLocalized
        case .connecting, .reasserting: return "正在连接".appLocalized
        case .disconnecting: return "正在断开".appLocalized
        case .disconnected, .invalid: return "未连接".appLocalized
        @unknown default: return "未连接".appLocalized
        }
    }

    var isActive: Bool {
        if awaitingSystemStop { return true }
        switch status {
        case .connected, .connecting, .reasserting, .disconnecting:
            return true
        default:
            return false
        }
    }

    var isStoppingInBackground: Bool {
        awaitingSystemStop
    }

    var shouldAutomaticallyRecover: Bool {
        guard manager?.isEnabled == true else { return false }
        return connectionIntent && !userStopRequested
    }

    var keepConnected: Bool {
        UserDefaults(suiteName: Self.diagnosticsSuiteName)?.bool(forKey: Self.keepConnectedKey) ?? false
    }

    private var connectionIntent: Bool {
        UserDefaults(suiteName: Self.diagnosticsSuiteName)?.bool(forKey: Self.connectionIntentKey) ?? false
    }

    private func setConnectionIntent(_ enabled: Bool) {
        UserDefaults(suiteName: Self.diagnosticsSuiteName)?.set(enabled, forKey: Self.connectionIntentKey)
    }

    func setKeepConnected(_ enabled: Bool) {
        UserDefaults(suiteName: Self.diagnosticsSuiteName)?.set(enabled, forKey: Self.keepConnectedKey)
        if enabled {
            setConnectionIntent(true)
            userStopRequested = false
        } else if !isActive {
            setConnectionIntent(false)
            userStopRequested = true
        }
    }

    func load() async throws {
        TunnelDiagnostics.record(source: "客户端", message: "正在读取系统 VPN 配置。")
        let managers = try await NETunnelProviderManager.loadAllFromPreferences()
        let existing = managers.first { ($0.protocolConfiguration as? NETunnelProviderProtocol)?.providerBundleIdentifier == "top.sewer.client.ios.tunnel" }
        manager = existing ?? NETunnelProviderManager()
        if keepConnected {
            setConnectionIntent(true)
            userStopRequested = false
        }
        observeConnectionStatus()
        if shouldAutomaticallyRecover,
           manager?.connection.status == .disconnected || manager?.connection.status == .invalid {
            signalUnexpectedDisconnect(
                message: "检测到系统 VPN 未运行，正在恢复保护通道。"
            )
        }
        TunnelDiagnostics.record(source: "客户端", message: "系统 VPN 配置已就绪。")
    }

    func disconnect(keepConnectionIntent: Bool = false) async {
        if !keepConnectionIntent {
            setConnectionIntent(false)
        }
        userStopRequested = !keepConnectionIntent
        recoveryNotificationPending = false
        guard !awaitingSystemStop else { return }
        guard let manager, isActive else {
            stopRequestedAt = nil
            awaitingSystemStop = false
            status = .disconnected
            return
        }
        TunnelDiagnostics.record(source: "客户端", message: "已请求断开系统 VPN。")
        stopRequestedAt = Date()
        // Disable auto-reconnect before stopping, so a stale on-demand rule
        // cannot restart the tunnel after the user explicitly disconnected.
        manager.isOnDemandEnabled = false
        manager.onDemandRules = []
        do {
            try await manager.saveToPreferences()
        } catch {
            TunnelDiagnostics.record(source: "客户端", message: "断开时未能更新系统 VPN 自动恢复设置。")
        }
        TunnelDiagnostics.record(source: "客户端", message: "已停止系统自动重连。")
        manager.connection.stopVPNTunnel()
        disconnectRequestID += 1
        let requestID = disconnectRequestID
        // stopVPNTunnel() is asynchronous. Keep the primary action in the
        // stopping state until iOS confirms completion; otherwise a late
        // `.connected` notification can make one tap appear to do nothing.
        awaitingSystemStop = true
        status = .disconnecting
        Task { [weak self] in
            await self?.reconcileStopRequest(requestID: requestID)
        }
    }

    func connect(
        using node: SewerNode,
        routingMode: SewerRoutingMode,
        optimizedAddresses: [String] = []
    ) async throws {
        #if targetEnvironment(simulator)
        throw VPNServiceError.simulatorUnsupported
        #else
        guard !awaitingSystemStop else {
            throw SewerAPIError.server("系统正在完成上一次断开，请稍候再连接。")
        }
        do {
            try await load()
        } catch {
            throw VPNServiceError.systemServiceUnavailable
        }

        guard let manager else { throw SewerAPIError.server("无法配置系统网络扩展。") }
        guard manager.connection.status == .disconnected || manager.connection.status == .invalid else {
            throw SewerAPIError.server("系统仍在完成上一次断开，请稍候再连接。")
        }
        guard !isActive else { throw SewerAPIError.server("请先断开当前连接后再切换线路。") }

        clearProviderFailure()
        stopRequestedAt = nil
        recoveryNotificationPending = false
        configurationGeneration &+= 1
        TunnelDiagnostics.record(source: "客户端", message: "已开始创建 Tunnel 连接。")
        let coreKind = try SewerCoreRouter.kind(for: node)
        let remoteHost = try SewerCoreRouter.remoteHost(for: node)
        TunnelDiagnostics.record(
            source: "客户端",
            message: "准备使用 \(coreKind) 核心连接 \(node.displayProtocol) 线路。"
        )
        let secureAddresses = (try? await SewerBootstrapResolver.shared.resolveIPv4(remoteHost)) ?? []
        let usableOptimizedAddresses = optimizedAddresses
            .filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
            .reduce(into: [String]()) { result, address in
                if !result.contains(address) { result.append(address) }
            }
        let optimizedAddress = usableOptimizedAddresses.first
        let configuration: String
        if coreKind == "sing-box" {
            configuration = try SingBoxConfigurationFactory.make(
                for: node,
                routingMode: routingMode,
                resolvedAddresses: secureAddresses
            )
        } else {
            let xrayAddressPool = usableOptimizedAddresses.isEmpty
                ? secureAddresses
                : usableOptimizedAddresses
            configuration = try XrayConfigurationFactory.make(
                for: node,
                routingMode: routingMode,
                optimizedAddresses: xrayAddressPool,
                resolvedAddresses: secureAddresses
            )
        }
        let tunnel = NETunnelProviderProtocol()
        tunnel.providerBundleIdentifier = coreKind == "sing-box"
            ? "top.sewer.client.ios.tunnel.singbox"
            : "top.sewer.client.ios.tunnel"
        tunnel.serverAddress = "SEWER"
        // Keep a user-established Packet Tunnel active when the device locks.
        // This is Apple's documented default, but persisting it explicitly
        // prevents a configuration migration from changing the behavior.
        tunnel.disconnectOnSleep = false
        tunnel.providerConfiguration = [
            "coreEngine": coreKind,
            "tunnelConfiguration": configuration,
            "xrayConfiguration": configuration,
            "selectedNodeID": node.id,
            "routingMode": routingMode.rawValue,
            // These domains must remain on the physical interface. The extension
            // resolves them before it installs the default tunnel route.
            "remoteHost": remoteHost,
            "resolvedRemoteAddresses": secureAddresses,
            "optimizedAddress": optimizedAddress ?? "",
            "optimizedAddresses": usableOptimizedAddresses,
            "directHosts": [
                "sewer.com.cn",
                "api.sewer.com.cn",
                "sewer.top",
                "net.sewer.top",
                "api.sewer.top"
            ]
        ]
        manager.protocolConfiguration = tunnel
        manager.localizedDescription = "SEWER 企业网络安全访问".appLocalized
        manager.isEnabled = true
        // System-level auto-reconnect: after the user asks to connect, Connect
        // On Demand lets iOS restore the tunnel whenever the connection is
        // interrupted (network handoff, transient upstream failure, provider
        // stop) — including while the app is in the background. It is disabled
        // again the moment the user taps disconnect, so the tunnel never
        // returns without the user's intent.
        manager.isOnDemandEnabled = true
        manager.onDemandRules = [NEOnDemandRuleConnect()]
        let previousIntent = connectionIntent
        let previousUserStopRequested = userStopRequested
        setConnectionIntent(true)
        userStopRequested = false
        do {
            try await manager.saveToPreferences()
            try await manager.loadFromPreferences()
            TunnelDiagnostics.record(source: "客户端", message: "已启用系统自动重连（连接中断时自动恢复）。")
            try manager.connection.startVPNTunnel(options: ["sewerPreResolved": NSNumber(value: true)])
        } catch {
            setConnectionIntent(previousIntent)
            userStopRequested = previousUserStopRequested
            manager.isOnDemandEnabled = false
            manager.onDemandRules = []
            try? await manager.saveToPreferences()
            throw error
        }
        status = .connecting
        TunnelDiagnostics.record(source: "客户端", message: "已向系统提交 Tunnel 启动请求。")
        #endif
    }

    func waitUntilConnected(timeout: TimeInterval = 20) async -> VPNConnectionAttemptResult {
        let deadline = Date().addingTimeInterval(timeout)
        var sawConnectingStatus = false
        while Date() < deadline {
            if Task.isCancelled {
                TunnelDiagnostics.record(source: "客户端", message: "连接请求已取消。")
                return .failed(reason: "连接已取消。")
            }
            updateConnectionStatus()
            switch status {
            case .connected:
                TunnelDiagnostics.record(source: "客户端", message: "系统报告 Tunnel 已连接。")
                return .connected
            case .connecting, .reasserting:
                sawConnectingStatus = true
                try? await Task.sleep(nanoseconds: 250_000_000)
            case .disconnecting:
                TunnelDiagnostics.record(source: "客户端", message: "系统在连接过程中开始断开。")
                return .failed(reason: providerFailure())
            case .disconnected, .invalid:
                if sawConnectingStatus {
                    TunnelDiagnostics.record(source: "客户端", message: "系统在连接过程中终止了 Tunnel。")
                    return .failed(reason: providerFailure())
                }
                try? await Task.sleep(nanoseconds: 250_000_000)
            @unknown default:
                TunnelDiagnostics.record(source: "客户端", message: "系统返回了未知的 Tunnel 状态。")
                return .failed(reason: providerFailure())
            }
        }
        TunnelDiagnostics.record(source: "客户端", message: "等待系统建立 Tunnel 超时。")
        return .failed(reason: providerFailure() ?? "连接请求超时。")
    }

    // Waits until the tunnel is fully stopped and the on-demand rule has been
    // persisted, so a follow-up connect attempt starts from a clean state.
    func waitUntilStopped(timeout: TimeInterval = 15) async {
        let deadline = Date().addingTimeInterval(timeout)
        while Date() < deadline {
            if Task.isCancelled { return }
            updateConnectionStatus()
            if !isActive { return }
            try? await Task.sleep(nanoseconds: 250_000_000)
        }
    }

    private func clearProviderFailure() {
        UserDefaults(suiteName: Self.diagnosticsSuiteName)?.removeObject(forKey: Self.diagnosticsKey)
    }

    private func providerFailure() -> String? {
        guard let value = UserDefaults(suiteName: Self.diagnosticsSuiteName)?
            .string(forKey: Self.diagnosticsKey)?
            .trimmingCharacters(in: .whitespacesAndNewlines),
            !value.isEmpty else {
            return nil
        }
        return value
    }

    private func observeConnectionStatus() {
        if let statusObserver {
            NotificationCenter.default.removeObserver(statusObserver)
        }
        guard let manager else {
            status = .invalid
            return
        }
        updateConnectionStatus()
        statusObserver = NotificationCenter.default.addObserver(
            forName: .NEVPNStatusDidChange,
            object: manager.connection,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor in
                self?.updateConnectionStatus()
            }
        }
    }

    private func updateConnectionStatus() {
        let previousStatus = status
        let systemStatus = manager?.connection.status ?? .invalid
        if awaitingSystemStop {
            if systemStatus == .disconnected || systemStatus == .invalid {
                awaitingSystemStop = false
                status = systemStatus
            } else if !userStopRequested, systemStatus == .connected {
                // Connect On Demand may win the race while an automatic
                // recovery is cleaning up a failed foreground attempt. In
                // that case the tunnel is already healthy; do not keep the UI
                // in "disconnecting" or issue a second start request.
                awaitingSystemStop = false
                stopRequestedAt = nil
                recoveryNotificationPending = false
                status = .connected
            } else {
                status = .disconnecting
            }
            return
        }
        status = systemStatus
        if systemStatus == .connected {
            recoveryNotificationPending = false
        }
        detectUnexpectedDisconnect(previous: previousStatus, current: systemStatus)
    }

    // The user did not ask to stop, yet the system reported the tunnel ended.
    // If the extension also stopped writing its heartbeat before this moment,
    // the extension process was almost certainly terminated by the system
    // (memory pressure or crash) rather than asked to stop gracefully.
    private func detectUnexpectedDisconnect(previous: NEVPNStatus, current: NEVPNStatus) {
        guard stopRequestedAt == nil,
              previous == .connected || previous == .reasserting || previous == .connecting || previous == .disconnecting,
              current == .disconnected || current == .invalid else {
            return
        }
        let lastAlive = TunnelDiagnostics.lastAliveAt()
        let extensionWasAlive = lastAlive.map { Date().timeIntervalSince($0) < 90 } ?? false
        if extensionWasAlive {
            TunnelDiagnostics.record(source: "客户端", message: "检测到 VPN 意外断开，已启用自动恢复；扩展进程在停止前仍在运行，请查看 Tunnel 停止原因。")
        } else {
            TunnelDiagnostics.record(source: "客户端", message: "检测到 VPN 意外断开，已启用自动恢复；扩展进程疑似被系统终止（未记录停止事件），请查看系统崩溃日志。")
        }
        signalUnexpectedDisconnect()
    }

    private func signalUnexpectedDisconnect(message: String? = nil) {
        guard shouldAutomaticallyRecover, !recoveryNotificationPending else { return }
        recoveryNotificationPending = true
        if let message {
            TunnelDiagnostics.record(source: "客户端", message: message)
        }
        unexpectedDisconnectID &+= 1
    }

    private func reconcileStopRequest(requestID: Int) async {
        // iOS may delay the status notification after the provider has already
        // stopped. The extension writes a post-close marker to the App Group,
        // which is more reliable than indefinitely retaining the old manager's
        // `.disconnecting` value in the UI.
        let deadline = Date().addingTimeInterval(Self.disconnectConfirmationTimeout)
        while Date() < deadline {
            guard requestID == disconnectRequestID else { return }
            if providerHasStopped(for: stopRequestedAt) {
                await refreshAfterProviderStop()
                guard requestID == disconnectRequestID else { return }
                awaitingSystemStop = false
                stopRequestedAt = nil
                status = .disconnected
                TunnelDiagnostics.record(source: "客户端", message: "Tunnel 已完成停止。")
                return
            }
            let systemStatus = manager?.connection.status ?? .invalid
            if systemStatus == .disconnected || systemStatus == .invalid {
                awaitingSystemStop = false
                stopRequestedAt = nil
                status = systemStatus
                return
            }
            try? await Task.sleep(nanoseconds: 500_000_000)
        }
        guard requestID == disconnectRequestID else { return }

        // A stale NETunnelProviderManager can retain `.disconnecting` after
        // iOS has already replaced or stopped the provider. Reload the current
        // preferences once before deciding that the stop is still in flight.
        await refreshAfterProviderStop()
        guard requestID == disconnectRequestID else { return }
        let refreshedStatus = manager?.connection.status ?? .invalid
        if refreshedStatus == .disconnected || refreshedStatus == .invalid {
            awaitingSystemStop = false
            stopRequestedAt = nil
            status = refreshedStatus
            TunnelDiagnostics.record(source: "客户端", message: "已从系统配置确认 Tunnel 完成停止。")
            return
        }

        // Do not keep the primary action permanently locked behind a custom
        // flag. Surface the authoritative system state and allow a fresh load
        // or foreground refresh to reconcile it if iOS is unusually slow.
        awaitingSystemStop = false
        status = refreshedStatus
        TunnelDiagnostics.record(
            source: "客户端",
            message: "系统未在限定时间内确认 Tunnel 停止，已恢复为系统当前状态。"
        )
    }

    private func providerHasStopped(for requestedAt: Date?) -> Bool {
        guard let requestedAt,
              let stoppedAt = TunnelDiagnostics.stopCompletedAt() else {
            return false
        }
        return stoppedAt >= requestedAt
    }

    private func refreshAfterProviderStop() async {
        do {
            let managers = try await NETunnelProviderManager.loadAllFromPreferences()
            manager = managers.first {
                ($0.protocolConfiguration as? NETunnelProviderProtocol)?.providerBundleIdentifier == "top.sewer.client.ios.tunnel"
            } ?? manager
            observeConnectionStatus()
        } catch {
            // The extension confirmation is enough to unlock the UI. A later
            // connect operation will load preferences again before starting.
        }
    }

    func removeConfigurationAfterLogout() async {
        UserDefaults(suiteName: Self.diagnosticsSuiteName)?.set(false, forKey: Self.keepConnectedKey)
        setConnectionIntent(false)
        let removalGeneration = configurationGeneration
        if manager == nil {
            do {
                let managers = try await NETunnelProviderManager.loadAllFromPreferences()
                manager = managers.first {
                    ($0.protocolConfiguration as? NETunnelProviderProtocol)?.providerBundleIdentifier == "top.sewer.client.ios.tunnel"
                }
            } catch {
                TunnelDiagnostics.record(source: "客户端", message: "退出时无法读取系统 VPN 配置。")
                return
            }
        }
        guard let manager else { return }

        if manager.connection.status != .disconnected && manager.connection.status != .invalid {
            await disconnect()
            for _ in 0..<20 {
                let systemStatus = manager.connection.status
                if systemStatus == .disconnected || systemStatus == .invalid { break }
                try? await Task.sleep(nanoseconds: 250_000_000)
            }
        }

        let systemStatus = manager.connection.status
        guard systemStatus == .disconnected || systemStatus == .invalid else {
            TunnelDiagnostics.record(source: "客户端", message: "系统 VPN 尚未停止，配置将在系统完成断开后保留。")
            return
        }

        // Do not let a delayed sign-out cleanup remove a configuration that a
        // user has created again after signing back in.
        guard removalGeneration == configurationGeneration else { return }

        do {
            try await manager.removeFromPreferences()
            self.manager = nil
            awaitingSystemStop = false
            status = .disconnected
            TunnelDiagnostics.record(source: "客户端", message: "已移除退出账户的系统 VPN 配置。")
        } catch {
            TunnelDiagnostics.record(source: "客户端", message: "退出时未能移除系统 VPN 配置。")
        }
    }

    deinit {
        if let statusObserver {
            NotificationCenter.default.removeObserver(statusObserver)
        }
    }
}
