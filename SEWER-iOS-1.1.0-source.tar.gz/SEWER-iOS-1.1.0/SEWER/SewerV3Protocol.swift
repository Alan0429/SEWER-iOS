import CryptoKit
import Foundation
import Network
import Security

enum SewerClientIdentity {
    static var version: String {
        Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "1.1.0"
    }

    static var userAgent: String {
        "SEWER/\(version) iOS"
    }
}

enum SewerV3Error: LocalizedError {
    case invalidResponse
    case invalidConfiguration
    case protocolFailure(String)
    case server(status: Int, message: String, code: String?)
    case transport(String)

    var errorDescription: String? {
        switch self {
        case .invalidResponse:
            return "服务返回的数据无效，请稍后重试。".appLocalized
        case .invalidConfiguration:
            return "服务地址配置无效。".appLocalized
        case .protocolFailure(let message):
            return message
        case .server(_, let message, _):
            return message.appLocalized
        case .transport(let message):
            return message
        }
    }

    var statusCode: Int? {
        if case .server(let status, _, _) = self { return status }
        return nil
    }

    var errorCode: String? {
        if case .server(_, _, let code) = self { return code }
        return nil
    }
}

enum SewerBase64URL {
    static func encode(_ data: Data) -> String {
        data.base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }

    static func decode(_ value: String?) -> Data? {
        guard let value, !value.isEmpty, !value.contains("="), value.count % 4 != 1 else {
            return nil
        }
        guard value.unicodeScalars.allSatisfy({
            CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_").contains($0)
        }) else {
            return nil
        }
        let base64 = value
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
            .padding(toLength: ((value.count + 3) / 4) * 4, withPad: "=", startingAt: 0)
        guard let decoded = Data(base64Encoded: base64), encode(decoded) == value else { return nil }
        return decoded
    }
}

enum SewerCanonicalJSON {
    static func data(_ value: Any) throws -> Data {
        var output = Data()
        try append(value, to: &output)
        return output
    }

    static func string(_ value: Any) throws -> String {
        guard let result = String(data: try data(value), encoding: .utf8) else {
            throw SewerV3Error.protocolFailure("JSON 编码失败。".appLocalized)
        }
        return result
    }

    private static func append(_ value: Any, to output: inout Data) throws {
        if value is NSNull {
            output.append(contentsOf: Data("null".utf8))
            return
        }
        if let dictionary = value as? [String: Any] {
            output.append(0x7B)
            for (index, key) in dictionary.keys.sorted().enumerated() {
                if index > 0 { output.append(0x2C) }
                appendString(key, to: &output)
                output.append(0x3A)
                try append(dictionary[key] as Any, to: &output)
            }
            output.append(0x7D)
            return
        }
        if let array = value as? [Any] {
            output.append(0x5B)
            for (index, item) in array.enumerated() {
                if index > 0 { output.append(0x2C) }
                try append(item, to: &output)
            }
            output.append(0x5D)
            return
        }
        if let string = value as? String {
            appendString(string, to: &output)
            return
        }
        if let number = value as? NSNumber {
            if CFGetTypeID(number) == CFBooleanGetTypeID() {
                output.append(contentsOf: Data((number.boolValue ? "true" : "false").utf8))
            } else {
                output.append(contentsOf: Data(number.stringValue.utf8))
            }
            return
        }
        if let bool = value as? Bool {
            output.append(contentsOf: Data((bool ? "true" : "false").utf8))
            return
        }
        if let integer = value as? Int {
            output.append(contentsOf: Data(String(integer).utf8))
            return
        }
        if let integer = value as? Int64 {
            output.append(contentsOf: Data(String(integer).utf8))
            return
        }
        throw SewerV3Error.protocolFailure("不支持的 JSON 数据类型。".appLocalized)
    }

    private static func appendString(_ value: String, to output: inout Data) {
        output.append(0x22)
        for scalar in value.unicodeScalars {
            switch scalar.value {
            case 0x22:
                output.append(contentsOf: Data("\\\"".utf8))
            case 0x5C:
                output.append(contentsOf: Data("\\\\".utf8))
            case 0x08:
                output.append(contentsOf: Data("\\b".utf8))
            case 0x0C:
                output.append(contentsOf: Data("\\f".utf8))
            case 0x0A:
                output.append(contentsOf: Data("\\n".utf8))
            case 0x0D:
                output.append(contentsOf: Data("\\r".utf8))
            case 0x09:
                output.append(contentsOf: Data("\\t".utf8))
            case 0x00...0x1F:
                output.append(contentsOf: Data(String(format: "\\u%04x", scalar.value).utf8))
            default:
                output.append(contentsOf: String(scalar).utf8)
            }
        }
        output.append(0x22)
    }
}

struct SewerHTTPResponse {
    let status: Int
    let headers: [String: String]
    let body: Data
}

enum SewerHTTPTransport {
    static func perform(
        host: String,
        connectIP: String? = nil,
        port: Int = 443,
        method: String,
        path: String,
        headers: [String: String] = [:],
        body: Data = Data(),
        timeout: TimeInterval = 20,
        maxResponseBytes: Int = 1_048_576
    ) async throws -> SewerHTTPResponse {
        let addresses: [String]
        if let connectIP {
            addresses = [connectIP]
        } else {
            addresses = try await SewerBootstrapResolver.shared.resolveIPv4(host)
        }
        guard !addresses.isEmpty else {
            throw SewerV3Error.transport("无法安全解析 SEWER 服务域名。".appLocalized)
        }

        var lastError: Error?
        for address in addresses.prefix(4) {
            do {
                return try await exchange(
                    host: host,
                    connectIP: address,
                    port: port,
                    method: method,
                    path: path,
                    headers: headers,
                    body: body,
                    timeout: timeout,
                    maxResponseBytes: maxResponseBytes
                )
            } catch {
                lastError = error
            }
        }
        throw lastError ?? SewerV3Error.transport("无法连接 SEWER 服务。".appLocalized)
    }

    private static func exchange(
        host: String,
        connectIP: String,
        port: Int,
        method: String,
        path: String,
        headers: [String: String],
        body: Data,
        timeout: TimeInterval,
        maxResponseBytes: Int
    ) async throws -> SewerHTTPResponse {
        guard let networkPort = NWEndpoint.Port(rawValue: UInt16(port)) else {
            throw SewerV3Error.invalidConfiguration
        }
        let tls = NWProtocolTLS.Options()
        sec_protocol_options_set_tls_server_name(tls.securityProtocolOptions, host)
        sec_protocol_options_set_min_tls_protocol_version(tls.securityProtocolOptions, .TLSv12)
        let parameters = NWParameters(tls: tls, tcp: NWProtocolTCP.Options())
        parameters.allowLocalEndpointReuse = true
        parameters.includePeerToPeer = false
        let connection = NWConnection(
            host: NWEndpoint.Host(connectIP),
            port: networkPort,
            using: parameters
        )

        return try await withCheckedThrowingContinuation { continuation in
            let exchange = SewerHTTPExchange(
                connection: connection,
                continuation: continuation,
                maxResponseBytes: maxResponseBytes
            )
            exchange.start(host: host, method: method, path: path, headers: headers, body: body)
            let timeoutItem = DispatchWorkItem {
                exchange.finish(throwing: SewerV3Error.transport("连接 SEWER 服务超时。".appLocalized))
            }
            exchange.setTimeoutItem(timeoutItem)
            DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + timeout, execute: timeoutItem)
        }
    }
}

private final class SewerHTTPExchange: @unchecked Sendable {
    private let connection: NWConnection
    private let continuation: CheckedContinuation<SewerHTTPResponse, Error>
    private let maxResponseBytes: Int
    private let lock = NSLock()
    private var completed = false
    private var responseData = Data()
    private var timeoutItem: DispatchWorkItem?

    init(
        connection: NWConnection,
        continuation: CheckedContinuation<SewerHTTPResponse, Error>,
        maxResponseBytes: Int
    ) {
        self.connection = connection
        self.continuation = continuation
        self.maxResponseBytes = maxResponseBytes
    }

    func setTimeoutItem(_ item: DispatchWorkItem) {
        lock.lock()
        timeoutItem = item
        lock.unlock()
    }

    func start(host: String, method: String, path: String, headers: [String: String], body: Data) {
        connection.stateUpdateHandler = { [weak self] state in
            guard let self else { return }
            switch state {
            case .ready:
                self.sendRequest(host: host, method: method, path: path, headers: headers, body: body)
            case .failed(let error):
                self.finish(throwing: SewerV3Error.transport(
                    "连接 SEWER 服务失败：\(error.localizedDescription)".appLocalized
                ))
            case .cancelled:
                self.finish(throwing: SewerV3Error.transport("SEWER 服务连接已取消。".appLocalized))
            default:
                break
            }
        }
        connection.start(queue: .global(qos: .utility))
    }

    func finish(throwing error: Error) {
        lock.lock()
        guard !completed else {
            lock.unlock()
            return
        }
        completed = true
        timeoutItem?.cancel()
        lock.unlock()
        connection.cancel()
        continuation.resume(throwing: error)
    }

    func finish(returning response: SewerHTTPResponse) {
        lock.lock()
        guard !completed else {
            lock.unlock()
            return
        }
        completed = true
        timeoutItem?.cancel()
        lock.unlock()
        connection.cancel()
        continuation.resume(returning: response)
    }

    private func sendRequest(host: String, method: String, path: String, headers: [String: String], body: Data) {
        var mergedHeaders = headers
        mergedHeaders["Host"] = host
        mergedHeaders["Accept-Encoding"] = "identity"
        mergedHeaders["Connection"] = "close"
        mergedHeaders["Content-Length"] = String(body.count)
        if method.uppercased() != "GET", mergedHeaders["Content-Type"] == nil {
            mergedHeaders["Content-Type"] = "application/json; charset=utf-8"
        }
        let orderedHeaders = mergedHeaders.keys.sorted().map { "\($0): \(mergedHeaders[$0] ?? "")" }
        let head = "\(method.uppercased()) \(path) HTTP/1.1\r\n" + orderedHeaders.joined(separator: "\r\n") + "\r\n\r\n"
        var request = Data(head.utf8)
        request.append(body)
        connection.send(content: request, completion: .contentProcessed { [weak self] error in
            guard let self else { return }
            if let error {
                self.finish(throwing: SewerV3Error.transport(
                    "发送 SEWER 请求失败：\(error.localizedDescription)".appLocalized
                ))
                return
            }
            self.receive()
        })
    }

    private func receive() {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 65_536) {
            [weak self] data, _, isComplete, error in
            guard let self else { return }
            if let data, !data.isEmpty {
                self.lock.lock()
                self.responseData.append(data)
                let tooLarge = self.responseData.count > self.maxResponseBytes + 65_536
                self.lock.unlock()
                if tooLarge {
                    self.finish(throwing: SewerV3Error.protocolFailure("服务器响应过大。".appLocalized))
                    return
                }
            }
            if let error {
                self.parseResponseIfReady(isComplete: true, transportError: error)
                return
            }
            if self.parseResponseIfReady(isComplete: isComplete, transportError: nil) {
                return
            }
            if isComplete {
                self.finish(throwing: SewerV3Error.transport("SEWER 服务提前断开响应。".appLocalized))
            } else {
                self.receive()
            }
        }
    }

    @discardableResult
    private func parseResponseIfReady(isComplete: Bool, transportError: Error?) -> Bool {
        lock.lock()
        let snapshot = responseData
        lock.unlock()
        let separator = Data("\r\n\r\n".utf8)
        guard let headerRange = snapshot.range(of: separator) else {
            if isComplete, transportError != nil {
                finish(throwing: transportError!)
                return true
            }
            return false
        }
        let headerData = snapshot[..<headerRange.lowerBound]
        let bodyStart = headerRange.upperBound
        guard let headerText = String(data: headerData, encoding: .utf8) else {
            finish(throwing: SewerV3Error.invalidResponse)
            return true
        }
        let lines = headerText.components(separatedBy: "\r\n")
        guard let statusLine = lines.first else {
            finish(throwing: SewerV3Error.invalidResponse)
            return true
        }
        let statusParts = statusLine.split(separator: " ", maxSplits: 2)
        guard statusParts.count >= 2, let status = Int(statusParts[1]) else {
            finish(throwing: SewerV3Error.invalidResponse)
            return true
        }
        var headers: [String: String] = [:]
        for line in lines.dropFirst() {
            guard let colon = line.firstIndex(of: ":") else { continue }
            let name = String(line[..<colon]).trimmingCharacters(in: .whitespaces).lowercased()
            let value = String(line[line.index(after: colon)...]).trimmingCharacters(in: .whitespaces)
            headers[name] = value
        }
        let contentLength: Int?
        if let rawContentLength = headers["content-length"] {
            guard let parsed = Int(rawContentLength), parsed >= 0, parsed <= maxResponseBytes else {
                finish(throwing: SewerV3Error.invalidResponse)
                return true
            }
            contentLength = parsed
        } else {
            contentLength = nil
        }
        let bodyCount = snapshot.count - bodyStart
        let declaredComplete = contentLength.map { bodyCount >= $0 } ?? false
        if let contentLength, bodyCount < contentLength {
            if isComplete {
                finish(throwing: SewerV3Error.invalidResponse)
                return true
            }
            return false
        }
        guard isComplete || declaredComplete else { return false }
        guard bodyCount <= maxResponseBytes else {
            finish(throwing: SewerV3Error.protocolFailure("服务器响应过大。".appLocalized))
            return true
        }

        var body = Data(snapshot[bodyStart...])
        if headers["transfer-encoding"]?.lowercased().contains("chunked") == true {
            guard let decoded = Self.decodeChunked(body, complete: isComplete) else {
                if isComplete {
                    finish(throwing: SewerV3Error.invalidResponse)
                    return true
                }
                return false
            }
            body = decoded
        } else if let contentLength, body.count > contentLength {
            body = Data(body.prefix(contentLength))
        }
        finish(returning: SewerHTTPResponse(status: status, headers: headers, body: body))
        return true
    }

    private static func decodeChunked(_ data: Data, complete: Bool) -> Data? {
        var offset = data.startIndex
        var output = Data()
        while offset < data.endIndex {
            guard let lineEnd = data[offset...].range(of: Data("\r\n".utf8)) else { return nil }
            guard let sizeText = String(data: data[offset..<lineEnd.lowerBound], encoding: .utf8),
                  let size = Int(sizeText.split(separator: ";", maxSplits: 1).first ?? "", radix: 16),
                  size >= 0,
                  size <= 64 * 1_048_576 else {
                return nil
            }
            offset = lineEnd.upperBound
            if size == 0 { return output }
            let remainingBytes = data.count - data.distance(from: data.startIndex, to: offset)
            guard remainingBytes >= size, remainingBytes - size >= 2 else {
                return nil
            }
            let end = data.index(offset, offsetBy: size)
            output.append(data[offset..<end])
            guard data.index(end, offsetBy: 2, limitedBy: data.endIndex) != nil else { return nil }
            offset = data.index(end, offsetBy: 2)
        }
        return complete ? output : nil
    }
}

actor SewerBootstrapResolver {
    static let shared = SewerBootstrapResolver()

    private struct CacheEntry {
        let addresses: [String]
        let expiresAt: Date
    }

    private var cache: [String: CacheEntry] = [:]
    private let dohAddresses = ["223.5.5.5", "1.12.12.12"]
    private let plainFallbackServers = ["1.2.4.8", "223.5.5.5"]
    // Used only after every secure and plain resolution path fails. TLS still
    // validates the certificate against net.sewer.top because only the dial
    // address changes; the HTTP/SNI hostname never changes to this IP.
    private let emergencyServiceAddresses = ["117.72.151.26"]

    func resolveIPv4(_ host: String) async throws -> [String] {
        let normalized = host.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "."))
            .lowercased()
        guard Self.isProtectedHostname(normalized) else {
            return try Self.systemIPv4(normalized)
        }
        if let cached = cache[normalized], cached.expiresAt > Date(), !cached.addresses.isEmpty {
            return cached.addresses
        }
        for address in dohAddresses {
            if let answer = try? await queryDoH(host: normalized, address: address) {
                let usable = answer.addresses.filter(Self.isPublicIPv4)
                guard !usable.isEmpty else { continue }
                let ttl = min(max(answer.ttl, 30), 600)
                cache[normalized] = CacheEntry(
                    addresses: usable,
                    expiresAt: Date().addingTimeInterval(TimeInterval(ttl))
                )
                return usable
            }
        }
        for server in plainFallbackServers {
            if let addresses = try? Self.queryUDP(host: normalized, server: server) {
                let usable = addresses.filter(Self.isPublicIPv4)
                guard !usable.isEmpty else { continue }
                cache[normalized] = CacheEntry(
                    addresses: usable,
                    expiresAt: Date().addingTimeInterval(120)
                )
                return usable
            }
        }
        let system = ((try? Self.systemIPv4(normalized)) ?? []).filter(Self.isPublicIPv4)
        if !system.isEmpty {
            return system
        }
        if normalized == "net.sewer.top" {
            cache[normalized] = CacheEntry(
                addresses: emergencyServiceAddresses,
                expiresAt: Date().addingTimeInterval(60)
            )
            return emergencyServiceAddresses
        }
        throw SewerV3Error.transport("服务域名没有可用的公网 IPv4 地址。".appLocalized)
    }

    static func isProtectedHostname(_ hostname: String) -> Bool {
        let value = hostname.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "."))
            .lowercased()
        let suffixes = [
            "sewer.com.cn",
            "sewer.top",
            "sewer-dns.top",
            "aws.amazon.com",
            "amazonaws.com"
        ]
        return suffixes.contains { value == $0 || value.hasSuffix(".\($0)") }
    }

    static func isSewerHostname(_ hostname: String) -> Bool {
        let value = hostname.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "."))
            .lowercased()
        let suffixes = ["sewer.com.cn", "sewer.top", "sewer-dns.top"]
        return suffixes.contains { value == $0 || value.hasSuffix(".\($0)") }
    }

    static func isPublicIPv4(_ address: String) -> Bool {
        let parts = address.split(separator: ".").compactMap { Int($0) }
        guard parts.count == 4, parts.allSatisfy({ (0...255).contains($0) }) else { return false }
        let first = parts[0]
        let second = parts[1]
        let third = parts[2]
        if first == 0 || first == 10 || first == 127 || first >= 224 { return false }
        if first == 100, (64...127).contains(second) { return false }
        if first == 169, second == 254 { return false }
        if first == 172, (16...31).contains(second) { return false }
        if first == 192, second == 0 || second == 168 { return false }
        if first == 192, second == 88, third == 99 { return false }
        if first == 198, (18...19).contains(second) { return false }
        if first == 198, second == 51 { return false }
        if first == 203, second == 0 { return false }
        return true
    }

    private func queryDoH(host: String, address: String) async throws -> (addresses: [String], ttl: Int) {
        let transaction = UInt16.random(in: 1...UInt16.max)
        guard let query = Self.makeQuery(host: host, transaction: transaction, type: 1) else {
            throw SewerV3Error.transport("DNS 请求名称无效。".appLocalized)
        }
        let path = "/dns-query?dns=\(SewerBase64URL.encode(query))"
        let response = try await SewerHTTPTransport.perform(
            host: address,
            connectIP: address,
            method: "GET",
            path: path,
            headers: [
                "Accept": "application/dns-message",
                "User-Agent": SewerClientIdentity.userAgent
            ],
            timeout: 5,
            maxResponseBytes: 4_096
        )
        guard (200...299).contains(response.status),
              let answer = Self.parseResponse(response.body, transaction: transaction, host: host),
              !answer.addresses.isEmpty else {
            throw SewerV3Error.invalidResponse
        }
        return answer
    }

    private static func systemIPv4(_ host: String) throws -> [String] {
        var hints = addrinfo(
            ai_flags: AI_ADDRCONFIG,
            ai_family: AF_INET,
            ai_socktype: SOCK_STREAM,
            ai_protocol: IPPROTO_TCP,
            ai_addrlen: 0,
            ai_canonname: nil,
            ai_addr: nil,
            ai_next: nil
        )
        var result: UnsafeMutablePointer<addrinfo>?
        guard getaddrinfo(host, "443", &hints, &result) == 0, let first = result else {
            throw SewerV3Error.transport("无法解析服务域名。".appLocalized)
        }
        defer { freeaddrinfo(first) }
        var addresses: [String] = []
        var current: UnsafeMutablePointer<addrinfo>? = first
        while let pointer = current {
            var buffer = [CChar](repeating: 0, count: Int(NI_MAXHOST))
            if getnameinfo(
                pointer.pointee.ai_addr,
                pointer.pointee.ai_addrlen,
                &buffer,
                socklen_t(buffer.count),
                nil,
                0,
                NI_NUMERICHOST
            ) == 0 {
                let value = String(cString: buffer)
                if !addresses.contains(value) { addresses.append(value) }
            }
            current = pointer.pointee.ai_next
        }
        guard !addresses.isEmpty else {
            throw SewerV3Error.transport("服务域名没有可用的 IPv4 地址。".appLocalized)
        }
        return addresses
    }

    private static func queryUDP(host: String, server: String) throws -> [String] {
        let transaction = UInt16.random(in: 1...UInt16.max)
        guard let query = makeQuery(host: host, transaction: transaction, type: 1) else {
            throw SewerV3Error.transport("DNS 请求名称无效。".appLocalized)
        }
        let descriptor = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)
        guard descriptor >= 0 else { throw SewerV3Error.transport("无法创建 DNS 连接。".appLocalized) }
        defer { close(descriptor) }
        var timeout = timeval(tv_sec: 1, tv_usec: 500_000)
        setsockopt(
            descriptor,
            SOL_SOCKET,
            SO_RCVTIMEO,
            &timeout,
            socklen_t(MemoryLayout<timeval>.size)
        )
        var address = sockaddr_in()
        address.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        address.sin_family = sa_family_t(AF_INET)
        address.sin_port = in_port_t(53).bigEndian
        guard server.withCString({ inet_pton(AF_INET, $0, &address.sin_addr) }) == 1 else {
            throw SewerV3Error.invalidConfiguration
        }
        let connected = withUnsafePointer(to: &address) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                connect(descriptor, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        guard connected == 0 else { throw SewerV3Error.transport("DNS 连接失败。".appLocalized) }
        let sent = query.withUnsafeBytes { send(descriptor, $0.baseAddress, $0.count, 0) }
        guard sent == query.count else { throw SewerV3Error.transport("DNS 请求发送失败。".appLocalized) }
        var buffer = [UInt8](repeating: 0, count: 4_096)
        let received = recv(descriptor, &buffer, buffer.count, 0)
        guard received > 12 else { throw SewerV3Error.transport("DNS 响应无效。".appLocalized) }
        guard let answer = parseResponse(Data(buffer.prefix(received)), transaction: transaction, host: host) else {
            throw SewerV3Error.transport("DNS 响应无效。".appLocalized)
        }
        return answer.addresses
    }

    private static func makeQuery(host: String, transaction: UInt16, type: UInt16) -> Data? {
        let labels = host.split(separator: ".", omittingEmptySubsequences: false)
        guard !labels.isEmpty,
              labels.allSatisfy({ !$0.isEmpty && $0.utf8.count <= 63 }),
              1 + labels.reduce(0, { $0 + 1 + $1.utf8.count }) <= 255 else {
            return nil
        }
        var data = Data()
        appendUInt16(transaction, to: &data)
        appendUInt16(0x0100, to: &data)
        appendUInt16(1, to: &data)
        appendUInt16(0, to: &data)
        appendUInt16(0, to: &data)
        appendUInt16(0, to: &data)
        for label in labels {
            data.append(UInt8(label.utf8.count))
            data.append(contentsOf: label.utf8)
        }
        data.append(0)
        appendUInt16(type, to: &data)
        appendUInt16(1, to: &data)
        return data
    }

    private static func parseResponse(_ data: Data, transaction: UInt16, host: String) -> (addresses: [String], ttl: Int)? {
        guard data.count >= 12 else { return nil }
        var offset = 0
        guard readUInt16(data, offset: &offset) == transaction,
              let flags = readUInt16(data, offset: &offset),
              flags & 0x8000 != 0,
              flags & 0x000F == 0,
              let questionCount = readUInt16(data, offset: &offset),
              questionCount > 0,
              let answerCount = readUInt16(data, offset: &offset),
              readUInt16(data, offset: &offset) != nil,
              readUInt16(data, offset: &offset) != nil else { return nil }
        for index in 0..<Int(questionCount) {
            guard let questionName = readName(data, offset: &offset),
                  readUInt16(data, offset: &offset) != nil,
                  readUInt16(data, offset: &offset) != nil else { return nil }
            if index == 0,
               questionName.trimmingCharacters(in: CharacterSet(charactersIn: ".")).lowercased()
                != host.trimmingCharacters(in: CharacterSet(charactersIn: ".")).lowercased() {
                return nil
            }
        }
        var addresses: [String] = []
        var minimumTTL = 600
        for _ in 0..<Int(answerCount) {
            guard skipName(data, offset: &offset),
                  let type = readUInt16(data, offset: &offset),
                  let recordClass = readUInt16(data, offset: &offset),
                  let ttl = readUInt32(data, offset: &offset),
                  let length = readUInt16(data, offset: &offset),
                  offset + Int(length) <= data.count else { return nil }
            if type == 1, recordClass == 1, length == 4 {
                let address = "\(data[offset]).\(data[offset + 1]).\(data[offset + 2]).\(data[offset + 3])"
                if !addresses.contains(address) { addresses.append(address) }
                minimumTTL = min(minimumTTL, Int(ttl))
            }
            offset += Int(length)
        }
        return addresses.isEmpty ? nil : (addresses, minimumTTL)
    }

    private static func skipName(_ data: Data, offset: inout Int) -> Bool {
        var traversals = 0
        while offset < data.count, traversals < 128 {
            traversals += 1
            let length = Int(data[offset])
            if length & 0xC0 == 0xC0 {
                guard offset + 2 <= data.count else { return false }
                offset += 2
                return true
            }
            if length == 0 {
                offset += 1
                return true
            }
            guard length & 0xC0 == 0, length <= 63, offset + length + 1 <= data.count else { return false }
            offset += length + 1
        }
        return false
    }

    private static func readName(_ data: Data, offset: inout Int) -> String? {
        var labels: [String] = []
        var cursor = offset
        var nextOffset: Int?
        var jumps = 0
        while cursor < data.count, jumps < 32 {
            let length = Int(data[cursor])
            if length & 0xC0 == 0xC0 {
                guard cursor + 2 <= data.count else { return nil }
                let pointer = (length & 0x3F) << 8 | Int(data[cursor + 1])
                guard pointer < data.count else { return nil }
                if nextOffset == nil { nextOffset = cursor + 2 }
                cursor = pointer
                jumps += 1
                continue
            }
            guard length & 0xC0 == 0 else { return nil }
            if length == 0 {
                offset = nextOffset ?? cursor + 1
                return labels.joined(separator: ".")
            }
            guard length <= 63, cursor + 1 + length <= data.count,
                  let label = String(data: data[(cursor + 1)..<(cursor + 1 + length)], encoding: .utf8) else {
                return nil
            }
            labels.append(label)
            cursor += 1 + length
        }
        return nil
    }

    private static func appendUInt16(_ value: UInt16, to data: inout Data) {
        data.append(UInt8(value >> 8))
        data.append(UInt8(truncatingIfNeeded: value))
    }

    private static func readUInt16(_ data: Data, offset: inout Int) -> UInt16? {
        guard offset + 2 <= data.count else { return nil }
        let value = UInt16(data[offset]) << 8 | UInt16(data[offset + 1])
        offset += 2
        return value
    }

    private static func readUInt32(_ data: Data, offset: inout Int) -> UInt32? {
        guard offset + 4 <= data.count else { return nil }
        let value = UInt32(data[offset]) << 24 |
            UInt32(data[offset + 1]) << 16 |
            UInt32(data[offset + 2]) << 8 |
            UInt32(data[offset + 3])
        offset += 4
        return value
    }
}

struct SewerV3RPCResult {
    let statusCode: Int
    let status: String?
    let message: String?
    let body: Any?
    let baseURL: String
}

actor SewerV3Transport {
    static let shared = SewerV3Transport()

    static let version = 3
    static let aead = "chacha20-poly1305-ietf"
    static let signingKeyID = "sewer-api-v3-signing-2026-11"
    static let signingPublicKey = "iD-cPlfnbN_Nnft-i3o0br9Ik0FZPkj-b9U5Ejs1gTI"
    static let candidateBaseURLs = [
        "https://api.sewer.com.cn",
        "https://net.sewer.top",
        "https://api.sewer.top"
    ]

    private struct Session {
        let id: String
        let clientToServerKey: Data
        let serverToClientKey: Data
        let expiresAt: Int64
        let maxRequests: Int
        var requestCount = 0

        func isUsable(at now: Int64) -> Bool {
            expiresAt > now + 5 && requestCount < maxRequests
        }
    }

    private var sessions: [String: Session] = [:]

    func rpc(
        baseURL: String,
        operation: String,
        path: [String: Any] = [:],
        query: [String: Any] = [:],
        body: [String: Any] = [:],
        authorization: String? = nil,
        headers: [String: String] = [:]
    ) async throws -> SewerV3RPCResult {
        let normalized = try Self.normalizeBaseURL(baseURL)
        var activeSession = try await session(for: normalized)
        do {
            let result = try await sendRPC(
                baseURL: normalized,
                session: activeSession,
                operation: operation,
                path: path,
                query: query,
                body: body,
                authorization: authorization,
                headers: headers
            )
            sessions[normalized]?.requestCount += 1
            return result
        } catch let error as SewerV3Error where
            (error.statusCode == 401 && error.errorCode == "session_unknown_or_expired") ||
            (error.statusCode == 429 && error.errorCode == "session_request_limit_reached") {
            sessions.removeValue(forKey: normalized)
            activeSession = try await session(for: normalized)
            let result = try await sendRPC(
                baseURL: normalized,
                session: activeSession,
                operation: operation,
                path: path,
                query: query,
                body: body,
                authorization: authorization,
                headers: headers
            )
            sessions[normalized]?.requestCount += 1
            return result
        }
    }

    func fetchSubscription(baseURL: String, fetchURL: String) async throws -> [String: Any] {
        let base = try Self.normalizeBaseURL(baseURL)
        let path = try Self.validatedSubscriptionPath(baseURL: base, fetchURL: fetchURL)
        let response = try await requestJSON(baseURL: base, method: "GET", path: path, maxBytes: 16 * 1_048_576)
        guard (200...299).contains(response.status), let body = response.object else {
            throw Self.protocolError(from: response, fallback: "加密订阅下载失败。")
        }
        return body
    }

    private func session(for baseURL: String) async throws -> Session {
        let now = Int64(Date().timeIntervalSince1970)
        if let session = sessions[baseURL], session.isUsable(at: now) { return session }
        sessions.removeValue(forKey: baseURL)
        let session = try await establishSession(baseURL: baseURL)
        sessions[baseURL] = session
        return session
    }

    private func establishSession(baseURL: String) async throws -> Session {
        let meta = try await requestJSON(baseURL: baseURL, method: "GET", path: "/api/v3/meta")
        guard meta.status >= 200, meta.status < 300,
              let root = meta.object,
              let data = root["data"] as? [String: Any],
              Self.int(data["version"]) == Self.version,
              Self.bool(data["enabled"]) == true,
              Self.string(data["server_signing_key_id"]) == Self.signingKeyID,
              Self.string(data["server_signing_public_key"]) == Self.signingPublicKey,
              Self.strings(data["accepted_kem"]).contains("x25519"),
              Self.strings(data["accepted_aead"]).contains(Self.aead),
              Self.strings(data["accepted_kdf"]).contains("hkdf-sha256") else {
            throw Self.protocolError(from: meta, fallback: "v3 服务能力与客户端不兼容。".appLocalized)
        }
        let tolerance = max(Self.int64(data["clock_skew"]) ?? 120, 120) + 5

        let privateKey = Curve25519.KeyAgreement.PrivateKey()
        let publicKey = privateKey.publicKey.rawRepresentation
        let nonceBytes = try Self.randomBytes(32)
        let clientNonce = SewerBase64URL.encode(nonceBytes)
        let handshakeBody: [String: Any] = [
            "client_nonce": clientNonce,
            "client_public_key": SewerBase64URL.encode(publicKey)
        ]
        let response = try await requestJSON(
            baseURL: baseURL,
            method: "POST",
            path: "/api/v3/handshake",
            json: handshakeBody
        )
        guard (200...299).contains(response.status),
              let root = response.object,
              let data = root["data"] as? [String: Any] else {
            throw Self.protocolError(from: response, fallback: "v3 安全握手失败。".appLocalized)
        }
        guard Self.int(data["version"]) == Self.version,
              let sessionID = Self.string(data["session_id"]), !sessionID.isEmpty,
              Self.string(data["client_nonce"]) == clientNonce,
              let serverPublicText = Self.string(data["server_public_key"]),
              let issuedAt = Self.int64(data["issued_at"]),
              let expiresAt = Self.int64(data["expires_at"]),
              let maxRequests = Self.int(data["max_requests"]), maxRequests > 0,
              Self.string(data["server_signing_key_id"]) == Self.signingKeyID,
              Self.string(data["server_signing_public_key"]) == Self.signingPublicKey,
              let signature = SewerBase64URL.decode(Self.string(data["signature"])),
              signature.count == 64 else {
            throw SewerV3Error.protocolFailure("v3 握手参数或固定公钥不匹配。".appLocalized)
        }
        let now = Int64(Date().timeIntervalSince1970)
        guard expiresAt > now, issuedAt >= now - tolerance, issuedAt <= now + tolerance else {
            throw SewerV3Error.protocolFailure("设备时间与安全会话时间不一致。".appLocalized)
        }
        let transcript = try SewerCanonicalJSON.data([
            "sewer-api-v3", "handshake", Self.version, sessionID,
            SewerBase64URL.encode(publicKey), clientNonce, serverPublicText,
            issuedAt, expiresAt, maxRequests, Self.signingKeyID
        ])
        guard let pinnedKey = SewerBase64URL.decode(Self.signingPublicKey),
              let verifier = try? Curve25519.Signing.PublicKey(rawRepresentation: pinnedKey),
              verifier.isValidSignature(signature, for: transcript),
              let serverPublicData = SewerBase64URL.decode(serverPublicText),
              let serverPublic = try? Curve25519.KeyAgreement.PublicKey(rawRepresentation: serverPublicData) else {
            throw SewerV3Error.protocolFailure("v3 服务端签名验证失败。".appLocalized)
        }
        let shared = try privateKey.sharedSecretFromKeyAgreement(with: serverPublic)
        let salt = Data(sessionID.utf8)
        let c2s = Self.hkdf(secret: shared, salt: salt, info: "sewer-api-v3|c2s")
        let s2c = Self.hkdf(secret: shared, salt: salt, info: "sewer-api-v3|s2c")
        return Session(
            id: sessionID,
            clientToServerKey: c2s,
            serverToClientKey: s2c,
            expiresAt: expiresAt,
            maxRequests: maxRequests
        )
    }

    private func sendRPC(
        baseURL: String,
        session: Session,
        operation: String,
        path: [String: Any],
        query: [String: Any],
        body: [String: Any],
        authorization: String?,
        headers: [String: String]
    ) async throws -> SewerV3RPCResult {
        let requestID = SewerBase64URL.encode(try Self.randomBytes(24))
        let timestamp = Int64(Date().timeIntervalSince1970)
        let nonce = try Self.randomBytes(12)
        var forwardedHeaders = headers
        if forwardedHeaders.keys.first(where: { $0.caseInsensitiveCompare("Accept-Language") == .orderedSame }) == nil {
            forwardedHeaders["Accept-Language"] = AppLanguage.resourceIdentifier
        }
        if forwardedHeaders.keys.first(where: { $0.caseInsensitiveCompare("User-Agent") == .orderedSame }) == nil {
            forwardedHeaders["User-Agent"] = SewerClientIdentity.userAgent
        }
        let plaintext: [String: Any] = [
            "operation": operation,
            "path": path,
            "query": query,
            "body": body,
            "authorization": authorization ?? "",
            "headers": forwardedHeaders
        ]
        let requestAAD = try SewerCanonicalJSON.data([
            "sewer-api-v3", "request", Self.version,
            session.id, requestID, timestamp
        ])
        let plaintextData = try SewerCanonicalJSON.data(plaintext)
        let encrypted = try Self.seal(
            plaintextData,
            key: session.clientToServerKey,
            nonce: nonce,
            aad: requestAAD
        )
        let envelope: [String: Any] = [
            "version": Self.version,
            "session_id": session.id,
            "request_id": requestID,
            "timestamp": timestamp,
            "nonce": SewerBase64URL.encode(nonce),
            "ciphertext": SewerBase64URL.encode(encrypted)
        ]
        let response = try await requestJSON(
            baseURL: baseURL,
            method: "POST",
            path: "/api/v3/rpc",
            json: envelope
        )
        guard (200...299).contains(response.status),
              let root = response.object else {
            throw Self.protocolError(from: response, fallback: "v3 加密请求失败。".appLocalized)
        }
        guard Self.int(root["version"]) == Self.version,
              Self.string(root["session_id"]) == session.id,
              Self.string(root["request_id"]) == requestID,
              Self.string(root["aead"]) == Self.aead,
              let responseTimestamp = Self.int64(root["timestamp"]),
              let httpStatus = Self.int(root["http_status"]),
              let responseNonce = SewerBase64URL.decode(Self.string(root["nonce"])),
              responseNonce.count == 12,
              let ciphertext = SewerBase64URL.decode(Self.string(root["ciphertext"])),
              ciphertext.count > 16 else {
            throw SewerV3Error.protocolFailure("v3 响应与请求不匹配。".appLocalized)
        }
        let responseAAD = try SewerCanonicalJSON.data([
            "sewer-api-v3", "response", Self.version,
            session.id, requestID, responseTimestamp, httpStatus
        ])
        let plaintextResponse = try Self.open(
            ciphertext,
            key: session.serverToClientKey,
            nonce: responseNonce,
            aad: responseAAD
        )
        guard let business = try JSONSerialization.jsonObject(with: plaintextResponse) as? [String: Any],
              Self.int(business["http_status"]) == httpStatus else {
            throw SewerV3Error.protocolFailure("v3 响应认证失败。".appLocalized)
        }
        let resultBody: Any?
        switch Self.string(business["kind"]) {
        case "json", "text":
            resultBody = business["body"]
        case "binary":
            resultBody = ["body_base64": business["body_base64"] ?? NSNull()]
        case "redirect":
            resultBody = ["location": business["location"] ?? NSNull()]
        default:
            throw SewerV3Error.protocolFailure("v3 响应类型不受支持。".appLocalized)
        }
        let resultObject = resultBody as? [String: Any]
        let error = (resultObject?["error"] as? [String: Any]) ?? (business["error"] as? [String: Any])
        let errorCode = Self.string(error?["code"])
        if (httpStatus == 401 && errorCode == "session_unknown_or_expired") ||
            (httpStatus == 429 && errorCode == "session_request_limit_reached") {
            throw SewerV3Error.server(
                status: httpStatus,
                message: Self.string(resultObject?["message"]) ?? "安全会话已过期，正在重新建立。".appLocalized,
                code: errorCode
            )
        }
        return SewerV3RPCResult(
            statusCode: httpStatus,
            status: Self.string(resultObject?["status"]),
            message: Self.string(resultObject?["message"]),
            body: resultBody,
            baseURL: baseURL
        )
    }

    private struct JSONResponse {
        let status: Int
        let object: [String: Any]?
    }

    private func requestJSON(
        baseURL: String,
        method: String,
        path: String,
        json: [String: Any]? = nil,
        maxBytes: Int = 1_048_576
    ) async throws -> JSONResponse {
        let url = try Self.url(baseURL: baseURL, path: path)
        guard let host = url.host else { throw SewerV3Error.invalidConfiguration }
        let requestPath = url.path + (url.query.map { "?\($0)" } ?? "")
        let body = try json.map { try SewerCanonicalJSON.data($0) } ?? Data()
        let response = try await SewerHTTPTransport.perform(
            host: host,
            method: method,
            path: requestPath,
            headers: [
                "Accept": "application/json",
                "Cache-Control": "no-store, no-cache",
                "Pragma": "no-cache",
                "Accept-Language": AppLanguage.resourceIdentifier,
                "User-Agent": SewerClientIdentity.userAgent
            ],
            body: body,
            maxResponseBytes: maxBytes
        )
        let parsed = try? JSONSerialization.jsonObject(with: response.body)
        let object = parsed as? [String: Any]
        return JSONResponse(status: response.status, object: object)
    }

    private static func protocolError(from response: JSONResponse, fallback: String) -> SewerV3Error {
        let root = response.object
        let error = root?["error"] as? [String: Any]
        let data = root?["data"] as? [String: Any]
        let dataError = data?["error"] as? [String: Any]
        return .server(
            status: response.status,
            message: string(error?["message"])
                ?? string(root?["message"])
                ?? string(data?["message"])
                ?? fallback,
            code: string(error?["code"]) ?? string(dataError?["code"])
        )
    }

    private static func hkdf(secret: SharedSecret, salt: Data, info: String) -> Data {
        let inputKey = SymmetricKey(data: secret.withUnsafeBytes { Data($0) })
        let key = HKDF<SHA256>.deriveKey(
            inputKeyMaterial: inputKey,
            salt: salt,
            info: Data(info.utf8),
            outputByteCount: 32
        )
        return key.withUnsafeBytes { Data($0) }
    }

    private static func seal(_ plaintext: Data, key: Data, nonce: Data, aad: Data) throws -> Data {
        let box = try ChaChaPoly.seal(
            plaintext,
            using: SymmetricKey(data: key),
            nonce: try ChaChaPoly.Nonce(data: nonce),
            authenticating: aad
        )
        return Data(box.ciphertext) + Data(box.tag)
    }

    private static func open(_ ciphertext: Data, key: Data, nonce: Data, aad: Data) throws -> Data {
        guard ciphertext.count > 16 else { throw SewerV3Error.invalidResponse }
        let body = ciphertext.prefix(ciphertext.count - 16)
        let tag = ciphertext.suffix(16)
        let box = try ChaChaPoly.SealedBox(
            nonce: try ChaChaPoly.Nonce(data: nonce),
            ciphertext: body,
            tag: tag
        )
        return try ChaChaPoly.open(box, using: SymmetricKey(data: key), authenticating: aad)
    }

    private static func randomBytes(_ count: Int) throws -> Data {
        var data = Data(count: count)
        let status = data.withUnsafeMutableBytes { bytes -> Int32 in
            guard let address = bytes.baseAddress else { return errSecParam }
            return SecRandomCopyBytes(kSecRandomDefault, count, address)
        }
        guard status == errSecSuccess else {
            throw SewerV3Error.protocolFailure("无法生成安全随机数。".appLocalized)
        }
        return data
    }

    private static func normalizeBaseURL(_ value: String) throws -> String {
        var trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        while trimmed.hasSuffix("/") { trimmed.removeLast() }
        guard let url = URL(string: trimmed), url.scheme == "https", let host = url.host,
              ["api.sewer.com.cn", "net.sewer.top", "api.sewer.top"].contains(host),
              url.user == nil, url.password == nil, url.query == nil, url.fragment == nil else {
            throw SewerV3Error.invalidConfiguration
        }
        return "https://\(host)"
    }

    private static func url(baseURL: String, path: String) throws -> URL {
        let normalized = try normalizeBaseURL(baseURL)
        guard let url = URL(string: normalized + "/" + path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))) else {
            throw SewerV3Error.invalidConfiguration
        }
        return url
    }

    private static func validatedSubscriptionPath(baseURL: String, fetchURL: String) throws -> String {
        let grantID = fetchURL.split(separator: "/").last.map(String.init) ?? ""
        guard !grantID.isEmpty else { throw SewerV3Error.invalidConfiguration }
        let expected = "/api/v3/subscription/fetch/\(grantID)"
        if fetchURL.hasPrefix("/") {
            guard fetchURL == expected else { throw SewerV3Error.protocolFailure("订阅下载地址与登录服务器不一致。".appLocalized) }
            return expected
        }
        guard let base = URL(string: baseURL), let url = URL(string: fetchURL),
              url.scheme == "https", url.host == base.host, url.port == base.port,
              url.path == expected, url.user == nil, url.password == nil,
              url.query == nil, url.fragment == nil else {
            throw SewerV3Error.protocolFailure("订阅下载地址与登录服务器不一致。".appLocalized)
        }
        return expected
    }

    static func string(_ value: Any?) -> String? {
        value as? String
    }

    static func int(_ value: Any?) -> Int? {
        if let number = value as? NSNumber { return number.intValue }
        if let string = value as? String { return Int(string) }
        return nil
    }

    static func int64(_ value: Any?) -> Int64? {
        if let number = value as? NSNumber { return number.int64Value }
        if let string = value as? String { return Int64(string) }
        return nil
    }

    static func bool(_ value: Any?) -> Bool? {
        if let number = value as? NSNumber { return number.boolValue }
        if let string = value as? String { return ["1", "true", "yes"].contains(string.lowercased()) }
        return nil
    }

    static func strings(_ value: Any?) -> [String] {
        (value as? [Any])?.compactMap { $0 as? String } ?? []
    }
}
