import Foundation
#if canImport(UIKit)
import UIKit
#endif

enum SewerAPIError: LocalizedError {
    case invalidResponse
    case server(String, Int? = nil)
    case invalidConfiguration

    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "服务返回的数据无效，请稍后重试。".appLocalized
        case .server(let message, _): return message.appLocalized
        case .invalidConfiguration: return "服务地址配置无效。".appLocalized
        }
    }

    var statusCode: Int? {
        if case .server(_, let status) = self { return status }
        return nil
    }
}

struct SewerLoginResult {
    let authentication: AuthenticationResponse
    let baseURL: String
}

struct SewerAPIClient {
    private let transport = SewerV3Transport.shared
    private let keyStore = SewerSubscriptionKeyStore.shared

    func login(email: String, password: String) async throws -> SewerLoginResult {
        var lastError: Error?
        for baseURL in SewerV3Transport.candidateBaseURLs {
            do {
                let result = try await transport.rpc(
                    baseURL: baseURL,
                    operation: "passport.auth.client-login",
                    body: [
                        "email": email.trimmingCharacters(in: .whitespacesAndNewlines),
                        "password": password,
                        "device_id": Self.installationID,
                        "platform": "ios",
                        "app_version": Self.appVersion
                    ]
                )
                let data = try Self.requireData(result, fallback: "登录失败。".appLocalized)
                let authentication = try Self.decode(AuthenticationResponse.self, from: data)
                guard !authentication.authData.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
                    throw SewerAPIError.invalidResponse
                }
                return SewerLoginResult(authentication: authentication, baseURL: baseURL)
            } catch let error as SewerV3Error where error.statusCode.map({ (400..<500).contains($0) }) == true {
                if error.statusCode == 404 || error.statusCode == 429 { lastError = error; continue }
                throw error
            } catch let error as SewerAPIError where error.statusCode.map({ (400..<500).contains($0) }) == true {
                if error.statusCode == 404 || error.statusCode == 429 { lastError = error; continue }
                throw error
            } catch {
                lastError = error
            }
        }
        throw lastError ?? SewerAPIError.server("无法连接 SEWER 服务器，请检查网络后重试。".appLocalized)
    }

    func subscription(for session: SewerSession) async throws -> SewerSubscriptionBundle {
        var deviceKey = try await registeredDeviceKey(for: session)
        var result = try await transport.rpc(
            baseURL: session.baseURL,
            operation: "user.get-subscribe",
            query: ["format": SewerSubscriptionCrypto.contentFormat],
            authorization: session.authorization,
            headers: subscriptionHeaders(deviceKeyID: deviceKey.keyID)
        )
        if Self.isDeviceKeyConflict(result) {
            deviceKey = try await register(try keyStore.rotate(deviceKey), session: session)
            result = try await transport.rpc(
                baseURL: session.baseURL,
                operation: "user.get-subscribe",
                query: ["format": SewerSubscriptionCrypto.contentFormat],
                authorization: session.authorization,
                headers: subscriptionHeaders(deviceKeyID: deviceKey.keyID)
            )
        }
        let data = try Self.requireData(result, fallback: "获取新版加密订阅失败。".appLocalized)
        let response = try Self.decode(SubscriptionResponse.self, from: data)
        guard let grant = response.subscriptionV3 else {
            throw SewerV3Error.protocolFailure("服务器未返回订阅 v3 Grant，已停止旧订阅回退。".appLocalized)
        }
        guard let serverDeviceKeyID = deviceKey.serverDeviceKeyID else {
            throw SewerV3Error.protocolFailure("订阅设备密钥尚未完成服务端确认。".appLocalized)
        }
        let fetchURL = try SewerSubscriptionCrypto.validateGrant(
            grant,
            baseURL: session.baseURL,
            serverDeviceKeyID: serverDeviceKeyID
        )
        let envelopeObject = try await transport.fetchSubscription(baseURL: session.baseURL, fetchURL: fetchURL)
        let envelope = try Self.decode(SewerSubscriptionEnvelope.self, from: envelopeObject)
        let plaintext = try SewerSubscriptionCrypto.decryptEnvelope(
            envelope,
            grant: grant,
            deviceKey: deviceKey,
            serverDeviceKeyID: serverDeviceKeyID
        )
        let nodes = try SubscriptionService().load(plaintext: plaintext)
        return SewerSubscriptionBundle(response: response, nodes: nodes)
    }

    func accountSummary(for session: SewerSession) async throws -> SubscriptionResponse {
        var deviceKey = try await registeredDeviceKey(for: session)
        var result = try await transport.rpc(
            baseURL: session.baseURL,
            operation: "user.get-subscribe",
            query: ["summary": "1"],
            authorization: session.authorization,
            headers: subscriptionHeaders(deviceKeyID: deviceKey.keyID)
        )
        if Self.isDeviceKeyConflict(result) {
            deviceKey = try await register(try keyStore.rotate(deviceKey), session: session)
            result = try await transport.rpc(
                baseURL: session.baseURL,
                operation: "user.get-subscribe",
                query: ["summary": "1"],
                authorization: session.authorization,
                headers: subscriptionHeaders(deviceKeyID: deviceKey.keyID)
            )
        }
        if result.statusCode == 400 || result.statusCode == 422 {
            result = try await transport.rpc(
                baseURL: session.baseURL,
                operation: "user.get-subscribe",
                authorization: session.authorization,
                headers: subscriptionHeaders(deviceKeyID: deviceKey.keyID)
            )
        }
        let data = try Self.requireData(result, fallback: "获取套餐状态失败。".appLocalized)
        return try Self.decode(SubscriptionResponse.self, from: data)
    }

    func accountProfile(for session: SewerSession) async throws -> AccountProfileResponse {
        let result = try await transport.rpc(
            baseURL: session.baseURL,
            operation: "user.type",
            authorization: session.authorization
        )
        let data = try Self.requireData(result, fallback: "获取账号类型失败。".appLocalized)
        return try Self.decode(AccountProfileResponse.self, from: data)
    }

    func notices(for session: SewerSession, currentPage: Int) async throws -> SewerNoticePage {
        let result = try await transport.rpc(
            baseURL: session.baseURL,
            operation: "user.notice.fetch",
            query: ["current": String(max(currentPage, 1))],
            authorization: session.authorization
        )
        let root = try Self.requireRoot(result, fallback: "公告服务返回异常。".appLocalized)
        let pageObject = (root["data"] as? [String: Any]) ?? root
        if let data = try? JSONSerialization.data(withJSONObject: pageObject, options: [.sortedKeys]),
           let page = try? JSONDecoder().decode(SewerNoticePage.self, from: data) {
            return page
        }
        throw SewerAPIError.invalidResponse
    }

    func acknowledgeLogout(for session: SewerSession) async throws {
        guard let token = session.token?.trimmingCharacters(in: .whitespacesAndNewlines), !token.isEmpty else {
            return
        }
        let result = try await transport.rpc(
            baseURL: session.baseURL,
            operation: "client.app.ack-logout",
            query: ["token": token],
            body: ["device_id": Self.installationID, "platform": "ios"],
            authorization: "Bearer \(token)",
            headers: ["User-Agent": "SEWER/\(Self.appVersion) iOS"]
        )
        _ = try Self.requireRoot(result, fallback: "确认退出失败。".appLocalized)
    }

    func clearDeviceIdentity() {
        keyStore.clear()
    }

    private func registeredDeviceKey(for session: SewerSession) async throws -> SewerSubscriptionDeviceKey {
        var key = try keyStore.loadOrCreate()
        if key.serverDeviceKeyID != nil {
            return key
        }
        do {
            return try await register(key, session: session)
        } catch let error as SewerV3Error where error.statusCode == 409 {
            key = try keyStore.rotate(key)
            return try await register(key, session: session)
        }
    }

    private func register(
        _ key: SewerSubscriptionDeviceKey,
        session: SewerSession
    ) async throws -> SewerSubscriptionDeviceKey {
        let result = try await transport.rpc(
            baseURL: session.baseURL,
            operation: "user.subscription-key.register",
            body: [
                "device_id": Self.installationID,
                "platform": "ios",
                "app_version": Self.appVersion,
                "key_id": key.keyID,
                "key_version": key.keyVersion,
                "key_alg": "x25519",
                "public_key": key.publicKeyText
            ],
            authorization: session.authorization
        )
        if result.statusCode == 409 {
            throw SewerV3Error.server(status: 409, message: "设备订阅密钥冲突或已撤销。".appLocalized, code: "conflict")
        }
        let data = try Self.requireData(result, fallback: "注册订阅设备密钥失败。".appLocalized)
        let registration = try Self.decode(SewerSubscriptionDeviceRegistration.self, from: data)
        guard registration.deviceKeyID > 0,
              registration.keyID == nil || registration.keyID == key.keyID,
              registration.keyVersion == 0 || registration.keyVersion == key.keyVersion,
              registration.acceptedKEM.contains(where: { $0.caseInsensitiveCompare("x25519") == .orderedSame }),
              registration.acceptedAEAD.contains(where: { $0.caseInsensitiveCompare(SewerV3Transport.aead) == .orderedSame }),
              registration.serverSigningKeyID == SewerV3Transport.signingKeyID,
              registration.subscriptionProtocolVersion == SewerV3Transport.version else {
            throw SewerV3Error.protocolFailure("服务端设备密钥或加密能力与客户端不一致。".appLocalized)
        }
        var registered = key
        try keyStore.markRegistered(&registered, serverDeviceKeyID: registration.deviceKeyID)
        return registered
    }

    private func subscriptionHeaders(deviceKeyID: String) -> [String: String] {
        [
            "x-sewer-subscription-version": String(SewerV3Transport.version),
            "x-sewer-device-key-id": deviceKeyID
        ]
    }

    private static func requireData(_ result: SewerV3RPCResult, fallback: String) throws -> Any {
        let root = try requireRoot(result, fallback: fallback)
        if let data = root["data"], !(data is NSNull) { return data }
        return root
    }

    private static func requireRoot(_ result: SewerV3RPCResult, fallback: String) throws -> [String: Any] {
        guard (200...299).contains(result.statusCode),
              result.status == nil || result.status?.caseInsensitiveCompare("success") == .orderedSame,
              let root = result.body as? [String: Any] else {
            throw apiError(from: result, fallback: fallback)
        }
        return root
    }

    private static func apiError(from result: SewerV3RPCResult, fallback: String) -> SewerAPIError {
        let root = result.body as? [String: Any]
        let error = root?["error"] as? [String: Any]
        let message = result.message
            ?? (error?["message"] as? String)
            ?? (root?["message"] as? String)
            ?? fallback
        return .server(message, result.statusCode)
    }

    private static func isDeviceKeyConflict(_ result: SewerV3RPCResult) -> Bool {
        guard result.statusCode == 409,
              let root = result.body as? [String: Any],
              let error = root["error"] as? [String: Any],
              let code = error["code"] as? String else {
            return false
        }
        let value = code.lowercased()
        return value.contains("device_key") || value.contains("subscription_key") || value.contains("key_conflict")
    }

    private static func decode<T: Decodable>(_ type: T.Type, from value: Any) throws -> T {
        let data = try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
        return try JSONDecoder().decode(type, from: data)
    }

    private static var appVersion: String {
        SewerClientIdentity.version
    }

    private static var installationID: String {
        let key = "sewer.installation-id.v1"
        if let existing = UserDefaults.standard.string(forKey: key), !existing.isEmpty {
            return existing
        }
        #if canImport(UIKit)
        let value = UIDevice.current.identifierForVendor?.uuidString ?? UUID().uuidString
        #else
        let value = UUID().uuidString
        #endif
        UserDefaults.standard.set(value, forKey: key)
        return value
    }
}
