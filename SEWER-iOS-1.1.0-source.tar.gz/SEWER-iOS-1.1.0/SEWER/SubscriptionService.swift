import CryptoKit
import Foundation

enum SubscriptionError: LocalizedError {
    case invalidURL
    case insecureURL
    case invalidResponse
    case contentTooLarge
    case noSupportedNodes

    var errorDescription: String? {
        switch self {
        case .invalidURL: return "订阅地址无效。".appLocalized
        case .insecureURL: return "订阅必须通过 HTTPS 安全下载。".appLocalized
        case .invalidResponse: return "订阅服务返回异常。".appLocalized
        case .contentTooLarge: return "订阅内容过大，已拒绝处理。".appLocalized
        case .noSupportedNodes: return "订阅中没有可用于当前 iOS 版本的 VLESS、Trojan、SOCKS5 或 Shadowsocks 线路。".appLocalized
        }
    }
}

struct SubscriptionService {
    // Keep accepted schemes aligned with the locally bundled core. VLESS and
    // Trojan retain their supported TCP, WebSocket, XHTTP, gRPC, and
    // HTTPUpgrade transports.
    private static let supportedSchemes: Set<String> = ["vless", "trojan", "socks", "socks5", "socks5h", "ss"]
    private let maximumSubscriptionBytes = 1_048_576
    private let maximumNodeURIBytes = 65_536

    func load(plaintext: String) throws -> [SewerNode] {
        let data = Data(plaintext.utf8)
        guard data.count <= maximumSubscriptionBytes else { throw SubscriptionError.contentTooLarge }
        let text = decode(data)
        let nodes = text
            .split(whereSeparator: \.isNewline)
            .compactMap { parse(String($0).trimmingCharacters(in: .whitespacesAndNewlines)) }

        guard !nodes.isEmpty else { throw SubscriptionError.noSupportedNodes }
        return Array(Dictionary(nodes.map { ($0.id, $0) }, uniquingKeysWith: { first, _ in first }).values)
            .sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }

    private func decode(_ data: Data) -> String {
        if let direct = String(data: data, encoding: .utf8), direct.contains("://") {
            return direct
        }

        let compact = String(decoding: data, as: UTF8.self)
            .components(separatedBy: .whitespacesAndNewlines)
            .joined()
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        let padded = compact + String(repeating: "=", count: (4 - compact.count % 4) % 4)
        return Data(base64Encoded: padded).flatMap { String(data: $0, encoding: .utf8) } ?? ""
    }

    private func parse(_ raw: String) -> SewerNode? {
        guard raw.utf8.count <= maximumNodeURIBytes else { return nil }
        guard let components = URLComponents(string: raw),
              let scheme = components.scheme?.lowercased(),
              Self.supportedSchemes.contains(scheme) else { return nil }

        // A server-side display-name change must not reset a user's selected line.
        let identitySource = raw.split(separator: "#", maxSplits: 1, omittingEmptySubsequences: false).first.map(String.init) ?? raw
        let digest = SHA256.hash(data: Data(identitySource.utf8))
        let id = digest.prefix(12).map { String(format: "%02x", $0) }.joined()
        let label = components.fragment?.removingPercentEncoding
        let name = (label?.isEmpty == false ? label! : "\(scheme.uppercased()) 线路")
        return SewerNode(id: id, scheme: scheme, name: name, rawURI: raw)
    }
}
