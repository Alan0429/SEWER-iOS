import CryptoKit
import Foundation
import Security

struct SewerSubscriptionDeviceKey {
    let keyID: String
    let keyVersion: Int
    let privateKey: Curve25519.KeyAgreement.PrivateKey
    var serverDeviceKeyID: Int64?

    var publicKeyText: String {
        SewerBase64URL.encode(privateKey.publicKey.rawRepresentation)
    }
}

struct SewerSubscriptionDeviceRegistration: Decodable {
    let deviceKeyID: Int64
    let keyID: String?
    let keyVersion: Int
    let serverSigningKeyID: String?
    let acceptedKEM: [String]
    let acceptedAEAD: [String]
    let subscriptionProtocolVersion: Int

    enum CodingKeys: String, CodingKey {
        case deviceKeyID = "device_key_id"
        case keyID = "key_id"
        case keyVersion = "key_version"
        case serverSigningKeyID = "server_signing_key_id"
        case acceptedKEM = "accepted_kem"
        case acceptedAEAD = "accepted_aead"
        case subscriptionProtocolVersion = "subscription_protocol_version"
    }
}

struct SewerSubscriptionGrant: Decodable {
    let version: Int
    let aead: String?
    let grantID: String?
    let fetchURL: String?
    let expiresAt: Int64
    let maxFetches: Int
    let contentFormat: String?
    let serverSigningKeyID: String?
    let serverEphemeralPublicKey: String?
    let signature: String?

    enum CodingKeys: String, CodingKey {
        case version
        case aead
        case grantID = "grant_id"
        case fetchURL = "fetch_url"
        case expiresAt = "expires_at"
        case maxFetches = "max_fetches"
        case contentFormat = "content_format"
        case serverSigningKeyID = "server_signing_key_id"
        case serverEphemeralPublicKey = "server_ephemeral_public_key"
        case signature
    }
}

struct SewerSubscriptionEnvelope: Decodable {
    let version: Int
    let aead: String?
    let grantID: String?
    let contentFormat: String?
    let nonce: String?
    let ciphertext: String?
    let serverSigningKeyID: String?
    let signature: String?

    enum CodingKeys: String, CodingKey {
        case version
        case aead
        case grantID = "grant_id"
        case contentFormat = "content_format"
        case nonce
        case ciphertext
        case serverSigningKeyID = "server_signing_key_id"
        case signature
    }
}

enum SewerSubscriptionCrypto {
    static let contentFormat = "v2ray"
    static let version = 3
    static let aead = "chacha20-poly1305-ietf"
    static let maximumPlaintextBytes = 8 * 1_048_576

    static func validateGrant(
        _ grant: SewerSubscriptionGrant,
        baseURL: String,
        serverDeviceKeyID: Int64,
        now: Int64 = Int64(Date().timeIntervalSince1970)
    ) throws -> String {
        guard serverDeviceKeyID > 0,
              grant.version == version,
              grant.aead == aead,
              let grantID = grant.grantID,
              let grantIDData = SewerBase64URL.decode(grantID),
              (24...32).contains(grantIDData.count),
              grant.expiresAt > now,
              grant.maxFetches >= 0,
              grant.contentFormat == contentFormat,
              grant.serverSigningKeyID == SewerV3Transport.signingKeyID,
              let serverPublic = grant.serverEphemeralPublicKey,
              let serverPublicData = SewerBase64URL.decode(serverPublic),
              serverPublicData.count == 32,
              let signatureText = grant.signature,
              let signature = SewerBase64URL.decode(signatureText),
              signature.count == 64 else {
            throw SewerV3Error.protocolFailure("订阅 Grant 参数、版本或加密能力无效。".appLocalized)
        }
        let transcript = try SewerCanonicalJSON.data([
            "sewer-sub-v3", "grant", version, grantID, grant.expiresAt,
            grant.maxFetches, contentFormat, serverDeviceKeyID,
            serverPublic, SewerV3Transport.signingKeyID
        ])
        try verifyPinnedSignature(signature, transcript: transcript, message: "订阅 Grant 签名验证失败。".appLocalized)

        let fetchURL = grant.fetchURL ?? ""
        let expectedPath = "/api/v3/subscription/fetch/\(grantID)"
        if fetchURL.hasPrefix("/") {
            guard fetchURL == expectedPath else {
                throw SewerV3Error.protocolFailure("订阅下载地址与登录服务器不一致。".appLocalized)
            }
            return fetchURL
        }
        guard let base = URL(string: baseURL), let url = URL(string: fetchURL),
              url.scheme == "https", url.host == base.host, url.port == base.port,
              url.path == expectedPath, url.user == nil, url.password == nil,
              url.query == nil, url.fragment == nil else {
            throw SewerV3Error.protocolFailure("订阅下载地址与登录服务器不一致。".appLocalized)
        }
        return fetchURL
    }

    static func decryptEnvelope(
        _ envelope: SewerSubscriptionEnvelope,
        grant: SewerSubscriptionGrant,
        deviceKey: SewerSubscriptionDeviceKey,
        serverDeviceKeyID: Int64
    ) throws -> String {
        guard serverDeviceKeyID > 0,
              envelope.version == version,
              envelope.aead == aead,
              envelope.grantID == grant.grantID,
              envelope.contentFormat == grant.contentFormat,
              envelope.serverSigningKeyID == SewerV3Transport.signingKeyID,
              let nonce = SewerBase64URL.decode(envelope.nonce),
              nonce.count == 12,
              let ciphertext = SewerBase64URL.decode(envelope.ciphertext),
              ciphertext.count > 16,
              ciphertext.count - 16 <= maximumPlaintextBytes,
              let grantID = grant.grantID,
              let contentFormat = grant.contentFormat,
              let serverPublicText = grant.serverEphemeralPublicKey,
              let serverPublicData = SewerBase64URL.decode(serverPublicText),
              let serverPublic = try? Curve25519.KeyAgreement.PublicKey(rawRepresentation: serverPublicData) else {
            throw SewerV3Error.protocolFailure("加密订阅响应与 Grant 不匹配。".appLocalized)
        }
        let shared = try deviceKey.privateKey.sharedSecretFromKeyAgreement(with: serverPublic)
        let inputKey = SymmetricKey(data: shared.withUnsafeBytes { Data($0) })
        let contentKey = HKDF<SHA256>.deriveKey(
            inputKeyMaterial: inputKey,
            salt: Data(grantID.utf8),
            info: Data("sewer-sub-v3|\(contentFormat)".utf8),
            outputByteCount: 32
        )
        let aad = try SewerCanonicalJSON.data([
            "sewer-sub-v3", "aad", version, grantID, contentFormat, serverDeviceKeyID
        ])
        let body = ciphertext.prefix(ciphertext.count - 16)
        let tag = ciphertext.suffix(16)
        let box = try ChaChaPoly.SealedBox(
            nonce: try ChaChaPoly.Nonce(data: nonce),
            ciphertext: body,
            tag: tag
        )
        let plaintext = try ChaChaPoly.open(box, using: contentKey, authenticating: aad)
        guard let text = String(data: plaintext, encoding: .utf8), !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw SewerV3Error.protocolFailure("解密后的订阅正文为空或编码无效。".appLocalized)
        }
        return text
    }

    private static func verifyPinnedSignature(_ signature: Data, transcript: Data, message: String) throws {
        guard let publicData = SewerBase64URL.decode(SewerV3Transport.signingPublicKey),
              let publicKey = try? Curve25519.Signing.PublicKey(rawRepresentation: publicData),
              publicKey.isValidSignature(signature, for: transcript) else {
            throw SewerV3Error.protocolFailure(message)
        }
    }
}

final class SewerSubscriptionKeyStore {
    static let shared = SewerSubscriptionKeyStore()

    private struct StoredKey: Codable {
        let keyID: String
        let keyVersion: Int
        let privateKey: Data
        let serverDeviceKeyID: Int64?
    }

    private let service = "top.sewer.client.ios"
    private let account = "subscription-device-key-v3"
    private let lock = NSLock()

    func loadOrCreate() throws -> SewerSubscriptionDeviceKey {
        lock.lock()
        defer { lock.unlock() }
        if let stored = loadStored(),
           !stored.keyID.isEmpty,
           stored.keyVersion > 0,
           let privateKey = try? Curve25519.KeyAgreement.PrivateKey(rawRepresentation: stored.privateKey) {
            return SewerSubscriptionDeviceKey(
                keyID: stored.keyID,
                keyVersion: stored.keyVersion,
                privateKey: privateKey,
                serverDeviceKeyID: (stored.serverDeviceKeyID ?? 0) > 0 ? stored.serverDeviceKeyID : nil
            )
        }
        let key = SewerSubscriptionDeviceKey(
            keyID: SewerBase64URL.encode(try Self.randomData(count: 18)),
            keyVersion: Int(Date().timeIntervalSince1970),
            privateKey: Curve25519.KeyAgreement.PrivateKey(),
            serverDeviceKeyID: nil
        )
        try save(key)
        return key
    }

    func rotate(_ previous: SewerSubscriptionDeviceKey? = nil) throws -> SewerSubscriptionDeviceKey {
        lock.lock()
        defer { lock.unlock() }
        let nextVersion = max((previous?.keyVersion ?? 0) + 1, Int(Date().timeIntervalSince1970))
        let key = SewerSubscriptionDeviceKey(
            keyID: SewerBase64URL.encode(try Self.randomData(count: 18)),
            keyVersion: nextVersion,
            privateKey: Curve25519.KeyAgreement.PrivateKey(),
            serverDeviceKeyID: nil
        )
        try save(key)
        return key
    }

    func markRegistered(_ key: inout SewerSubscriptionDeviceKey, serverDeviceKeyID: Int64) throws {
        lock.lock()
        defer { lock.unlock() }
        key.serverDeviceKeyID = serverDeviceKeyID
        try save(key)
    }

    func clear() {
        lock.lock()
        defer { lock.unlock() }
        SecItemDelete([
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account
        ] as CFDictionary)
    }

    private func save(_ key: SewerSubscriptionDeviceKey) throws {
        let stored = StoredKey(
            keyID: key.keyID,
            keyVersion: key.keyVersion,
            privateKey: key.privateKey.rawRepresentation,
            serverDeviceKeyID: key.serverDeviceKeyID
        )
        let data = try JSONEncoder().encode(stored)
        SecItemDelete([
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account
        ] as CFDictionary)
        let status = SecItemAdd([
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account,
            kSecValueData: data,
            kSecAttrAccessible: kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        ] as CFDictionary, nil)
        guard status == errSecSuccess else {
            throw SewerV3Error.protocolFailure("无法安全保存订阅设备密钥。".appLocalized)
        }
    }

    private func loadStored() -> StoredKey? {
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account,
            kSecReturnData: true,
            kSecMatchLimit: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return try? JSONDecoder().decode(StoredKey.self, from: data)
    }

    private static func randomData(count: Int) throws -> Data {
        var data = Data(count: count)
        let status = data.withUnsafeMutableBytes { bytes -> Int32 in
            guard let address = bytes.baseAddress else { return errSecParam }
            return SecRandomCopyBytes(kSecRandomDefault, count, address)
        }
        guard status == errSecSuccess else {
            throw SewerV3Error.protocolFailure("无法生成安全随机数。".appLocalized)
        }
        return data
    }
}
