# App Store Connect Privacy Details

This document is the submission checklist for App Store Connect's **App Privacy** form. It is not an app privacy manifest and cannot be submitted through Xcode. The service owner must validate every answer against production server logs and data retention before each submission.

## Current declaration baseline

- Tracking: **No**.
- Advertising or third-party analytics SDKs: **None**.
- Sale of user data: **No**.
- Data is used only for account management, app functionality, service security, and diagnostics.
- The main app privacy manifest declares Email Address, User ID, Other Usage Data, and Other Diagnostic Data as linked, non-tracking data used for app functionality.

## Data to declare when it is linked to an account

| App Store Connect data type | Declare when production service processes it | Linked to user | Purpose |
| --- | --- | --- | --- |
| Contact Info - Email Address | Login email or support email is stored server-side | Yes | App Functionality, Account Management |
| Identifiers - User ID | Account ID, subscription authorization, or other persistent account identifier is stored server-side | Yes | App Functionality, Account Management, Security |
| Usage Data - Other Usage Data | Per-account traffic quota, consumed traffic, or connection state is stored server-side | Yes | App Functionality |
| Diagnostics - Other Diagnostic Data | Per-account connection failures, security events, or diagnostic logs are stored server-side | Yes, if the event can be associated with the account | App Functionality, Security |

## Mandatory server-side confirmation

Do not declare **Browsing History** only if production systems do not retain visited domains, DNS queries, destination IP addresses, URLs, or equivalent destination records in a way that can be associated with an account. If any such record is retained, App Store Connect must be updated to declare the applicable data type and the public privacy policy must describe it.

The client resolves SEWER, AWS edge, and protected route hostnames through Alibaba DoH (`223.5.5.5`) and Tencent DoH (`1.12.12.12`) before the tunnel exists, falling back to plain DNS only after DoH failure. If every resolution path for `net.sewer.top` fails, a preconfigured service IP may be dialled while TLS still validates `net.sewer.top`. Smart Acceleration reads Amazon's public CloudFront IP ranges and measures candidate TLS latency. After connection, device IPv4/IPv6 DNS uses Cloudflare `1.1.1.1` through the selected line, and public IPv4/IPv6, UDP, and WebRTC/STUN traffic is captured by the Packet Tunnel to prevent physical-network leakage. Tunnel health checks use Apple's `captive.apple.com` status page and Cloudflare's `cp.cloudflare.com/generate_204` endpoint through the selected route; only HTTP status, latency, and required network metadata are processed. Before submission, the service owner must disclose this processing in the public policy and have counsel confirm that the operational and disclosure model is consistent with the VPN requirements in App Review Guideline 5.4. Do not mark the service as collecting no data while this or any other server-side processing remains in production.
