// Live Activities are intentionally omitted. VPN status is exposed through
// the Home Screen and Lock Screen widget without keeping an activity live.
