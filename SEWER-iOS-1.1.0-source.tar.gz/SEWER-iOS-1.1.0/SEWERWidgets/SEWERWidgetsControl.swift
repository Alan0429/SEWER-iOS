import AppIntents
import NetworkExtension
import SwiftUI
import WidgetKit

@available(iOSApplicationExtension 18.0, *)
struct SEWERWidgetsControl: ControlWidget {
    static let kind = "top.sewer.client.ios.control"

    var body: some ControlWidgetConfiguration {
        AppIntentControlConfiguration(kind: Self.kind, provider: Provider()) { isConnected in
            ControlWidgetButton(action: ToggleSewerConnectionIntent()) {
                Label(
                    isConnected
                        ? (WidgetSharedStore.usesEnglish ? "SEWER Protected" : "SEWER 已保护")
                        : (WidgetSharedStore.usesEnglish ? "SEWER Disconnected" : "SEWER 未连接"),
                    systemImage: isConnected ? "checkmark.shield.fill" : "shield"
                )
            }
        }
        .displayName("SEWER Connection")
        .description("Show and toggle the current SEWER connection.")
    }

    struct Provider: AppIntentControlValueProvider {
        func previewValue(configuration: SewerControlConfiguration) -> Bool {
            true
        }

        func currentValue(configuration: SewerControlConfiguration) async throws -> Bool {
            let managers = try await NETunnelProviderManager.loadAllFromPreferences()
            let sewerManagers = managers.filter {
                let identifier = ($0.protocolConfiguration as? NETunnelProviderProtocol)?.providerBundleIdentifier
                return identifier == "top.sewer.client.ios.tunnel"
                    || identifier == "top.sewer.client.ios.tunnel.singbox"
            }
            guard !sewerManagers.isEmpty else {
                return WidgetSharedStore.loadSnapshot().connectionState == "connected"
            }
            return sewerManagers.contains { $0.connection.status == .connected }
        }
    }
}

@available(iOSApplicationExtension 18.0, *)
struct SewerControlConfiguration: ControlConfigurationIntent {
    static let title: LocalizedStringResource = "SEWER Connection"
}
