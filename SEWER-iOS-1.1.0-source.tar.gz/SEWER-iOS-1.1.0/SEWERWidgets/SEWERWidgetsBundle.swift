//
//  SEWERWidgetsBundle.swift
//  SEWERWidgets
//
//  Created by 豪豪 on 2026/8/17.
//

import WidgetKit
import SwiftUI

@main
struct SEWERWidgetsBundle: WidgetBundle {
    var body: some Widget {
        SEWERWidgets()
        if #available(iOSApplicationExtension 18.0, *) {
            SEWERWidgetsControl()
        }
    }
}
