// The control intent is shared from SEWER/WidgetActionIntent.swift so it is
// registered by both the host app and its WidgetKit extension.
