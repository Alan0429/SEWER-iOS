import AppIntents
import NetworkExtension
import SwiftUI
import WidgetKit

private struct SewerStatusEntry: TimelineEntry {
    let date: Date
    let snapshot: SewerWidgetSnapshot
}

private struct SewerStatusProvider: TimelineProvider {
    func placeholder(in context: Context) -> SewerStatusEntry {
        SewerStatusEntry(date: .now, snapshot: SewerWidgetSnapshot(
            remainingTraffic: "32.5 GB",
            routeName: "Hong Kong Premium",
            planName: "Enterprise",
            expiresAt: Date().addingTimeInterval(30 * 24 * 60 * 60),
            connectionState: "connected",
            healthState: "available",
            latencyMilliseconds: 86,
            updatedAt: .now
        ))
    }

    func getSnapshot(in context: Context, completion: @escaping (SewerStatusEntry) -> Void) {
        loadCurrentEntry { entry in
            completion(entry)
        }
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<SewerStatusEntry>) -> Void) {
        loadCurrentEntry { entry in
            let interval: TimeInterval = entry.snapshot.connectionState == "connected" ? 2 * 60 : 5 * 60
            completion(Timeline(entries: [entry], policy: .after(Date().addingTimeInterval(interval))))
        }
    }

    private func loadCurrentEntry(completion: @escaping (SewerStatusEntry) -> Void) {
        let cached = WidgetSharedStore.loadSnapshot()
        Task {
            let state = await currentConnectionState()
            let snapshot = state.map {
                SewerWidgetSnapshot(
                    remainingTraffic: cached.remainingTraffic,
                    routeName: cached.routeName,
                    planName: cached.planName,
                    expiresAt: cached.expiresAt,
                    connectionState: $0,
                    healthState: cached.healthState,
                    latencyMilliseconds: cached.latencyMilliseconds,
                    updatedAt: Date()
                )
            } ?? cached
            completion(SewerStatusEntry(date: .now, snapshot: snapshot))
        }
    }

    private func currentConnectionState() async -> String? {
        do {
            let managers = try await NETunnelProviderManager.loadAllFromPreferences()
            let sewerManagers = managers.filter {
                let identifier = ($0.protocolConfiguration as? NETunnelProviderProtocol)?.providerBundleIdentifier
                return identifier == "top.sewer.client.ios.tunnel"
                    || identifier == "top.sewer.client.ios.tunnel.singbox"
            }
            guard !sewerManagers.isEmpty else {
                return "disconnected"
            }
            if sewerManagers.contains(where: { $0.connection.status == .connected }) {
                return "connected"
            }
            if sewerManagers.contains(where: {
                $0.connection.status == .connecting
                    || $0.connection.status == .reasserting
                    || $0.connection.status == .disconnecting
            }) {
                return "connecting"
            }
            return "disconnected"
        } catch {
            // WidgetKit can be launched before the containing app has created
            // its first configuration. Fall back to the App Group snapshot.
            return nil
        }
    }
}

struct SEWERWidgets: Widget {
    let kind = WidgetSharedConstants.statusWidgetKind

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: SewerStatusProvider()) { entry in
            SewerStatusWidgetView(entry: entry)
                .containerBackground(for: .widget) {
                    LinearGradient(
                        colors: [
                            Color(red: 11 / 255, green: 18 / 255, blue: 32 / 255),
                            Color(red: 20 / 255, green: 50 / 255, blue: 92 / 255)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                }
        }
        .configurationDisplayName("SEWER 状态")
        .description("查看当前线路、连接状态和剩余流量。")
        .supportedFamilies([
            .systemSmall, .systemMedium,
            .accessoryCircular, .accessoryRectangular, .accessoryInline
        ])
    }
}

private struct SewerStatusWidgetView: View {
    @Environment(\.widgetFamily) private var family
    let entry: SewerStatusEntry

    private var isEnglish: Bool { WidgetSharedStore.usesEnglish }
    private var isConnected: Bool { entry.snapshot.connectionState == "connected" }
    private var isConnecting: Bool { entry.snapshot.connectionState == "connecting" }
    private var statusText: String {
        if isConnected { return isEnglish ? "Protected" : "已保护" }
        if isConnecting { return isEnglish ? "Connecting" : "连接中" }
        return isEnglish ? "Disconnected" : "未连接"
    }
    private var statusColor: Color {
        isConnected ? .green : (isConnecting ? .orange : .secondary)
    }

    var body: some View {
        Group {
            switch family {
            case .systemMedium:
                mediumLayout
            case .accessoryInline:
                accessoryInline
            case .accessoryCircular:
                accessoryCircular
            case .accessoryRectangular:
                accessoryRectangular
            default:
                smallLayout
            }
        }
        .padding(isAccessoryFamily ? 2 : 12)
        .foregroundStyle(.white)
    }

    private var isAccessoryFamily: Bool {
        switch family {
        case .accessoryCircular, .accessoryRectangular, .accessoryInline:
            return true
        default:
            return false
        }
    }

    private var smallLayout: some View {
        VStack(alignment: .leading, spacing: 0) {
            Link(destination: URL(string: "sewer://open")!) {
                VStack(alignment: .leading, spacing: 5) {
                    header
                    statusLabel
                    routeLabel
                    planLabel
                }
            }
            .buttonStyle(.plain)

            Spacer(minLength: 7)

            Link(destination: URL(string: "sewer://open")!) {
                HStack(alignment: .firstTextBaseline, spacing: 6) {
                    Text(isEnglish ? "Remaining" : "剩余流量")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                    Spacer(minLength: 4)
                    Text(entry.snapshot.remainingTraffic)
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                        .minimumScaleFactor(0.8)
                }
            }
            .buttonStyle(.plain)

            Spacer(minLength: 5)
            healthLabel
            Spacer(minLength: 7)
            connectionButton
        }
    }

    private var mediumLayout: some View {
        HStack(alignment: .center, spacing: 14) {
            Link(destination: URL(string: "sewer://open")!) {
                VStack(alignment: .leading, spacing: 6) {
                    header
                    statusLabel
                    routeLabel
                    planLabel
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .buttonStyle(.plain)

            Divider()

            VStack(alignment: .trailing, spacing: 9) {
                Link(destination: URL(string: "sewer://open")!) {
                    VStack(alignment: .trailing, spacing: 2) {
                        Text(isEnglish ? "Remaining traffic" : "剩余流量")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                        Text(entry.snapshot.remainingTraffic)
                            .font(.headline.weight(.semibold))
                            .foregroundStyle(.white)
                            .lineLimit(1)
                            .minimumScaleFactor(0.75)
                    }
                }
                .buttonStyle(.plain)
                healthLabel
                connectionButton
                    .frame(width: 112)
            }
            .frame(width: 126, alignment: .trailing)
        }
    }

    private var accessoryInline: some View {
        Text("SEWER · \(statusText)")
            .font(.caption.weight(.semibold))
    }

    private var accessoryCircular: some View {
        ZStack {
            AccessoryWidgetBackground()
            VStack(spacing: 1) {
                Image(systemName: isConnected ? "checkmark.shield.fill" : "shield")
                    .font(.title3)
                    .foregroundStyle(isConnected ? .green : .orange)
                Text(entry.snapshot.latencyMilliseconds > 0 ? "\(entry.snapshot.latencyMilliseconds)" : statusText)
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .minimumScaleFactor(0.7)
            }
        }
    }

    private var accessoryRectangular: some View {
        VStack(alignment: .leading, spacing: 2) {
            HStack(spacing: 4) {
                Image(systemName: isConnected ? "checkmark.shield.fill" : "shield")
                Text("SEWER · \(statusText)")
                    .font(.caption.weight(.bold))
            }
            Text(entry.snapshot.routeName.isEmpty ? (isEnglish ? "Open SEWER" : "打开 SEWER") : entry.snapshot.routeName)
                .font(.caption2)
                .lineLimit(1)
            HStack {
                Text(entry.snapshot.remainingTraffic)
                Spacer()
                Text(healthText)
            }
            .font(.caption2.weight(.medium))
        }
    }

    private var planLabel: some View {
        Group {
            if !entry.snapshot.planName.isEmpty {
                Text(entry.snapshot.planName)
                    .lineLimit(1)
            } else if let expiresAt = entry.snapshot.expiresAt {
                Text((isEnglish ? "Valid until " : "有效期至 ") + expiresAt.formatted(date: .abbreviated, time: .omitted))
                    .lineLimit(1)
            }
        }
        .font(.caption2)
        .foregroundStyle(.white.opacity(0.62))
    }

    private var healthLabel: some View {
        HStack(spacing: 4) {
            Circle()
                .fill(healthColor)
                .frame(width: 5, height: 5)
            Text(healthText)
                .font(.caption2.weight(.medium))
                .foregroundStyle(.white.opacity(0.74))
                .lineLimit(1)
        }
    }

    private var healthText: String {
        switch entry.snapshot.healthState {
        case "available":
            let latency = String(entry.snapshot.latencyMilliseconds).prefix(2)
            return "\(latency) ms"
        case "checking": return isEnglish ? "Checking" : "检测中"
        case "unavailable": return isEnglish ? "Unstable" : "线路异常"
        default: return isEnglish ? "Health --" : "状态 --"
        }
    }

    private var healthColor: Color {
        switch entry.snapshot.healthState {
        case "available": return .green
        case "checking": return .blue
        case "unavailable": return .red
        default: return .gray
        }
    }

    private var header: some View {
        HStack(spacing: 7) {
            Image(systemName: isConnected ? "checkmark.shield.fill" : "shield")
                .foregroundStyle(statusColor)
                .frame(width: 22, height: 22)
            Text("SEWER")
                .font(.headline.weight(.semibold))
                .lineLimit(1)
                .fixedSize(horizontal: true, vertical: false)
                .layoutPriority(1)
        }
    }

    private var statusLabel: some View {
        HStack(spacing: 5) {
            Circle()
                .fill(statusColor)
                .frame(width: 6, height: 6)
            Text(statusText)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(statusColor)
        }
    }

    private var routeLabel: some View {
        Group {
            if entry.snapshot.routeName.isEmpty {
                Text(isEnglish ? "Open SEWER" : "打开 SEWER")
                    .foregroundStyle(.secondary)
            } else {
                Text(entry.snapshot.routeName)
            }
        }
        .font(.caption.weight(.medium))
        .lineLimit(1)
        .truncationMode(.tail)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var connectionButton: some View {
        Button(intent: ToggleSewerConnectionIntent()) {
            Label(
                isConnected
                    ? (isEnglish ? "Disconnect" : "断开连接")
                    : (isConnecting ? (isEnglish ? "Connecting" : "连接中") : (isEnglish ? "Connect" : "连接")),
                systemImage: isConnected ? "power" : (isConnecting ? "hourglass" : "bolt.fill")
            )
            .font(.caption.weight(.semibold))
            .lineLimit(1)
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(.borderedProminent)
        .tint(isConnected ? .secondary : (isConnecting ? .orange : .green))
        .controlSize(.small)
        .disabled(isConnecting)
    }

}
