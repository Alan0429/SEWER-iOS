# Corresponding source and GPLv3 obligations

The iOS client links sing-box `experimental/libbox` and is therefore distributed under GNU GPL version 3. The complete source code used to build a distributed binary must be made publicly available for at least the period required by GPLv3, together with the scripts and build instructions needed to reproduce the binary.

## Public source location

The exact corresponding source for the distributed App Store build is available
at:

- Release tag: `https://github.com/Alan0429/SEWER-iOS/tree/v1.1.0`
- Repository: `https://github.com/Alan0429/SEWER-iOS`

The tag and source repository are public and must remain available for at least
the period required by GPLv3. Every later binary release must use a new matching
tag and update the in-app source link.

## Components

- SEWER iOS client: this source tree at the exact release commit/tag.
- sing-box integration fork: `https://github.com/KaringX/sing-box/tree/73603b201141ee9bab41af76995808ccfc45209f`.
- Xray Core: `https://github.com/XTLS/Xray-core/tree/5d17b872edde3024a5b906d9cd6c7a3ad4973d81`.

The reduced libbox build supports SOCKS5, Shadowsocks, and the built-in SIP003
`obfs-local` and `v2ray-plugin` implementations. It does not download or launch
external plugin executables.

No source file in the sing-box core is modified by SEWER. The generated `LibboxSlim.xcframework` is built from the sing-box commit above with:

```sh
gomobile init
gomobile bind \
  -target ios,iossimulator \
  -libname box \
  -o LibboxSlim.xcframework \
  -tags-not-macos=with_low_memory \
  -tags=with_gvisor,grpcnotrace \
  ./experimental/libbox
```

Framework binaries used by this build (SHA-256):

```text
LibboxSlim ios-arm64:
4618a53e0579121e57038b86a951e9ab90dac3050bded07bbeeaf5287b8b9bd3
LibboxSlim ios-arm64_x86_64-simulator:
c7fc5fa4b7b20eb2fb66cfd11dada51f2f59abf02b21d1342fc63cd1261d9ab9
XrayBridge ios-arm64:
7a9c494e7037a213a2315811b440eb7dc30180680289f752bc3d7283f2ee6c85
XrayBridge ios-arm64_x86_64-simulator:
c95f458abfec9e4e337f986f31ce77cae91b27af6ee1a49ca0cee24192311bf7
```

The SEWER integration source is the Xcode project in this repository. The full
canonical GPLv3 text is in `LICENSE` and is included in the app bundle. The
public repository and matching release tag above satisfy the source-location
requirement for this version. Keep the tag immutable and do not replace the
release source after upload.
