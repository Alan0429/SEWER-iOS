# Third-party notices

## Xray Core

This project builds Xray Core from source commit `5d17b872edde3024a5b906d9cd6c7a3ad4973d81` (upstream main, 2026-11-14) into the Packet Tunnel extension through `XrayBridge`.

Xray Core is licensed under the [Mozilla Public License 2.0](https://github.com/XTLS/Xray-core/blob/5d17b872edde3024a5b906d9cd6c7a3ad4973d81/LICENSE). Keep this notice in every distributed build. If any MPL-covered source file is modified, provide the modified source form as required by MPL-2.0.

## sing-box / libbox

The iOS tunnel uses a reduced `libbox` build from KaringX/sing-box commit `73603b201141ee9bab41af76995808ccfc45209f` for SOCKS5 and Shadowsocks routes. Shadowsocks SIP003 handling uses sing-box's built-in `obfs-local` and `v2ray-plugin` implementations; no external plugin executable is downloaded or launched.

sing-box is licensed under GNU GPL version 3; its upstream copyright and additional terms are preserved in `LICENSE.sing-box`. The project as a whole is conveyed under GPLv3, whose complete canonical text is in `LICENSE` and is bundled with the app. The complete corresponding SEWER client source, build instructions, exact dependency revisions, and source-download location must be published with every distributed build. See `CORRESPONDING_SOURCE.md`.
